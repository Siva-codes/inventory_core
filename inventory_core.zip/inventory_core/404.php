<?php include 'config.php'; 
// print_r($_SESSION); exit;
  if(!empty($_SESSION["customerid"]))
  {
    $IsLogin = '1';
    $CustomerId = $_SESSION['customerid'];
    $CartDetail = $db->getRows("SELECT * from cart_details WHERE customerid='".$CustomerId."'");
    $TotalItems = count($CartDetail);
      // echo '<pre>'; print_r($CartDetail); exit;
  }
  else { 
    $IsLogin = 0;
    $TotalItems = 0;
    $CustomerId = '';  
  }
 ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title> PetButty | Categories</title>
    <!-- Favicon -->
    <link rel="shortcut icon" href="images/favicon.ico">
    <link rel="icon" sizes="16x16 32x32 64x64 " href="images/favicon.ico">
    <link rel="icon" type="image/png" sizes="196x196" href="images/favicon-192.png">
    <link rel="icon" type="image/png" sizes="160x160" href="images/favicon-160.png">
    <link rel="icon" type="image/png" sizes="96x96" href="images/favicon-96.png">
    <link rel="icon" type="image/png" sizes="64x64" href="images/favicon-64.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16.png">
    <link rel="apple-touch-icon" href="images/favicon-57.png">
    <link rel="apple-touch-icon" sizes="114x114" href="images/favicon-114.png">
    <link rel="apple-touch-icon" sizes="72x72" href="images/favicon-72.png">
    <link rel="apple-touch-icon" sizes="144x144" href="images/favicon-144.png">
    <link rel="apple-touch-icon" sizes="60x60" href="images/favicon-60.png">
    <link rel="apple-touch-icon" sizes="120x120" href="images/favicon-120.png">
    <link rel="apple-touch-icon" sizes="76x76" href="images/favicon-76.png">
    <link rel="apple-touch-icon" sizes="152x152" href="images/favicon-152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="images/favicon-180.png">
    <meta name="msapplication-TileColor" content="#FFFFFF">
    <meta name="msapplication-TileImage" content="images/favicon-144.png">
    <meta name="msapplication-config" content="/browserconfig.xml">
    <meta charset="UTF-8">
    <!-- For Resposive Device -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- For IE -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="canonical" href="" />
    <meta name="description" content="">
    <meta name="keywords" content="" />

    <!-- Main style sheet -->
    <link rel="stylesheet" href="css/style.css">
    <!-- responsive style sheet -->
    <link rel="stylesheet" href="css/responsive.css">

    <link rel="stylesheet" href="css/custom-style.css">
    <link href="https://fonts.googleapis.com/css?family=PT+Sans+Narrow:400,700|Dosis:500,600,700,800|Quicksand:400,500,700|Josefin+Sans" rel="stylesheet">
    <!-- Fix Internet Explorer ______________________________________-->

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-131549512-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'UA-131549512-1');
    </script>
    
</head>
	
<body>
	
	<div class="main-page-wrapper">

		<!-- Header _________________________________ -->
		<?php include 'menu_section.php'; ?>

			<!-- Error-page ____________________________ -->
			<section class="error-page">
				<div class="container">
					<div class="error-page-text">
						<div class="top-png"><img src="images/404-img-2.png" alt=""></div>
						<h2>404</h2>
						<h6>Sorry page  not found</h6>
						<p>The page you were looking for could not be found.</p>
						<a href="index.php"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back to Home Page</a>
						<div class="bottom-png"><img src="images/404-img-2.png" alt=""></div>
					</div>
				</div>
			</section>

			<!-- Footer ____________________________ -->
			<?php include 'footer_section.php'; ?>
			
		</div> <!-- /.main-page-wrapper -->
		

		<!-- Scroll Top Button -->
		<button class="scroll-top tran7s p-color-bg">
			<i class="fa fa-angle-up" aria-hidden="true"></i>
		</button>

		<!-- pre loader  -->
	 	<div id="loader-wrapper">
			<div id="loader"></div>
		</div>
	

    <!-- js file -->
    <!-- Main js file/jquery -->
    <script src="vendor/jquery-2.2.3.min.js"></script>
    <!-- bootstrap-select.min.js -->
    <script src="vendor/bootstrap-select-1.10.0/dist/js/bootstrap-select.min.js"></script>
    <!-- bootstrap js -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <!-- camera js -->
    <script src="vendor/Camera-master/scripts/camera.min.js"></script>
    <script src="vendor/Camera-master/scripts/jquery.easing.1.3.js"></script>
    <!-- Owl carousel -->
    <script src="vendor/OwlCarousel2/dist/owl.carousel.min.js"></script>
    <!-- appear & countTo -->
    <script src="vendor/jquery.appear.js"></script>
    <script src="vendor/jquery.countTo.js"></script>
    <!-- fancybox -->
    <script src="vendor/fancybox/dist/jquery.fancybox.min.js"></script>
    <!-- Gallery - isotop -->
    <script type="text/javascript" src="vendor/isotope.pkgd.min.js"></script>
    <!-- WOW js -->
    <script type="text/javascript" src="vendor/WOW-master/dist/wow.min.js"></script>
    <!-- Circle Progress -->
    <script type="text/javascript" src="vendor/circle-progress.js"></script>
    <!-- Style js -->
    <script src="js/custom.js"></script>
    <script src="js/login_signup.js"></script>
    <script type="text/javascript">
      

$(window).on('load', function () {
  $('.category-selection').each(function () {
    var tree = $(this);
    tree.treeview();
  })
});

  function OpenCartPage(){
    var IsLogin = '<?php echo $IsLogin ?>';
    if(IsLogin == 1){
      window.location.replace("cart_view.php");
    }else{
      $('#signup-modal').modal('show');
    }
  }

  function isNumber(evt) {
      evt = (evt) ? evt : window.event;
      var charCode = (evt.which) ? evt.which : evt.keyCode;
      if (charCode > 31 && (charCode < 48 || charCode > 57)) {
          return false;
      }
      return true;
  } 
  </script>
	</body>
</html>