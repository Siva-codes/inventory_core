<?php
header("Location: http://localhost/inventory_core/admin");
exit();
?>