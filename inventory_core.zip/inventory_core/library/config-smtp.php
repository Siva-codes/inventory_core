<?php
define("SMTP_HOST", "localhost");
define("SMTP_PORT", 25);
define("SMTP_USER", "info@omsoftware.us");
define("SMTP_PSWD", "$09~JTm^@tZb");

?>