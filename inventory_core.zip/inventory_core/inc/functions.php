<?php  
function validate_promo_code($customer_id,$promo_code,$total){
	$resp=array();
	$sql = "select * from promo_code where code=BINARY'".$promo_code."'";
	$this->db->sql($sql);
	$res = $this->db->getResult();
	if(empty($res)){
		$resp['error'] = true;
		$resp['msg'] = "Invalid Promo code.";
		return $resp;
		exit();
	}
	if($res[0]['status']==0){
		$resp['error'] = true;
		$resp['msg'] = "This Promo code is either expired / invalid.";
		return $resp;
		exit();
	}

	$sql = "select customer_id from customer_id where customer_id=".$customer_id;
	$this->db->sql($sql);
	$res_user = $this->db->getResult();
	if(empty($res_user)){
		$resp['error'] = true;
		$resp['msg'] = "Invalid Customer.";
		return $resp;
		exit();
	}

	$fr_date = $res[0]['fr_date'];
	$to_date = $res[0]['to_date'];
	$date = time();

	if($date<$fr_date){
		$resp['error'] = true;
		$resp['msg'] = "This Promo code can't be used before ".date('d-m-Y',strtotime($fr_date))."";
		return $resp;
		exit();
	}
	if($date>$to_date){
		$resp['error'] = true;
		$resp['msg'] = "This Promo code can't be used after ".date('d-m-Y',strtotime($to_date))."";
		return $resp;
		exit();
	}
	if($total<$res[0]['min_order_amt']){
		$resp['error'] = true;
		$resp['msg'] = "This Promo code is applicable only for order amount greater than or equal to ".$res[0]['min_order_amt']."";
		return $resp;
		exit();

	}
	if($res[0]['tot_usage']==0){
		$resp['error'] = true;
		$resp['msg'] = "This Promo code is not usage!";
		return $resp;
		exit();
	}

	$sql = "select orders_id from orders where promo_code=BINARY'".$promo_code."' GROUP BY customer_id";
	$this->db->sql($sql);
	$res_order = $this->db->numRows();

	if($res_order>=$res[0]['tot_customer']){
		$resp['error'] = true;
		$resp['msg'] = "This Promo code is applicable only for first ".$res[0]['tot_customer']." customers.";
		return $resp;
		exit();
	}

	$sql = "select orders from orders where customer_id=".$customer_id." and promo_code=BINARY'".$promo_code."'";
	$this->db->sql($sql);
	$total_usage = $this->db->numRows();
	if($total_usage>=$res[0]['tot_usage']){
		$resp['error'] = true;
		$resp['msg'] = "This Promo code is applicable only for ".$res[0]['tot_usage']." times.";
		return $resp;
		exit();
	}

	if($res[0]['disc_type']=='P'){
		$percent = $res[0]['disc_amt'];
		$disc_amt = $total/100*$percent;

		if($disc_amt>$res[0]['max_disc_amt'])
			$disc_amt=$res[0]['max_disc_amt'];		
	}
	else
		$disc_amt=$res[0]['disc_amt'];

	$discounted_amount = $total - $disc_amt;
	$resp['error'] = false;
	$resp['msg'] = "Promo code applied successfully.";
	$resp['promo_code'] = $promo_code;
	$resp['promo_code_msg'] = $res[0]['description'];
	$resp['tot_amt'] = $total;
	$resp['disc_amt'] = "$disc_amt";
	$resp['discounted_amount'] = "$discounted_amount";
	return $resp;
	exit();
}
 ?>