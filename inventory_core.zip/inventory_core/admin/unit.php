<?php include("../config.php");

if(empty($_SESSION["Users_Id"]))  {
  echo "<script>window.location.href='login.php';</script>";
}

$view_perm=$add_perm=$edit_perm=$del_perm=true;  

if (isset($_SESSION['success']) && ($_SESSION['success'] != "")) {
  $stat['success'] = $_SESSION['success'];
  unset($_SESSION['success']);
}
if (isset($_SESSION['error']) && ($_SESSION['error'] != "")) {
  $stat['danger'] = $_SESSION['error'];
  unset($_SESSION['error']);
}

if (!empty($_POST['unit_id'])) {
  $save= $_POST;
  $save['conversion']= !empty($_POST["conversion"])?$_POST["conversion"]:0;
  $save['modified_by']= $_SESSION["Users_Id"];
  $save['modified_date']= date('Y-m-d H:i:s'); 

  $res = $db->updateAry("unit", $save, "where unit_id=".$_POST['unit_id']);

  unset($_POST);
  if(isset($res)){
    unset($_POST);
    $_SESSION['success'] = "Unit updated successfully.";    
  }
  else{
    $_SESSION['error'] ="Unit update failed.";
  }  

  redirect('unit.php');
}
elseif (!empty($_POST['name'])) 
{
 $save= $_POST;
 $save['conversion']= !empty($_POST["conversion"])?$_POST["conversion"]:0;
 $save['created_by']= $_SESSION["Users_Id"];
 $save['created_date']= date('Y-m-d H:i:s');      

 $id = $db->insertAry('unit',$save);
  // echo $db->getLastQuery(); exit;
 if(!is_null($id))
  $_SESSION['success'] = "Unit Added successfully.";
else
  $_SESSION['error'] ="Unit update failed.";
// echo $db->getLastQuery(); exit;
unset($_POST);
redirect('unit.php');          
}
?>
<?php include 'includes/header.php'; ?>
<link href="dist/css/img_upl.css" rel="stylesheet">
<div class="row">                   
  <div class="col-lg-12 col-sm-12" style="padding: 0;"> 
    <div class="row panel panel-default" id="firstRow">      
      <div class="add-newproduct-tab">
        <div class="gradient-card-header">
          <h2 class="white-text mx-3">Measurement Unit</h2>
        </div>
      </div>
      <?php echo !empty($stat)?msg($stat):'';?>
      <div class="courseAddPrmssn">
        <button type="button" id="btn_add" class="btn btn-info button-addnew pull-right" ><i class="fa fa-angle-down" aria-hidden="true"></i>Add Unit&nbsp;&nbsp; 
        </button>
        <br/><br/>
      </div>
      <form method="post" class="frm-save" name="doc-register" enctype="multipart/form-data">
        <div id="content" class="panel panel-default" >
          <div class="panel-body">
            <div class="row">
             <div class="col-md-3">
              <span class="badge-label">Name<span class="redstar">*</span></span>
              <input class="form-control name" name="name">
            </div>
            <div class="col-md-3">
              <span class="badge-label">Parent Unit<span class="redstar">*</span></span>
              <select class="select form-control parent_unit_id" name="parent_unit_id">
                <option value="0">Select Parent Unit</option>
                <?php  $res = $db->getRows("SELECT unit_id,name FROM unit order by name");
                if( count($res) > 0){
                  foreach($res as $res1){ ?>
                    <option value="<?= $res1["unit_id"] ?>"><?= $res1["name"] ?></option>
                  <?php } 
                }?>     
              </select>
            </div>      
            <div class="col-md-2">
              <span class="badge-label">Conversion<span class="redstar">*</span></span>
              <input class="form-control conversion" onkeypress="return isNumber(event)" name="conversion">
            </div>         
            <div class="col-md-4">
              <div class="pull-right top30">
                <label style="position: absolute;top: -3px;padding-left:10px;" class="err_lbl"></label>&nbsp;&nbsp;
                <button class="btn blue-gradient button-save btn-save" title="Save" type="button" name="saveGroup"><i class="fa fa-check" aria-hidden="true"></i> Add</button>
                <button type="reset" title="Cancel" class="btn danger-gradient button-cancel"><i class="fa fa-times" aria-hidden="true"></i> Clear</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </form>
    <div class="row">
      <div class="">
        <div class="panel-default">
          <div class="panel-body">
            <div style1="overflow-y: auto;">
              <form method="post">
                <table style="width: 100%" class="table table-striped table-hover table-bordered" id="data_table">
                  <thead>
                    <tr>
                      <th>Unit Name</th>
                      <th>Parent Unit</th>
                      <th>Conversion</th>
                      <th class="text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody id="row-cont">
                    <?php
                    $res = $db->getRows("SELECT a.*,b.name as parent_name FROM unit a left join unit b on a.parent_unit_id=b.unit_id order by a.unit_id desc");

                    if( count($res) > 0){
                      foreach($res as $key => $res1){ 
                        $id = $res1["unit_id"];
                        ?>
                        <tr class="odd gradeX">
                          <td><?= $res1['name']; ?></td>
                          <td><?= $res1['parent_name']?$res1['parent_name']:'-'; ?></td>
                          <td><?= $res1['conversion']?$res1['conversion']:'-'; ?></td>
                          <td class="text-center">                                
                            <button class="btn_edit btn btn-primary btn-circle courseEditPrmssn" data-toggle="modal" data-target="#mod_data" name="edit" value="<?php echo $id ?>"  data-id="<?php echo $id ?>" ><i class="fa fa-pencil-alt" title="Edit"></i></button>
                            <button type="button" id="delete" onclick="del_confirm(this)" name="delete" value="<?php  echo $id ?>" class="btn btn-danger btn-circle courseDeletePrmssn" title="Delete"><i class="fa fa-times"></i>
                            </button>
                          </td>                          
                        </tr>
                      <?php  } }
                      ?>                    
                    </tbody>                  
                  </table>              
                </form>
              </div>
            </div> <!-- panel-body-->
          </div> <!-- panel-default-->
        </div> <!-- empty class-->
      </div> <!-- row-->
    </div>          
  </div>
</div>
<div class="modal fade" id="mod_data" role="dialog">
  <div class="modal-dialog cascading-modal" role="document">
    <!--Content-->
    <div class="modal-content">
      <!--Header-->
      <div class="modal-header light-blue darken-3 white-text">
        <button type="button" class="close waves-effect waves-light" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
        <h4 class="title"><i class="fa fa-pencil-alt"></i> EDIT</h4>
      </div>
      <!--Body-->
      <div class="modal-body mb-0">
        <form method="post" class="frm-upd" enctype="multipart/form-data">
          <div id="upd"></div>
          <br/>
          <div class="text-center">
            <label class="err_lbl"></label><br>
            <button type="button" name="update" id="btn_upd" data-id="0" class=" btn btn-success button-update btn-save"><i class="fa fa-check" aria-hidden="true"></i>Update
            </button>
            <button type="button" data-dismiss="modal" class="btn btn-warning button-cancel"><i class="fa fa-times"></i>Cancel</button>
          </div>
          <br/>
        </form>
      </div>
    </div>
    <!--/.Content-->
  </div>
</div>
<?php include 'includes/footer.php'; ?>
<script>  
 $(document).ready(function() {
  $('.select').select2();

  $("#btn_add").click(function(){
    $("#content").toggle();
    $(this).find(".fa-angle-down").toggleClass('fa-angle-up');
  });
});
 $("#content").toggle();
 $(document).ready(function() {
  $('#data_table').DataTable({
    "scrollX": true,
    "columnDefs": [
    { "orderable": false, "targets": [3]},
    { "orderable": true, "targets": [0, 1,2]}
    ],
     "aaSorting": []
  });    
});
 $( ".btn_edit" ).click(function( event ) {
  event.preventDefault();

  var id =$(this).attr('data-id');
  $.ajax({
    url: 'aj_data.php',
    type: 'POST',
    data: 'action=unit_edit&id='+id,
    dataType: 'html'
  })
  .done(function(data){      
    $('#upd').empty().append(data);
    $('#btn_upd').attr('data-id',id);
  })
  $('#mod_data').find('.err_lbl').html('');
  $('#mod_data').modal('show');
  return false;
});  
 function del_confirm(e) {
  var id = e.value;
  $.confirm({
    icon: 'fa fa-warning',
    title: 'Confirm!',
    content: 'Do you want to Delete ?',
    type: 'red',
    buttons: {
      confirm:  {
        btnClass: 'btn-red',
        action: function(){
          $.confirm({
            icon: 'fa fa-warning',
            title: 'Confirm!',
            content: 'If you Delete, You cant restore this record !',
            type: 'red',
            buttons: {
              Okay: {
                btnClass: 'btn-red',
                action: function(){
                  $.ajax({
                    type: 'post',
                    url: 'aj_data.php',
                    data: 'action=del_setting&type=unit&id='+id,
                    dataType: "json",
                    success: function (data) {
                      if(data['validation'] == '1'){
                       window.location.reload();
                     }
                     else{
                      $.alert(data['message']);
                    }
                  }
                });
                }
              },
              Cancel: function () { },
            }
          });
        }
      },
      cancel: function () { },
    }
  });
}  

$(document).on('click','.btn-save',function(e){    
  $err_lbl= $(this).parent().find('.err_lbl');
  $err_lbl.html('');

  if($(this).attr('data-id')){
    $id=$(this).attr('data-id');
    $frm = $('.frm-upd');
  }
  else{
    $id =0;
    $frm = $('.frm-save');        
  }

  $val = '';
  $frm.find('input:text').each(function(){
    $(this).val($.trim($(this).val()));
  });

  $val=$frm.find('.name').val();
  $parent_unit_id=$frm.find('.parent_unit_id').val();  
  $conversion=$frm.find('.conversion').val();
  if($conversion=='')
    $conversion=0;
  
  $conversion=parseFloat($conversion);

  if($val ==''){
    $err_lbl.html('Please enter name!');
    return false;
  }      
  if(($parent_unit_id !=0 && $conversion==0) || ($parent_unit_id==0 && $conversion!=0)){
    $err_lbl.html('Invalid conversion value!');
    return false;
  }      

  $chk_val=$val;   

  $.ajax({
    url : "aj_data.php",
    data: 'action=chk_dup&type=unit&chk_fld=name&chk_val='+$chk_val+'&chk_id='+$id,
    success: function(res){
      res =$.trim(res);
      if(res=='E')
        $err_lbl.html('Unit already exists!');
      else
        $frm.submit();
    }
  }); 
}); 

</script>
