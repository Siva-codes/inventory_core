<?php include '../config.php';

    // print_r($_SESSION); exit;

if(!empty($_SESSION["Users_Id"])){
        // $row = $db->getRow("SELECT users_id FROM users where users_id=".$_SESSION["user_id"]);
    $DCount=$DTable='yes';
}
else{
    echo "<script>window.location.href='login.php';</script>";   
}

// if(!empty($_SESSION["adminlogin"]))
// {
//     if(!empty($_SESSION["slogin"]))
//     {
//         $slogin=$_SESSION["slogin"];
//         $row = $db->getRow("SELECT * FROM subadmin where subadminid='".$_SESSION["slogin"]."' ");
//             //$row = $query->fetch_assoc();
//         $DCount = $row['dashboard_count'];
//         $DTable = $row['dashboard_table'];
//     }
//     else { echo "<script>window.location.href='login.php';</script>"; }
// }
// else
// {
//     echo "<script>window.location.href='login.php';</script>";

// }
?> 
<?php include 'includes/header.php'; ?>

<style type="text/css">
    .material-icons {
        font-family: 'Material Icons';
        font-weight: normal;
        font-style: normal;
        font-size: 24px;
        line-height: 1;
        letter-spacing: normal;
        text-transform: none;
        display: inline-block;
        white-space: nowrap;
        word-wrap: normal;
        direction: ltr;
        -webkit-font-feature-settings: 'liga';
        -webkit-font-smoothing: antialiased;
    }
    .card{
        border: 0;
        margin-bottom: 30px;
        margin-top: 45px;
        /*border-radius: 6px;*/
        color: #333;
        background: #fff;
        width: 100%;
        /*box-shadow: 0 2px 2px 0 rgba(0,0,0,.14), 0 3px 1px -2px rgba(0,0,0,.2), 0 1px 5px 0 rgba(0,0,0,.12);*/
    }
    .card-icon{
        /*border-radius: 3px;*/
        background-color: #999;
        padding: 15px;
        margin-top: -30px;
        margin-right: 10px;
        float: left;
        /*box-shadow: 0 4px 20px 0 rgba(0,0,0,.14), 0 7px 10px -5px rgba(255,152,0,.4);*/
        /*background: linear-gradient(60deg,#ffa726,#fb8c00);*/
    }
    .card-icon i{
        font-size: 36px;
        line-height: 50px;
        width: 50px;
        height: 50px;
        text-align: center;
        color: #ffffffd6;
        /* text-shadow: 0px 1px 5px #00000069; */
    }
    .card-header {
        padding: .75em 1rem;
        background-color: #f7f7f9;
    }
    .card-stats .card-header .card-category:not([class*=text-]) {
        color: #999;
        font-size: 14px;
    }
    .card .card-header {
        border-bottom: none;
        background: transparent;
    }
    .card-stats .card-header+.card-footer {
        border-top: 1px solid #eee;
        /*margin-top: 20px;*/
    }
    .card .card-body+.card-footer, .card .card-footer {
        padding: 0;
        padding-top: 10px;
        margin: 0 15px 10px;
        border-radius: 0;
        justify-content: space-between;
        align-items: center;
    }
    .card .card-header.card-header-icon .card-title, .card .card-header.card-header-text .card-title {
        margin-top: 15px;
        color: #3c4858;
        font-size: 1.5625rem;
    }
    .card-stats .card-header.card-header-icon, .card-stats .card-header.card-header-text {
        text-align: right;
    }
    .card.bg-success, .card .card-header-success .card-icon, .card .card-header-success .card-text, .card .card-header-success:not(.card-header-icon):not(.card-header-text), .card.card-rotate.bg-success .back, .card.card-rotate.bg-success .front {
        background: linear-gradient(60deg,#66bb6a,#43a047);
    }
    .card .card-header-success .card-icon, .card .card-header-success .card-text, .card .card-header-success:not(.card-header-icon):not(.card-header-text) {
        box-shadow: 0 4px 20px 0 rgba(0,0,0,.14), 0 7px 10px -5px rgba(76,175,80,.4);
    }
    .card.bg-danger, .card .card-header-danger .card-icon, .card .card-header-danger .card-text, .card .card-header-danger:not(.card-header-icon):not(.card-header-text), .card.card-rotate.bg-danger .back, .card.card-rotate.bg-danger .front {
        background: linear-gradient(60deg,#ef5350,#e53935);
    }
    .card .card-header-danger .card-icon, .card .card-header-danger .card-text, .card .card-header-danger:not(.card-header-icon):not(.card-header-text) {
        box-shadow: 0 4px 20px 0 rgba(0,0,0,.14), 0 7px 10px -5px rgba(244,67,54,.4);
    }
    .card .card-header-info .card-icon, .card .card-header-info .card-text, .card .card-header-info:not(.card-header-icon):not(.card-header-text) {
        box-shadow: 0 4px 20px 0 rgba(0,0,0,.14), 0 7px 10px -5px rgba(0,188,212,.4);
    }
    .card.bg-info, .card .card-header-info .card-icon, .card .card-header-info .card-text, .card .card-header-info:not(.card-header-icon):not(.card-header-text), .card.card-rotate.bg-info .back, .card.card-rotate.bg-info .front {
        background: linear-gradient(60deg,#26c6da,#00acc1);
    }
    .card.bg-warning, .card .card-header-warning .card-icon, .card .card-header-warning .card-text, .card .card-header-warning:not(.card-header-icon):not(.card-header-text), .card.card-rotate.bg-warning .back, .card.card-rotate.bg-warning .front {
        /*background: linear-gradient(60deg,#ffa726,#fb8c00);*/
        background: linear-gradient(60deg,#ab47bc,#8e24aa);
    }
    .card .card-header-warning .card-icon, .card .card-header-warning .card-text, .card .card-header-warning:not(.card-header-icon):not(.card-header-text) {
        /*box-shadow: 0 4px 20px 0 rgba(0,0,0,.14), 0 7px 10px -5px rgba(255,152,0,.4);*/
        box-shadow: 0 4px 20px 0 rgba(0,0,0,.14), 0 7px 10px -5px rgba(156,39,176,.4);
    }
    .card .card-body+.card-footer .stats, .card .card-footer .stats {
        color: #575757;
        font-size: 13px;
        line-height: 22px;
        font-weight: 400;

    }
    .card .card-body+.card-footer .stats .material-icons, .card .card-footer .stats .material-icons {
        position: relative;
        top: 4px;
        font-size: 16px;
    }
    .card .card-footer .stats .material-icons {
        top: 2px;
        margin-right: 7px;
        margin-left: 3px;
        font-size: 17px;
    }
    #dashboard-table thead{
        color: #09c !important;
        background-color: transparent!important;
    }
    .table-bordered>thead>tr>th, .table-bordered>tbody>tr>th, .table-bordered>tfoot>tr>th, .table-bordered>thead>tr>td, .table-bordered>tbody>tr>td, .table-bordered>tfoot>tr>td {
        border: 0px solid #ddd;
        /*padding: .75rem;*/
        vertical-align: top;
        border-top: 1px solid #dee2e6;
        font-size: 1.02rem;
        padding: 12px 8px;
    }
    .table-bordered>thead>tr>th{
        font-weight: 400;
    }
    .table-bordered>tbody>tr>td{
        color: #444444;
        /*font-weight: 100;*/
    }
    #dashboard-table .panel-heading {
        color: #fff;
        background-color: #09c;
        border-color: #09c;
    }

    .card .card-footer .author, .card .card-footer .stats {
        display: inline-flex;
    }
</style>
<?php 

$Orders=$Returns=$Cancels=$Customers=0;
$DCount =$DTable= 'yes';
if($DCount == 'yes'){ ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="col-lg-3 col-md-6 col-sm-6">
              <div class="card card-stats">
                <div class="card-header card-header-warning card-header-icon">
                  <div class="card-icon">
                     <i class="material-icons">
                        shopping_cart
                    </i>
                </div>
                <p class="card-category">Today Orders</p>
                <h3 class="card-title"><?php echo $Orders ?>
                <!-- <small>GB</small> -->
            </h3>
        </div>
        <div class="card-footer">
          <div class="stats">
            <i class="material-icons text-info">visibility</i>
            <a href="orders.php">View Entire Details</a>
        </div>
    </div>
</div>
</div>
<div class="col-lg-3 col-md-6 col-sm-6">
  <div class="card card-stats">
    <div class="card-header card-header-success card-header-icon">
      <div class="card-icon">
        <i class="material-icons">
            replay
        </i>
    </div>
    <p class="card-category">Today Returns</p>
    <h3 class="card-title"><?php echo $Returns ?></h3>
</div>
<div class="card-footer">
  <div class="stats">
     <i class="material-icons text-info">visibility</i> 
     <a href="return.php">View Entire Details</a>
 </div>
</div>
</div>
</div>
<div class="col-lg-3 col-md-6 col-sm-6">
  <div class="card card-stats">
    <div class="card-header card-header-danger card-header-icon">
      <div class="card-icon">
        <i class="material-icons">
            block
        </i>
    </div>
    <p class="card-category">Today Cancel</p>
    <h3 class="card-title"><?php echo $Cancels ?></h3>
</div>
<div class="card-footer">
  <div class="stats">
    <i class="material-icons text-info">visibility</i> 
    <a href="cancel.php">View Entire Details</a>
</div>
</div>
</div>
</div>
<div class="col-lg-3 col-md-6 col-sm-6">
  <div class="card card-stats">
    <div class="card-header card-header-info card-header-icon">
      <div class="card-icon">
        <i class="material-icons">
            supervisor_account
        </i>
    </div>
    <p class="card-category">Customers</p>
    <h3 class="card-title"><?php echo $Customers ?></h3>
</div>
<div class="card-footer">
  <div class="stats">
    <i class="material-icons text-info">visibility</i> 
    <a href="customers.php">View Entire Details</a>
</div>
</div>
</div>
</div>
</div>
<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<?php } ?>

<br/>

<?php 
if($DTable == 'yes'){ ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="col-md-6 ">
                <div class="col-md-12">
                    <div class=" row panel panel-default" id="dashboard-table" style="margin-top:2em">
                        <div class="gradient-card-header-info">
                            <h2 class="white-text mx-3">Recent Orders</h2>
                        </div>
        <!--             <div class="panel-heading" style="text-decoration-color: black;">
                    Last Five Order List
                </div> -->
                <div class="panel-body table-responsive">

                    <table width="100%" class="table table-striped table-bordered table-hover" >
                        <thead >
                            <tr>
                                <th>Order&nbsp;Id</th>
                                <th>Status</th>
                                <th>Product&nbsp;Image</th>
                                <th>Date&nbsp;and&nbsp;Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                //get images from database
                            // $orders = $db->getRows("SELECT orders.*, product.catId, product.Sub_categoriesId FROM orders LEFT JOIN product on product.ProductID=orders.productid where orders.payment_status='success' and orders.order_status !='Cancel Requested' and orders.order_status !='Cancelled' ORDER BY id DESC Limit 5");
                // echo $db->getLastQuery();
                // $query = $db->query("SELECT * FROM images ORDER BY uploaded_on DESC");
                            $orders=array();
                            if(count($orders) > 0){
                                foreach($orders as $order_list)
                                {
                                    $orderid = $order_list["orderid"];
                                    $customerid = $order_list["customerid"];
                                    $customername = $order_list["customername"];
                                    $image = $order_list["image"];
                                    $productid = $order_list["productid"];
                                    $productname = $order_list["productname"];
                                    $amount = $order_list["selling_price"];
                                    $date = $order_list["OrderPlacedDateTime"];
                                    $id = $order_list["id"];

                                    $payment = $order_list["payment"];
                                    $status = $order_list["order_status"];
                                    ?>

                                    <tr class="odd gradeX">
                                        <td><?php  echo $orderid ?></td>
                                        <td><?php  echo $status ?></td>
                                        <td><img src="uploads/product_images/<?= $order_list["catId"] ?>/<?= $order_list["Sub_categoriesId"] ?>/<?php  echo $image ?>" class="img-responsive" style="height: 70px" > </td>
                                        <td><?php echo date("d-m-Y h:m:s a", strtotime($date)); ?></td>
                                    </tr>
                                <?php  } } ?>

                            </tbody>
                        </table>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.panel-body -->
                </div>
            </div>
            <!-- /.panel -->
        </div>


        <div class="col-md-6">
           <div class="col-md-12">
               <div class=" row panel panel-default" id="dashboard-table" style="margin-top:2em" >
                <div class="gradient-card-header-info">
                    <h2 class="white-text mx-3">Recent Returned Orders</h2>
                </div>

<!--             <div class="panel-heading" >
              Last Five Return List
          </div> -->
          <!-- /.panel-heading -->
          <div class="panel-body table-responsive">
            <table width="100%" class="table table-striped table-bordered table-hover" >
                <thead >
                    <tr>
                        <th>Return&nbsp;Id</th>
                        <th>Order&nbsp;Id</th>
                        <th>Product&nbsp;Image</th>
                        <th>Status</th>
                        <th>Date&nbsp;and&nbsp;Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php

        //get images from database
                    //$returns = $db->getRows("SELECT returns.*, product.catId, product.Sub_categoriesId FROM returns LEFT JOIN product on product.ProductID = returns.productid  ORDER BY returns.id DESC Limit 5");
                    $returns=array();
        // $query = $db->query("SELECT * FROM images ORDER BY uploaded_on DESC");
                    if(count($returns) > 0){
                        foreach($returns as $value)
                        {  
                            $returnid = $value["returnid"];
                            $orderid = $value["orderid"];
                            $image = $value["image"];
                            $date = $value["ReturnRequestDateTime"];
                            $status = $value["status"];
                            ?>
                            <tr class="odd gradeX">
                                <td><?php  echo $returnid ?></td>
                                <td><?php  echo $orderid ?></td>
                                <td>
                                    <img src="uploads/product_images/<?= $value["catId"] ?>/<?= $value["Sub_categoriesId"] ?>/<?= $image ?>" class="img-responsive" style="height: 70px" > 
                                </td>
                                <td><?php  echo $value["status"] ?></td>
                                <td><?php echo date("d-m-Y h:m:s a", strtotime($date)); ?></td>
                            </tr>

                        <?php  }} ?>

                    </tbody>
                </table>
                <!-- /.table-responsive -->

            </div>
            <!-- /.panel-body -->
        </div>
    </div>
    <!-- /.panel -->
</div>

</div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="col-md-6 ">
            <div class="col-md-12">
                <div class=" row panel panel-default" id="dashboard-table" style="margin-top:3em">
                    <div class="gradient-card-header-info">
                        <h2 class="white-text mx-3">Recent Cancelled Orders</h2>
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body table-responsive">
                        <table width="100%"  class="table table-striped table-bordered table-hover" >
                            <thead style="background-color: #f7e8e8;">
                                <tr>
                                    <th>Order&nbsp;Id</th>
                                    <th>Status</th>
                                    <th>Product&nbsp;Image</th>
                                    <th>Date&nbsp;and&nbsp;Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php

        //get images from database
                            //    $cancel = $db->getRows("SELECT orders.*, product.catId, product.Sub_categoriesId FROM orders LEFT JOIN product on product.ProductID=orders.productid where orders.order_status ='Cancel Requested' or orders.order_status ='Cancelled' ORDER BY OrderPlacedDateTime DESC Limit 5");
                                $cancel=array();
        // $query = $db->query("SELECT * FROM images ORDER BY uploaded_on DESC");
                                if(count($cancel) > 0){
                                    foreach($cancel as $cancel_list)
                                    {  
                                        $orderid = $cancel_list["orderid"];
                                        $customerid = $cancel_list["customerid"];
                                        $customername = $cancel_list["customername"];
                                        $image = $cancel_list["image"];
                                        $productid = $cancel_list["productid"];
                                        $productname = $cancel_list["productname"];
                                        $amount = $cancel_list["selling_price"];
                                        $date = $cancel_list["OrderPlacedDateTime"];
                                        $id = $cancel_list["id"];

                                        $payment = $cancel_list["payment"];
                                        $status = $cancel_list["order_status"];
                                        ?>
                                        <tr class="odd gradeX">
                                            <td><?php  echo $orderid ?></td>
                                            <td><?php  echo $status ?></td>
                                            <td><img src="uploads/product_images/<?= $cancel_list["catId"] ?>/<?= $cancel_list["Sub_categoriesId"] ?>/<?php  echo $image ?>" class="img-responsive" style="height: 70px" > </td>
                                            <td><?php echo date("d-m-Y h:m:s a", strtotime($date)); ?></td>
                                        </tr>
                                    <?php  }} ?>

                                </tbody>
                            </table>
                            <!-- /.table-responsive -->

                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>
                <!-- /.panel -->
            </div>

            <div class="col-md-6 ">
                <div class="col-md-12">
                    <div class=" row panel panel-default" id="dashboard-table" style="margin-top:3em">
                        <div class="gradient-card-header-info">
                            <h2 class="white-text mx-3">Recent Customers</h2>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body table-responsive">

                          <table width="100%" class="table table-striped table-bordered table-hover" id="employees">
                            <thead style="background-color: #f7e8e8;" >
                                <tr>
                                    <th>Customer&nbsp;ID</th>
                                    <th>Customer&nbsp;Name</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php

        //get images from database
                                // $customer = $db->getRows("SELECT * from customer order by id desc Limit 5");
        // $query = $db->query("SELECT * FROM images ORDER BY uploaded_on DESC");
                                if(count($cancel) > 0){
                                    foreach($customer as $customer_list)
                                    {                
                                        $customerid = $customer_list["customerid"];
                                        $name = $customer_list["name"];
                                        $phone = $customer_list["phone"];
                                        $email = $customer_list["email"];
                                        ?>
                                        <tr class="odd gradeX">
                                            <td><?php echo $customerid; ?></td>
                                            <td><?php  echo $name; ?></td>
                                            <td><?php  echo $phone ?></td>
                                            <td><?php  echo $email ?></td>
                                        </tr>
                                    <?php  }
                                } ?>

                            </tbody>
                        </table>
                        <!-- /.table-responsive -->

                    </div>
                    <!-- /.panel-body -->
                </div>
            </div>
            <!-- /.panel -->
        </div>
    </div>

</div>
<?php } ?>
</div>
<!-- /#page-wrapper -->

<?php include 'includes/footer.php'; ?>