<?php include("../config.php");

if(empty($_SESSION["Users_Id"]))  {
  echo "<script>window.location.href='login.php';</script>";
}
else{
  $seller_type='';
  $res = $db->getRow("select type from seller where status='A' and seller_id=".$_SESSION["Users_Id"]);
  if(isset($res['type'])){ 
    $seller_type=$res['type'];
  }
  else{
    echo "<script>window.location.href='login.php';</script>";
  }
}

$view_perm=$add_perm=$edit_perm=$del_perm=true;  

if (isset($_SESSION['success']) && ($_SESSION['success'] != "")) {
  $stat['success'] = $_SESSION['success'];
  unset($_SESSION['success']);
}
if (isset($_SESSION['error']) && ($_SESSION['error'] != "")) {
  $stat['danger'] = $_SESSION['error'];
  unset($_SESSION['error']);
}

$product_id=$_REQUEST['id'];
include('functions.php');

$save= $_POST;
// echo "<pre>";print_r($_POST);

$prod = $db->getRow("SELECT product.*,main_category.main_category_id,category.category_id FROM product left join sub_category on sub_category.sub_category_id=product.sub_category_id left join category on category.category_id=sub_category.category_id left join main_category on main_category.main_category_id=category.main_category_id where product_id=".$product_id." and product.created_by=".$_SESSION["Users_Id"]);
if( count($prod) == 0){ 
  echo "<script>window.location.href='login.php';</script>";
}   
$prod_var_grps=array();   
$res = $db->getRows("SELECT product_variant_group_id,product_id FROM product_variant_group where product_id=".$product_id." order by product_variant_group_id");
if(!empty($res)){
  foreach ($res as $key => $res1) {
    $grp=array();
    $grp['product_id']=$res1['product_id'];
    $grp['product_variant_group_id']=$res1['product_variant_group_id'];
    $prod_var_grps[]=$grp;
  }
}
// $prod_variants = $db->getRows("SELECT * FROM product_variant where product_id=".$product_id." order by product_variant_id");

if (!empty($_POST['product_id'])) {
 // $save= $_POST;
 //echo "<pre>";print_r($_POST);
  $product_id=$_POST['product_id'];
  $save=array();
  $save['name']=$_POST['name'];
  $slug=slugify($_POST['name']).'-'.$product_id;
  $save['slug']=$slug;
  $save['brand_id']=$_POST['brand_id'];
  $save['sub_category_id']=$_POST['sub_category_id'];
  $save['type']=$_POST['type'];
  $save['cancelable']=$_POST['cancelable'];
  $save['returnable']=$_POST['returnable'];
  $save['sku_code']=$_POST['sku_code'];
  $save['hsn_code']=$_POST['hsn_code'];
  $save['tax_id']=$_POST['tax_id'];
  $save['description']=$_POST['description'];
  $save['canonical_tag']=$_POST['canonical_tag'];
  $save['meta_title']=$_POST['meta_title'];
  $save['img_alt_tag']=$_POST['img_alt_tag'];
  $save['meta_desc']=$_POST['meta_desc'];
  $save['meta_keyword']=$_POST['meta_keyword'];
  $save['status']=isset($_POST['status']) && $_POST['status']!='A'?'I':'A'; 
  $save['modified_by']= $_SESSION["Users_Id"];
  $save['modified_date']= date('Y-m-d H:i:s');
  $res = $db->updateAry("product", $save, "where product_id=".$product_id);  

  $prod_var_grp = $_POST['product_variant'];
// echo "<pre>";print_r($product_variant);die;
  $var_grp_ids=array();
  if(!empty($prod_var_grp)){
    foreach ($prod_var_grp as $key => $grp) {
      if(!empty($grp)){
        if(strpos($key,'id') !== false){
          $id=str_replace('id', '', $key);
        }
        else{
          $save=array();
          $save['product_id']=$product_id;
          $id = $db->insertAry('product_variant_group',$save);              
        }
        $var_grp_ids[]=$id;  

        foreach ($grp as $variant) {
          $save=array();
          $save=$variant;
          $save['product_id']=$product_id;          
          if(isset($variant['product_variant_id']) && !empty($variant['product_variant_id'])){
            $res = $db->updateAry("product_variant", $save, "where product_variant_id=".$variant['product_variant_id']);
          }        
          else{
            $save['product_variant_group_id']=$id;
            $db->insertAry('product_variant',$save);              
          }
        }
      }      
    }
  }
  
  $del_var_grp_ids = $_POST['del_var_grp_ids'];
  if(!empty($del_var_grp_ids)){
    $res = $db->getRows("SELECT img FROM product_img where product_variant_group_id in (".$del_var_grp_ids.") order by product_img_id");
    if(!empty($res)){
      foreach ($res as $r) {
       if (!empty($r['img']))
        unlink('../uploads/product/'.$r['img']);
    }
  }

  $db->delete('product_img',"where product_variant_group_id in(".$del_var_grp_ids.")");
  $db->delete('product_variant',"where product_variant_group_id in(".$del_var_grp_ids.")");
  $db->delete('product_variant_group',"where product_variant_group_id in(".$del_var_grp_ids.")");
}

$del_att_ids = $_POST['del_att_ids'];
if(!empty($del_att_ids)){
  $db->delete('product_attribute',"where product_attribute_id in(".$del_att_ids.")");
}

$del_img_ids = $_POST['del_img_ids'];
if(!empty($del_img_ids)){
  $res = $db->getRows("SELECT img FROM product_img where product_img_id in(".$del_img_ids.") order by product_img_id");
  if(!empty($res)){ 
    foreach ($res as $key => $res1) {
      unlink('../uploads/product/'.$res1['img']);
    }      
  }

  $db->delete('product_img',"where product_img_id in(".$del_img_ids.")");
} 

$img_sno=0;
$img_grp_sno=0;

if(!empty($_FILES['img'])){
  foreach ($_FILES['img']['name'] as $key => $file) {
    if(fmod($img_sno, 6)==0 && $img_sno>0)
      $img_grp_sno++;   

    if($file != ''){
      $fname = $file;
      $ext = strtolower(substr($fname, strrpos($fname, '.') + 1));
      if (in_array($ext, array('jpeg', 'jpg', 'png','bmp'))) {
        $file_path='../uploads/product';
        if(!file_exists($file_path))
          mkdir($file_path,0777,true); 

        $tmp_file = $_FILES['img']['tmp_name'][$key];
          // $newfile = md5($tmp_file) . "." . $ext;
        $uid=rand();
        $newfile = $slug."-".$uid.".".$ext;
        if (move_uploaded_file($tmp_file, $file_path.'/'.$newfile)){
          if(strpos($key,'id') !== false){
            $id = str_replace('id', '', $key);
            $res = $db->getRow("select img from product_img where product_img_id=".$id);
            if(!empty($res)){
              unlink($file_path.'/'.$res['img']);
              $save=array();
              $save['product_variant_group_id'] = $var_grp_ids[$img_grp_sno];   
              $save['img'] = $newfile;
              $db->updateAry("product_img", $save, "where product_img_id=".$id); 
            }          
          }
          else{
            $save=array();
            $save['product_id'] = $product_id;      
            $save['product_variant_group_id'] = $var_grp_ids[$img_grp_sno];   
            $save['img'] = $newfile;    
            $db->insertAry('product_img',$save);  
          }            
        }
      }
    }
    $img_sno++;      
  }
}

// $q =$db->delete('product_attribute',"where product_id=".$product_id);
$product_attribute = $_POST['product_attribute'];
if(!empty($product_attribute)){
  foreach ($product_attribute as $key => $att) {
    if(isset($att['attribute_id']) && !empty($att['attribute_id']) && isset($att['attribute_value_ids']) && !empty($att['attribute_value_ids'])){
      $save=array();
      $save['product_id']=$product_id;
      $save['attribute_id']=$att['attribute_id'];
      $save['attribute_value_ids']=implode(",", $att['attribute_value_ids']);

      if(isset($att['product_attribute_id']) && !empty($att['product_attribute_id']))
        $res = $db->updateAry("product_attribute", $save, "where product_attribute_id=".$att['product_attribute_id']);
      else
        $db->insertAry('product_attribute',$save);
    }      
  }
}

if(!is_null($product_id))
  $_SESSION['success'] = "Product updated successfully.";
else
  $_SESSION['error'] ="Product update failed.";
// echo $db->getLastQuery(); exit;
unset($_POST);
redirect('product.php');          
}
?>
<?php include 'includes/header.php'; ?>
<link href="dist/css/img_upl.css" rel="stylesheet">
<style type="text/css">
  .avatar-upload .avatar-preview {
    width: 150px;
    height: 150px;
  }
  /*.avatar-edit{
    right: unset !important;
    }*/
    .img-col{
      padding: 0px !important;
    }
  </style>
  <div class="row">                   
    <div class="col-lg-12" style="padding-left: 0px;">
      <a href="javascript:history.go(-1)" class="btn btn-info button-addnew pull-left" style="margin-bottom:0px;margin-top: 10px;"><i class="fa fa-angle-double-left" aria-hidden="true"></i>Go Back</a>
    </div>
    <div class="col-lg-12 col-sm-12" style="padding: 0;"> 
      <div class="row panel panel-default" id="firstRow">      
        <div class="add-newproduct-tab">
          <div class="gradient-card-header">
            <h2 class="white-text mx-3">Edit Product</h2>
          </div>
        </div>
        <?php echo !empty($stat)?msg($stat):'';?>        
        <form method="post" class="frm-upd" name="doc-register" enctype="multipart/form-data">
          <div id="content" class="panel panel-default">
            <div class="panel-body add-newproduct-tab">
              <!-- prodtabs -->
              <ul class="nav nav-tabs custom-nav-tabs" id="myTab">
                <li class="active"><a id="menu_1" data-toggle="tab" href="#menu1">General</a></li>
                <li><a id="menu_2" data-toggle="tab" href="#menu2">Data</a></li>
                <li><a id="menu_3" data-toggle="tab" href="#menu3">Stock</a></li>
                <!-- <li><a data-toggle="tab" href="#menu4">Image</a></li> -->
                <li><a id="menu_4" data-toggle="tab" href="#menu4">Attributes</a></li>
                <li><a id="menu_5" data-toggle="tab" href="#menu5">SEO</a></li>
              </ul>

              <div class="tab-content">
                <div id="menu1" class="tab-pane fade in active" >
                 <br>
                 <div class="col-md-8">
                  <span class="badge-label">Product Name<span class="redstar">*</span></span>
                  <input class="form-control name" name="name" value="<?=$prod['name'];?>" placeholder="">
                </div>
                <div class="col-md-4">
                 <span class="badge-label">Brand<span class="redstar">*</span></span>
                 <select class="select form-control brand_id" name="brand_id">
                  <option value="0">Select Brand</option>
                  <?php  $res = $db->getRows("SELECT brand_id,name FROM brand order by name");
                  if( count($res) > 0){
                    foreach($res as $res1){ ?>
                      <option <?= $res1['brand_id']==$prod['brand_id']?' selected="true"':'';?> value="<?= $res1["brand_id"] ?>"><?= $res1["name"] ?></option>
                    <?php } 
                  }?>     
                </select>
              </div>  
              <div class="col-md-4 top10">
               <span class="badge-label">Main Category<span class="redstar">*</span></span>
               <select class="select form-control main_category_id" onchange="get_categories(this,this.value);">
                <option value="0">Select Main Category</option>
                <?php  $res = $db->getRows("SELECT main_category_id,name FROM main_category order by name");
                if( count($res) > 0){
                  foreach($res as $res1){ ?>
                    <option <?= $res1['main_category_id']==$prod['main_category_id']?' selected="true"':'';?> value="<?= $res1["main_category_id"] ?>"><?= $res1["name"] ?></option>
                  <?php } 
                }?>     
              </select>
            </div>
            <div class="col-md-4 top10">
              <span class="badge-label">Category<span class="redstar">*</span></span>
              <select class="select form-control category_id" onchange="get_sub_categories(this,this.value);">
                <option value="0">Select Category</option>                    
                <?php  
                $res  = $db->getRows("SELECT category_id,name FROM category where main_category_id=".$prod['main_category_id']);
                if( count($res) > 0){
                  foreach($res as $res1){ ?>
                    <option <?= $res1['category_id']==$prod['category_id']?' selected="true"':'';?> value="<?php echo $res1["category_id"] ?>"><?= $res1['name']; ?></option>
                  <?php }
                } ?>
              </select>
            </div>  
            <div class="col-md-4 top10">
              <span class="badge-label">Sub Category<span class="redstar">*</span></span>
              <select name="sub_category_id" class="select form-control sub_category_id" onchange="get_attrs(this,this.value);">
                <option value="0">Select Sub Category</option>
                <?php  
                $res  = $db->getRows("SELECT sub_category_id,name FROM sub_category where category_id=".$prod['category_id']);
                if( count($res) > 0){
                  foreach($res as $res1){ ?>
                    <option <?= $res1['sub_category_id']==$prod['sub_category_id']?' selected="true"':'';?> value="<?php echo $res1["sub_category_id"] ?>"><?= $res1['name']; ?></option>
                  <?php }
                } ?>             
              </select>
            </div>
            <div class="col-md-4 top10">            
              <div class="form-group">
               <span class="badge-label">Type<span class="redstar">*</span></span><br/>
               <div class="radio">
                <label>
                  <input type="radio" class="prod-type" name="type" value="P" <?= $prod['type']=='P'?'checked':'';?> >Packet
                </label>
              </div>
              <div class="radio">
                <label>
                  <input type="radio" class="prod-type" name="type" value="L" <?= $prod['type']=='L'?'checked':'';?>>Loose
                </label>
              </div>              
            </div>
          </div>
          <div class="col-md-4 top10">            
            <div class="form-group">
             <span class="badge-label">Cancelable<span class="redstar">*</span></span><br/>
             <div class="radio">
              <label>
                <input type="radio" class="cancelable" name="cancelable" value="Y" <?= $prod['cancelable']=='Y'?'checked':'';?>>Yes
              </label>
            </div>
            <div class="radio">
              <label>
                <input type="radio" class="cancelable" name="cancelable" value="N" <?= $prod['cancelable']=='N'?'checked':'';?>>No
              </label>
            </div>              
          </div>
        </div>
        <div class="col-md-4 top10">            
          <div class="form-group">
           <span class="badge-label">Returnable<span class="redstar">*</span></span><br/>
           <div class="radio">
            <label>
              <input type="radio" class="returnable" name="returnable" value="Y" <?= $prod['returnable']=='Y'?'checked':'';?>>Yes
            </label>
          </div>
          <div class="radio">
            <label>
              <input type="radio" class="returnable" name="returnable" value="N" <?= $prod['returnable']=='N'?'checked':'';?>>No
            </label>
          </div>              
        </div>        
      </div>
      <div class="col-md-4 top10">
        <span class="badge-label p-2">Status</span>
        <div class="switch top10">
          <label>Inactive
            <input type="checkbox" <?= $prod['status']=='A'?'checked':'';?> name="status" value="A" >
            <span class="lever"></span> Active
          </label>
        </div>
      </div>
      <br/>
    </div>
    <div id="menu2" class="tab-pane fade">
      <br/> 
      <div class="col-md-4">
        <span class="badge-label">Product SKU ID</span>
        <input placeholder="" class="form-control sku_code" name="sku_code" value="<?=$prod['sku_code'];?>" >
        <br/>
      </div>
      <div class="col-md-4">
        <span class="badge-label">HSN Code</span>
        <input placeholder="" class="form-control hsn_code" name="hsn_code" value="<?=$prod['hsn_code'];?>" >
        <br/>
      </div>
      <div class="col-md-4">
        <span class="badge-label">Tax</span>
        <select class="select form-control tax_id" name="tax_id">
          <option value="0">Select</option>
          <?php  $res = $db->getRows("SELECT tax_id,name FROM tax order by name");
          if( count($res) > 0){
            foreach($res as $res1){ ?>
              <option <?= $res1['tax_id']==$prod['tax_id']?' selected="true"':'';?> value="<?= $res1["tax_id"] ?>"><?= $res1["name"] ?></option>
            <?php } 
          }?>     
        </select>
        <br/>
      </div>
      <div class="col-md-12">
        <span class="badge-label">Description</span>
        <textarea class="content" name="description"><?=$prod['description'];?></textarea>
        <br/>
      </div>
    </div>
    <div id="menu3" class="tab-pane fade">
      <br/>
      <div class="panel-body" id="variant_cont">
       <?php if(!empty($prod_var_grps)) { 
        $var_sno=0;
        foreach ($prod_var_grps as $grp_key => $prod_var_grp) { ?>
          <div class="field_wrapper">
            <div class="row" style="display: flex;">
              <div class="col-md-11">
                <?php 
                for ($var_sno1=0; $var_sno1 < strlen($seller_type); $var_sno1++) {   
                $row_type=$seller_type[$var_sno1];          
                  if($row_type=='W')
                    $cap='Whole Sale (B2B)';
                  elseif($row_type=='S')
                    $cap='Semi Whole Sale (B2B)';
                  elseif($row_type=='R')
                    $cap='Retail (B2C)';
                  $prod_variant = $db->getRow("SELECT * FROM product_variant where product_id=".$product_id." and product_variant_group_id=".$prod_var_grp['product_variant_group_id']." and type='".$row_type."'");
                 // echo $db->getLastQuery();  exit;
                  // print_r($prod_variant);die;
                  ?>
                  <button type="button"  class="collapsible collapsebtn var-row btn-r"><?=$cap?></button>
                  <div class="divStockContent">
                    <br/>
                    <div class="row">
                      <div class="col-md-3">
                        <span class="badge-label ">Measurement Qty<span class="redstar">*</span></span>
                        <input class="form-control price_qty" onkeypress="return isNumber(event)" name="product_variant[id<?=$prod_var_grp['product_variant_group_id']?>][<?=$var_sno?>][price_qty]" value="<?=!empty($prod_variant['price_qty'])?$prod_variant['price_qty']:''?>">
                      </div>
                      <div class="col-md-3">
                        <span class="badge-label ">Measurement Unit<span class="redstar">*</span></span>
                        <select class="select form-control price_unit_id" name="product_variant[id<?=$prod_var_grp['product_variant_group_id']?>][<?=$var_sno?>][price_unit_id]">
                          <option value="0">Select</option>
                          <?php  $res = $db->getRows("SELECT unit_id,name FROM unit order by name");
                          if( count($res) > 0){
                            foreach($res as $res1){ ?>
                              <option <?= !empty($prod_variant['price_unit_id']) && $res1['unit_id']==$prod_variant['price_unit_id']?' selected="true"':'';?> value="<?= $res1["unit_id"] ?>"><?= $res1["name"] ?></option>
                            <?php } 
                          }?>     
                        </select>
                      </div>
                      <div class="col-md-3">
                        <span class="badge-label ">Price<span class="redstar">*</span></span>
                        <input class="form-control price disc_calc" onkeypress="return isNumber(event)" value="<?=!empty($prod_variant['price'])?$prod_variant['price']:''?>" name="product_variant[id<?=$prod_var_grp['product_variant_group_id']?>][<?=$var_sno?>][price]">
                      </div>
                      <div class="clearfix"></div>
                      <div class="col-md-3 top10">
                        <span class="badge-label">Discount Type</span>
                        <select class="select form-control disc_type" onchange="calc_disc(this);" name="product_variant[id<?=$prod_var_grp['product_variant_group_id']?>][<?=$var_sno?>][disc_type]">
                          <option value="0" <?= !empty($prod_variant['disc_type']) && $prod_variant['disc_type']=="0"?' selected="true"':'';?>>Select</option>
                          <option value="P" <?= !empty($prod_variant['disc_type']) && $prod_variant['disc_type']=="P"?' selected="true"':'';?>>Percent</option>
                          <option value="A" <?= !empty($prod_variant['disc_type']) && $prod_variant['disc_type']=="A"?' selected="true"':'';?>>Amount</option>
                        </select>
                      </div>
                      <div class="col-md-3 top10">
                        <span class="badge-label ">Discount Amount</span>
                        <input class="form-control disc_amt disc_calc" onkeypress="return isFracNumber(event)" name="product_variant[id<?=$prod_var_grp['product_variant_group_id']?>][<?=$var_sno?>][disc_amt]" value="<?=!empty($prod_variant['disc_amt'])?$prod_variant['disc_amt']:''?>">
                      </div>
                      <div class="col-md-3 top10">
                        <span class="badge-label ">Discounted Price</span>
                        <input class="form-control discounted_price" readonly="true" onkeypress="return isNumber(event)" name="product_variant[id<?=$prod_var_grp['product_variant_group_id']?>][<?=$var_sno?>][discounted_price]" value="<?=!empty($prod_variant['discounted_price'])?$prod_variant['discounted_price']:''?>">
                      </div>
                      <div class="clearfix"></div>
                      <div class="col-md-3 top10">
                        <span class="badge-label ">Stock Qty<span class="redstar">*</span></span>
                        <input class="form-control stock_qty" onkeypress="return isNumber(event)" name="product_variant[id<?=$prod_var_grp['product_variant_group_id']?>][<?=$var_sno?>][stock_qty]" value="<?=!empty($prod_variant['stock_qty'])?$prod_variant['stock_qty']:''?>">
                      </div>
                      <div class="col-md-3 top10">
                        <span class="badge-label ">Stock Unit<span class="redstar">*</span></span>
                        <select class="select form-control stock_unit_id" name="product_variant[id<?=$prod_var_grp['product_variant_group_id']?>][<?=$var_sno?>][stock_unit_id]">
                          <option value="0">Select</option>
                          <?php  $res = $db->getRows("SELECT unit_id,name FROM unit order by name");
                          if( count($res) > 0){
                            foreach($res as $res1){ ?>
                              <option <?= !empty($prod_variant['stock_unit_id']) && $res1['unit_id']==$prod_variant['stock_unit_id']?' selected="true"':'';?> value="<?= $res1["unit_id"] ?>"><?= $res1["name"] ?></option>
                            <?php } 
                          }?>     
                        </select>
                      </div>
                      <div class="col-md-3 top10">
                        <span class="badge-label ">Stock Status<span class="redstar">*</span></span>
                        <select class="select form-control" name="product_variant[id<?=$prod_var_grp['product_variant_group_id']?>][<?=$var_sno?>][stock_status]">
                          <option <?= !empty($prod_variant['stock_status']) && $prod_variant['stock_status']=="SO"?' selected="true"':'';?> value="AV">Available</option>
                          <option <?= !empty($prod_variant['stock_status']) && $prod_variant['stock_status']=="AV"?' selected="true"':'';?> value="SO">Sold Out</option>
                          <option <?= !empty($prod_variant['stock_status']) && $prod_variant['stock_status']=="NA"?' selected="true"':'';?> value="NA">Not Available</option>
                          <option <?= !empty($prod_variant['stock_status']) && $prod_variant['stock_status']=="SC"?' selected="true"':'';?> value="SC">Shop Closed</option>
                        </select>
                      </div>
                      <div class="clearfix"></div>
                      <div class="col-md-3 top10">
                        <span class="badge-label ">Min.Order Qty</span>
                        <input class="form-control min_order_qty" onkeypress="return isNumber(event)" name="product_variant[id<?=$prod_var_grp['product_variant_group_id']?>][<?=$var_sno?>][min_order_qty]" value="<?=!empty($prod_variant['min_order_qty'])?$prod_variant['min_order_qty']:''?>">
                      </div> 
                      <div class="col-md-3 top10">
                        <span class="badge-label ">Delivery Time</span>
                        <div class="row">
                          <div class="col-md-6" style="padding-right: 0;">                      
                            <input style1="display: inline-block;width: 50% !important;position: relative;" class="form-control deliv_time" onkeypress="return isNumber(event)" name="product_variant[id<?=$prod_var_grp['product_variant_group_id']?>][<?=$var_sno?>][deliv_time]" value="<?=!empty($prod_variant['deliv_time'])?$prod_variant['deliv_time']:''?>">
                          </div>
                          <div class="col-md-6">
                            <select style1="display: inline-block;width: 50% !important;position: relative;" class="select form-control deliv_time_type" name="product_variant[id<?=$prod_var_grp['product_variant_group_id']?>][<?=$var_sno?>][deliv_time_type]">
                              <option <?= !empty($prod_variant['deliv_time_type']) && $prod_variant['deliv_time_type']=="0"?' selected="true"':'';?> value="0">Select</option>
                              <option <?= !empty($prod_variant['deliv_time_type']) && $prod_variant['deliv_time_type']=="H"?' selected="true"':'';?> value="H">Hours</option>
                              <option <?= !empty($prod_variant['deliv_time_type']) && $prod_variant['deliv_time_type']=="D"?' selected="true"':'';?> value="D">Days</option>
                              <option <?= !empty($prod_variant['deliv_time_type']) && $prod_variant['deliv_time_type']=="W"?' selected="true"':'';?> value="W">Weeks</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-3 top10">
                        <span class="badge-label ">Delivery Charge</span>
                        <input class="form-control deliv_charge" onkeypress="return isNumber(event)" name="product_variant[id<?=$prod_var_grp['product_variant_group_id']?>][<?=$var_sno?>][deliv_charge]" value="<?=!empty($prod_variant['deliv_charge'])?$prod_variant['deliv_charge']:''?>">
                      </div>
                      <div class="col-md-3 top10">            
                        <div class="form-group">
                         <span class="badge-label">COD Available<span class="redstar">*</span></span><br/>
                         <div class="radio">
                          <label>
                            <input type="radio" class="cod_available" name="product_variant[id<?=$prod_var_grp['product_variant_group_id']?>][<?=$var_sno?>][cod_available]" value="Y" <?= (!empty($prod_variant['cod_available']) && $prod_variant['cod_available']=="Y" || empty($prod_variant['cod_available']))?'checked':'';?>>Yes
                          </label>
                        </div>
                        <div class="radio">
                          <label>
                            <input type="radio" class="cod_available" name="product_variant[id<?=$prod_var_grp['product_variant_group_id']?>][<?=$var_sno?>][cod_available]" value="N" <?= !empty($prod_variant['cod_available']) && $prod_variant['cod_available']=="N"?'checked':'';?>>No
                          </label>
                        </div>              
                      </div>
                      <input type="hidden" name="product_variant[id<?=$prod_var_grp['product_variant_group_id']?>][<?=$var_sno?>][type]" value="<?=$row_type?>">
                      <input type="hidden" name="product_variant[id<?=$prod_var_grp['product_variant_group_id']?>][<?=$var_sno?>][product_variant_id]" value="<?=!empty($prod_variant['price'])?$prod_variant['product_variant_id']:''?>">
                    </div>
                  </div>
                  <br/>
                </div>
                <?php $var_sno++;} ?>   
                <button type="button" class="collapsible collapsebtn">Add Images </button>
                <div class="divStockContent" style="overflow-y:scroll;">
                  <br/>
                  <div class="row">
                    <?php $img_sno=0;
                    $res = $db->getRows("SELECT * FROM product_img where product_id=".$product_id." and product_variant_group_id=".$prod_var_grp['product_variant_group_id']." order by product_img_id");
                    if(!empty($res)){
                      foreach($res as $key => $res1){?>
                       <div class="col-md-2 top20 img-col">
                        <div class="avatar-upload">
                          <div class="avatar-edit">
                            <input type='file' name="img[id<?php echo $res1['product_img_id'];?>]" id="img<?=$res1['product_img_id'].'-'.$key;?>" multiple class="img" accept=".png, .jpg, .jpeg, .bmp" />
                            <label for="img<?=$res1['product_img_id'].'-'.$key;?>"><i class="fa fa-pencil-alt"></i></label>
                          </div>
                          <div class="avatar-preview">
                            <div class="imagePreview" style="background-image: url(<?php echo '../uploads/product/'.$res1['img'];?>);">
                              <button type="button" data-id="<?php echo $res1['product_img_id'];?>" class='del-img remove'><i class='fa fa-times'></i></button>
                            </div>
                          </div>
                        </div>
                      </div>                
                      <?php $img_sno++;}
                    }
                    ?>
                    <?php for ($i=$img_sno; $i <=5 ; $i++) {  $uid=rand();?>
                     <div class="col-md-2 top20 img-col">
                      <div class="avatar-upload">
                        <div class="avatar-edit">
                          <input type='file' class="img" id="img<?=$uid?>" name="img[]" multiple accept=".png, .jpg, .jpeg, .bmp" />
                          <label for="img<?=$uid?>"><i class="fa fa-pencil-alt"></i></label>
                        </div>
                        <div class="avatar-preview">
                          <div class="imagePreview" style="background-image: url(img/pl_hold_img.png);">
                          </div>
                        </div>
                      </div>
                    </div>       
                  <?php } ?>
                </div>       
              </div>      
            </div>
            <?php if($grp_key>0) { ?>  
              <div class="col-md-1" style="align-self: center;text-align: center;"><button type="button" data-id="<?=$prod_var_grp['product_variant_group_id']?>" class="rem_variant btn btn-danger btn-circle" title="Remove Product Variant"><i class="far fa-trash-alt" ></i></button>
              </div>
            <?php } ?>
          </div> <!-- Row ends -->
          <br>
        </div> <!-- Field wrapper -->
      <?php } ?>
    <?php } ?>
    <div class="row" id="add-variant-cont">
      <div class="col-md-12" style="background-color: #ebebeb; border: 1px dashed #122171;margin-top: 1em; padding: 3px 15px;">
        <div class="pull-right">
          <button type="button" class="btn btn-primary btn-circle btn-lg add_variant" title="Add Product Variant"><i class="fa fa-plus" ></i></button>
        </div>
      </div>
    </div>
  </div> <!-- panel-body -->
  <br/>
  <input type="hidden" id="var_grp_sno" value="<?=count($prod_var_grps)-1;?>">
</div>
<div id="menu4" class="tab-pane fade">
  <?php $res = $db->getRows("SELECT * FROM product_attribute where product_id=".$product_id." order by product_attribute_id"); 
  
  $atts  = $db->getRows("SELECT attribute_map.attribute_id,attribute.name FROM attribute_map left join attribute on attribute.attribute_id=attribute_map.attribute_id where attribute_map.sub_category_id=".$prod['sub_category_id']." order by attribute.name");

  $sno=0;
  if(!empty($res)){
    foreach($res as $key => $res1){      
      $res2 = $db->getRow("SELECT attribute_value_ids FROM attribute_map where attribute_id=".$res1['attribute_id']." and sub_category_id=".$prod['sub_category_id']);

      if(!empty($res2)){
        $att_vals  = $db->getRows("SELECT attribute_value_id,attr_value FROM attribute_value where attribute_value_id in(".$res2['attribute_value_ids'].")");  
      }  

      $att_val_ids =','.$res1['attribute_value_ids'].',';
      ?>
      <div class="col-md-12 divProductAttributes">
        <div class="col-md-4" id="divAttrId">
          <span class="badge-label p-2">Attribute</span>
          <select name="product_attribute[<?=$sno?>][attribute_id]" data-sno="<?=$sno?>" class="select form-control attribute_id" onchange="get_attr_vals(this,this.value)">
            <option value="0">Select Attribute</option>
            <?php if( count($atts) > 0){
              foreach($atts as $att){ ?>
                <option <?= $res1['attribute_id']==$att['attribute_id']?' selected="true"':'';?> value="<?php echo $att["attribute_id"] ?>"><?= $att['name']; ?></option>
              <?php }
            } ?>                  
          </select>
        </div>
        <div class="col-md-4">
          <span class="badge-label p-2">Values</span>
          <div class="addToListListBox form-control attribute_value_ids" style1="display: none;">
            <?php if( count($att_vals) > 0){
              foreach($att_vals as $att_val){ $id=uniqid(time(), true); ?>
                <div class="pure-checkbox">
                  &nbsp;<input type="checkbox" <?=strpos($att_val_ids,','.$att_val['attribute_value_id'].',') !== false?'checked':'';?> id="attribute_value_ids<?php echo $id ?>" value="<?php echo $att_val['attribute_value_id']?>" class="attribute_value_opts" style="opacity:2" name="product_attribute[<?=$sno?>][attribute_value_ids][]"><label for="attribute_value_ids<?php echo $id ?>"><?php echo $att_val['attr_value'];?></label>
                </div>
              <?php }
            } ?>            
          </div>      
        </div> 
        <div class="col-md-1" style="align-self: center;text-align: center;"><button type="button" data-id="<?php echo $res1['product_attribute_id'];?>" class="rem_attr btn btn-danger btn-circle" title="Remove Attribute"><i class="far fa-trash-alt" ></i></button>
        </div> 
        <input type="hidden" name="product_attribute[<?=$sno?>][product_attribute_id]" value="<?=$res1['product_attribute_id']?>">
      </div>
      <?php $sno++;} ?> 
    <?php }else{ ?>   
     <div class="col-md-12 divProductAttributes">
      <div class="col-md-4" id="divAttrId">
        <span class="badge-label p-2">Attribute</span>
        <select name="product_attribute[0][attribute_id]" class="select form-control attribute_id" data-sno="0" onchange="get_attr_vals(this,this.value)">
          <option value="0">Select Attribute</option> 
          <?php if( count($atts) > 0){
            foreach($atts as $att){ ?>
              <option value="<?php echo $att["attribute_id"] ?>"><?= $att['name']; ?></option>
            <?php }
          } ?>                         
        </select>
      </div>
      <div class="col-md-4">
        <span class="badge-label p-2">Values</span>
        <div class="addToListListBox form-control attribute_value_ids" style1="display: none;"></div>      
      </div>    
    </div>
  <?php } ?>   

  <div class="col-md-12" id="add-attr-cont" style="background-color: #ebebeb; border: 1px dashed #122171;margin-top: 1em; padding: 3px 15px;margin-bottom: 10px">
    <div class="pull-right">
      <button type="button" data-sno="<?=$sno?>" class="btn btn-primary btn-circle btn-lg add_attr" title="Add Attribute"><i class="fa fa-plus" ></i></button>
    </div>
  </div>  
</div>
<div id="menu5" class="tab-pane fade divSeoContent">
  <br/><br/>
  <div class="col-md-7 col-md-offset-2">
    <span class="badge-label p-2">Canonical Tag</span>
    <textarea class="form-control canonical_tag" name="canonical_tag"  placeholder="Canonical page link" ><?=$prod['canonical_tag'];?></textarea>
    <br/>
  </div>
  <div class="clearfix"></div>
  <div class="col-md-7 col-md-offset-2">
    <span class="badge-label p-2">Meta Title</span>
    <textarea title="<title tag Content >" class="form-control meta_title" rows="2" name="meta_title" placeholder="<title tag Content >"  maxlength="90"><?=$prod['meta_title'];?></textarea>
      <span class="note-text">Note : Character Length 55 to 90.</span>

    </div>
    <div class="clearfix"></div>
    <div class="col-md-7 col-md-offset-2">
      <span class="badge-label p-2">Image Alt Tag</span>
      <textarea title="Image Alt tag content here" class="form-control img_alt_tag" name="img_alt_tag" placeholder="<alt tag Content >"  ><?=$prod['img_alt_tag'];?></textarea>
        <br/>
      </div>  
      <div class="clearfix"></div>  
      <div class="col-md-10 col-md-offset-2">
        <span class="badge-label p-2">Meta Description</span>
        <textarea title="Maximum 200 Characters" class="form-control meta_desc" rows="3" name="meta_desc"  placeholder="<meta Description >" maxlength="220"><?=$prod['meta_desc'];?></textarea>
        <span class="note-text">Note : Character Length 150 to 220.</span>

      </div>
      <div class="col-md-10 col-md-offset-2">
        <span class="badge-label p-2">Meta Keywords</span>
        <textarea title="Maximum 30 Keywords" class="form-control meta_keyword" rows="3" name="meta_keyword" placeholder="<meta Keywords >"  maxlength="255"><?=$prod['meta_keyword'];?></textarea>
        <span class="note-text">Note : Maximum 30 Keywords ( Separate by comma ' , ' )</span>
      </div>    
    </div>
  </div>
  <!-- /prodtabs -->
  <div class="col-md-12">
    <div class="pull-right">
      <label class="err_lbl"></label>&nbsp;&nbsp;
      <button class="btn blue-gradient button-save btn-save" title="Save" type="button" name="saveGroup"><i class="fa fa-check" aria-hidden="true"></i> Update</button>
      <a href="javascript:history.go(-1)" title="Cancel" class="btn danger-gradient button-cancel"><i class="fa fa-times" aria-hidden="true"></i> Cancel</a>
      <input type="hidden" name="product_id" value="<?= $product_id; ?>">      
      <input type="hidden" name="del_img_ids" id="del_img_ids" value="0">   
      <input type="hidden" name="del_var_grp_ids" id="del_var_grp_ids" value="0">   
      <input type="hidden" name="del_att_ids" id="del_att_ids" value="0">   
    </div>
  </div>
</div>
</div>
</form>
</div>          
</div>
</div> 
<?php include 'includes/footer.php'; ?>
<script src="src/jquery.richtext.js"></script>
<script>  
 function readURL(input) {  
  $tis=$(input);
  if (input.files && input.files[0]) {
    var extension = input.files[0].name.split('.').pop().toLowerCase();
    var reader = new FileReader();
    reader.onload = function(e) {
      $tis.parent().parent().find('.imagePreview').css('background-image', 'url('+e.target.result +')');
      $tis.parent().parent().find('.imagePreview').hide();
      $tis.parent().parent().find('.imagePreview').fadeIn(650);
    }
    reader.readAsDataURL(input.files[0]);
  }
}
$(".img").change(function() {
  readURL(this);
});
$(document).ready(function(){
  $('.select').select2();
  $('.content').richText();
  $("#btn_add").click(function(){
    $("#content").toggle();
    $(this).find(".fa-angle-down").toggleClass('fa-angle-up');
  });    
  $('#data_table').DataTable({
    "scrollX": true,
    "columnDefs": [
    { "orderable": false, "targets": [7]},
    { "orderable": true, "targets": [0,1,2,3,4,5,6]},
    {"visible": false, "targets": [0]}
    ],
    "order": [[ 0, "asc" ]],
    "rowReorder" : [ "dataSrc", [1]]
  });    
});
$( ".btn_edit" ).click(function( event ) {
  event.preventDefault();

  var id =$(this).attr('data-id');
  $.ajax({
    url: 'aj_edit_prod.php?id='+id,
    dataType: 'html'
  })
  .done(function(data){      
    $('#upd').empty().append(data);
    $('#btn_upd').attr('data-id',id);
  })
  $('#mod_data').find('.err_lbl').html('');
  $('#mod_data').modal('show');
  return false;
});  
function del_confirm(e) {
  var id = e.value;
  $.confirm({
    icon: 'fa fa-warning',
    title: 'Confirm!',
    content: 'Do you want to Delete ?',
    type: 'red',
    buttons: {
      confirm:  {
        btnClass: 'btn-red',
        action: function(){
          $.confirm({
            icon: 'fa fa-warning',
            title: 'Confirm!',
            content: 'If you Delete, You cant restore this record !',
            type: 'red',
            buttons: {
              Okay: {
                btnClass: 'btn-red',
                action: function(){
                  $.ajax({
                    type: 'post',
                    url: 'aj_data.php',
                    data: 'action=del_setting&type=product&id='+id,
                    dataType: "json",
                    success: function (data) {
                      if(data['validation'] == '1'){
                       window.location.reload();
                     }
                     else{
                      $.alert(data['message']);
                    }
                  }
                });
                }
              },
              Cancel: function () { },
            }
          });
        }
      },
      cancel: function () { },
    }
  });
}  
$(document).on('input', '.disc_calc', function() {  
  calc_disc(this);
});

function calc_disc(ele){
  $tis=$(ele);  
  $price = $.trim($tis.parent().parent().find('.price').val());
  $disc_type = $tis.parent().parent().find('.disc_type').val();
  $disc_amt = $.trim($tis.parent().parent().find('.disc_amt').val());

  if($price=='')
    $price=0;

  if($disc_amt=='')
    $disc_amt=0;

  $amt =0;
  if($disc_type=='P'){
    $amt = $price * $disc_amt/100;
  }
  else if($disc_type=='A'){
    $amt = $disc_amt;
  }

  $discounted_price = $price-$amt;
  if($discounted_price<0)
    $discounted_price=0;

  $tis.parent().parent().find('.discounted_price').val($discounted_price);
}
$(document).on('click','.btn-save',function(e){    
  $err_lbl= $(this).parent().find('.err_lbl');
  $err_lbl.html('');
  $id='<?=$product_id?>';
  $frm = $('.frm-upd');

  $val = '';
  $frm.find('input:text').each(function(){
    $(this).val($.trim($(this).val()));
  });

  $name=$frm.find('.name').val();

  if($name ==''){
    $err_lbl.html('Please enter name!');
    return false;
  }      

  $brand_id=$frm.find('.brand_id').val();
  if($brand_id ==0){
    $err_lbl.html('Please select Brand!');
    return false;
  }

  $main_category_id=$frm.find('.main_category_id').val();
  if($main_category_id ==0){
    $err_lbl.html('Please select Main category!');
    return false;
  }

  $category_id=$frm.find('.category_id').val();
  if($category_id ==0){
    $err_lbl.html('Please select Category!');
    return false;
  }
  $sub_category_id=$frm.find('.sub_category_id').val();
  if($sub_category_id ==0){
    $err_lbl.html('Please select Sub category!');
    return false;
  }

 //  $tax_percent=$frm.find('.tax_percent').val();
 //  if($tax_percent=='')
 //    $tax_percent=0;

 //  if(parseFloat($tax_percent)>=100){
 //   $('#menu_2').click();
 //   $err_lbl.html('Invalid Tax percent!');
 //   return false;
 // } 

 $err =0;
 $(".divStockContent").css('max-height','0px');
 $(".divStockContent").each(function() {
  $val = $(this).find(".price_qty").val();
  if($val ==''){
    $('#menu_3').click();
    $err_lbl.html('Please enter Measurement Qty!');      
    $ele=$(this);
    setTimeout(
      function() 
      {
       $ele.css('max-height',$ele[0].scrollHeight+'px');
     }, 200);

    $err=1;
    return false;
  }
  $val = $(this).find(".price_unit_id").val();
  if($val ==0){
    $('#menu_3').click();
    $err_lbl.html('Please select Measurement Unit!');      
    $ele=$(this);
    setTimeout(
      function() 
      {
       $ele.css('max-height',$ele[0].scrollHeight+'px');
     }, 200);

    $err=1;
    return false;
  }
  $val = $(this).find(".price").val();
  if($val ==''){
    $('#menu_3').click();
    $err_lbl.html('Please enter Price!');      
    $ele=$(this);
    setTimeout(
      function() 
      {
       $ele.css('max-height',$ele[0].scrollHeight+'px');
     }, 200);

    $err=1;
    return false;
  }

  $disc_type = $(this).find(".disc_type").val();
  $disc_amt = $(this).find(".disc_amt").val();
  $disc_type = $(this).find(".disc_type").val();

  if ($disc_amt =='')
   $disc_amt=0;

 if($disc_type!='0'){
  if($disc_amt==0){
   $('#menu_3').click();
   $err_lbl.html('Please enter Discount Amount!');      
   $ele=$(this);
   setTimeout(
    function() 
    {
     $ele.css('max-height',$ele[0].scrollHeight+'px');
   }, 200);

   $err=1;
   return false;
 }
 else{
  if($disc_type=='P' && $disc_amt>100){
   $('#menu_3').click();
   $err_lbl.html('Invalid Discount %!');      
   $ele=$(this);
   setTimeout(
    function() 
    {
     $ele.css('max-height',$ele[0].scrollHeight+'px');
   }, 200);

   $err=1;
   return false;
 }
}
}
else{
  if($disc_amt>0){
   $('#menu_3').click();
   $err_lbl.html('Please select Discount type!');      
   $ele=$(this);
   setTimeout(
    function() 
    {
     $ele.css('max-height',$ele[0].scrollHeight+'px');
   }, 200);

   $err=1;
   return false;
 }
}

if(parseFloat($disc_amt) >parseFloat($val) && $disc_type=='A'){
  $('#menu_3').click();
  $err_lbl.html('Discount amount exceeds price!');      
  $ele=$(this);
  setTimeout(
    function() 
    {
     $ele.css('max-height',$ele[0].scrollHeight+'px');
   }, 200);

  $err=1;
  return false;
}
$val = $(this).find(".discounted_price").val();
if($val ==''){
  $('#menu_3').click();
  $err_lbl.html('Please enter Discounted Price!');      
  $ele=$(this);
  setTimeout(
    function() 
    {
     $ele.css('max-height',$ele[0].scrollHeight+'px');
   }, 200);

  $err=1;
  return false;
}
$val = $(this).find(".stock_qty").val();
if($val ==''){
  $('#menu_3').click();
  $err_lbl.html('Please enter Stock Qty!');      
  $ele=$(this);
  setTimeout(
    function() 
    {
     $ele.css('max-height',$ele[0].scrollHeight+'px');
   }, 200);

  $err=1;
  return false;
}
$val = $(this).find(".stock_unit_id").val();
if($val ==0){
  $('#menu_3').click();
  $err_lbl.html('Please select Stock Unit!');      
  $ele=$(this);
  setTimeout(
    function() 
    {
     $ele.css('max-height',$ele[0].scrollHeight+'px');
   }, 200);

  $err=1;
  return false;
}

$deliv_time = $(this).find(".deliv_time").val();
$deliv_time_type = $(this).find(".deliv_time_type").val();

if($deliv_time!='' && $deliv_time_type=='0'){
 $('#menu_3').click();
 $err_lbl.html('Please select Delivery time type!');      
 $ele=$(this);
 setTimeout(
  function() 
  {
   $ele.css('max-height',$ele[0].scrollHeight+'px');
 }, 200);

 $err=1;
 return false;
}
else if($deliv_time=='' && $deliv_time_type!='0'){
  $('#menu_3').click();
  $err_lbl.html('Please enter Delivery time!');      
  $ele=$(this);
  setTimeout(
    function() 
    {
     $ele.css('max-height',$ele[0].scrollHeight+'px');
   }, 200);

  $err=1;
  return false;
}
});

if($err==1)
    return false;

 $(".attribute_id").each(function() {
  $tis=$(this);
  $val = $tis.val();
  $sno=$tis.attr('data-sno');
  if($val!=0){
    var $txt = $("option:selected",this).text();
    $(".attribute_id").each(function() {
      $val1 = $(this).val();
      $sno1=$(this).attr('data-sno');
      if($val==$val1 && $sno!=$sno1){
        $('#menu_4').click();
        $err_lbl.html($txt+' Attribute already selected!');      
        $ele=$(this);
        setTimeout(
          function() 
          {
           $ele.css('max-height',$ele[0].scrollHeight+'px');
         }, 200);

        $err=1;
        return false;
      }
    }); 

    if($err!=1){
      if ($tis.parent().parent().find('.attribute_value_opts:checked').length ==0) {
        $('#menu_4').click();
        $err_lbl.html($txt+' Attribute values not selected!');      
        $ele=$tis;
        setTimeout(
          function() 
          {
           $ele.css('max-height',$ele[0].scrollHeight+'px');
         }, 200);

        $err=1;
        return false;
      }  
    }
  }   
});    
 if($err==1)
  return false;

$.ajax({
  url : "aj_data.php",
  data: 'action=chk_dup&type=product&chk_fld=name&chk_val='+$name+'&chk_fld1=sub_category_id&chk_val1='+$sub_category_id+'&chk_id='+$id,
  success: function(res){
    res =$.trim(res);
    if(res=='E')
      $err_lbl.html('Product already exists!');
    else{
        // alert($frm.attr('name'));
        $frm.submit();
      }

    }
  }); 
}); 
function get_categories(ele,id)
{
  $tis=$(ele);
  $tis.parent().parent().find(".category_id").html(''); 
  $tis.parent().parent().find(".sub_category_id").html('<option value="0">Select Sub Category</option>'); 
  $tis.parent().parent().parent().find(".attribute_id").html('<option value="0">Select Attribute</option>');
  $tis.parent().parent().parent().find(".attribute_value_ids").html('');
  $.ajax({
    type: "POST",
    url : "aj_data.php",
    data: 'action=get_categories&main_category_id='+id,
    success: function(msg){
     $tis.parent().parent().find(".category_id").html(msg); 
   }
 });
}
function get_sub_categories(ele,id)
{
  $tis=$(ele);
  $tis.parent().parent().find(".sub_category_id").html(''); 
  $tis.parent().parent().parent().find(".attribute_id").html('<option value="0">Select Attribute</option>');
  $tis.parent().parent().parent().find(".attribute_value_ids").html('');
  $.ajax({
    type: "POST",
    url : "aj_data.php",
    data: 'action=get_sub_categories&category_id='+id,
    success: function(msg){
     $tis.parent().parent().find(".sub_category_id").html(msg); 
   }
 });
}
$(document).on('click', '.collapsible', function()
{
  // var coll = document.getElementsByClassName("collapsebtn");
  // var i;
  this.classList.toggle("active1");
  $ele=$(this).next();
  if($ele.css('max-height')=='0px')
    $ele.css('max-height',$ele[0].scrollHeight+'px');
  else
    $ele.css('max-height','0px');

        // $('.divStockContent').maxHeight = null;
       // $(this).next().style.maxHeight = ($(this).next().scrollHeight+20) + "px";        
        // for (i = 0; i < coll.length; i++) {
        //   //coll[i].addEventListener("click", function() {
        //     this.classList.toggle("active1");
        //   // alert(this.classList);
        //     var contentC = this.nextElementSibling;
        //     if (contentC.style.maxHeight){
        //       contentC.style.maxHeight = null;
        //     } else {
        //       contentC.style.maxHeight = (contentC.scrollHeight+20) + "px";
        //     } 
        //   //});
        // }
      });

$('.add_variant').click(function(e){
  $var_grp_sno = parseFloat($('#var_grp_sno').val())+1;
  $seller_type='<?=$seller_type?>';
  $var_sno = $('.var-row').length;
  $.ajax({
    url : "aj_data.php",
    data: 'action=add_prod_variant&var_grp_sno='+$var_grp_sno+'&var_sno='+$var_sno+'&seller_type='+$seller_type,
    success: function(res){
      res =$.trim(res);
      $(res).insertBefore($("#add-variant-cont"));
      $('#var_grp_sno').val($var_grp_sno);
    }
  }); 
});
$('.add_attr').click(function(e){
 $sno = parseFloat($(this).attr('data-sno'));
 $sub_category_id=$(this).parent().parent().parent().parent().find(".sub_category_id").val();

 $.ajax({
  url : "aj_data.php",
  data: 'action=add_attr&sub_category_id='+$sub_category_id+'&sno='+$sno,
  success: function(res){
    res =$.trim(res);
    $(res).insertBefore($("#add-attr-cont"));
    $('.add_attr').attr('data-sno',$sno+1);
  }
}); 
});
$(document).on('click', '.rem_variant', function(e){
  e.preventDefault();  
  $(this).parent().parent().parent().remove(); 
  $id=$(this).attr('data-id');
  $ids = $('#del_var_grp_ids').val();
  if($ids!='0')
    $('#del_var_grp_ids').val($ids+','+$id);
  else
    $('#del_var_grp_ids').val($id);
});
$(document).on('click', '.rem_attr', function(e){
  e.preventDefault();
  $(this).parent().parent().remove(); 
  $id=$(this).attr('data-id');
  $ids = $('#del_att_ids').val();
  if($ids!='0')
    $('#del_att_ids').val($ids+','+$id);
  else
    $('#del_att_ids').val($id);
});
function get_attrs(ele,id)
{
  $tis=$(ele);
  $tis.parent().parent().parent().find(".attribute_id").html(''); 
  $tis.parent().parent().parent().find(".attribute_value_ids").html('');
  if(id!=0){
    $.ajax({
      type: "POST",
      url : "aj_data.php",
      data: 'action=get_attrs&sub_category_id='+id+'&mapped=1',
      success: function(msg){
       $tis.parent().parent().parent().find(".attribute_id").html(msg); 
     }
   })
  }    
}  
function get_attr_vals(ele,id)
{
  $tis=$(ele);
  $tis.parent().parent().find(".attribute_value_ids").html(''); 
  $sub_category_id=$tis.parent().parent().parent().parent().find(".sub_category_id").val();
  $sno =$tis.attr('data-sno');
  if(id!=0){
    $.ajax({
      type: "POST",
      url : "aj_data.php",
      data: 'action=get_attr_vals&attribute_id='+id+'&sub_category_id='+$sub_category_id+'&mapped=1&sno='+$sno,
      success: function(msg){
       $tis.parent().parent().find(".attribute_value_ids").html(msg); 
     }
   })
  }    
}
$(".del-img").click(function(){
  $id=$(this).attr('data-id');
  $name = $(this).parents().eq(3).find('.img').attr('name');
  $name = $name.replace("[id", "[");
  $(this).parents().eq(3).find('.img').attr('name',$name);
  $(this).parent().css('background-image', 'url(img/pl_hold_img.png)');
  $ids = $('#del_img_ids').val();
  if($ids!='0')
    $('#del_img_ids').val($ids+','+$id);
  else
    $('#del_img_ids').val($id);
});
</script>
