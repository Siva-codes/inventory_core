<?php include("../config.php");

if(empty($_SESSION["Users_Id"]))  {
  echo "<script>window.location.href='login.php';</script>";
}
else{
  $seller_type='';
  $res = $db->getRow("select type from seller where status='A' and seller_id=".$_SESSION["Users_Id"]);
  if(isset($res['type'])){ 
    $seller_type=$res['type'];
  }
  else{
    echo "<script>window.location.href='login.php';</script>";
  }
}

$view_perm=$add_perm=$edit_perm=$del_perm=true;  

if (isset($_SESSION['success']) && ($_SESSION['success'] != "")) {
  $stat['success'] = $_SESSION['success'];
  unset($_SESSION['success']);
}
if (isset($_SESSION['error']) && ($_SESSION['error'] != "")) {
  $stat['danger'] = $_SESSION['error'];
  unset($_SESSION['error']);
}

include('functions.php');

// $var_grp_ids=array();
// for ($j=1; $j <=12 ; $j++) { 
//   $var_grp_ids[]=$j;
// }

// $img_sno=0;
// $img_grp_sno=0;
// $img=array();
// for ($i=1; $i <=14 ; $i++) { 
//  if(fmod($img_sno, 6)==0 && $img_sno>0){
//   $img_grp_sno++;     
//  } 
  
//   $img1=array();  
//   $img1['id']=$i;
//   $img1['img_grp']=$var_grp_ids[$img_grp_sno];
//   $img[]= $img1;

// $img_sno++;      
// }

// echo "<pre>";print_r($img);die;

if (!empty($_POST['data_ord'])) {
  foreach ($_POST['data_ord'] as $key => $ord) {
    $save=array();
    $save['sort_order'] = $ord;
    $res=$db->updateAry("product", $save, "where product_id=".$key);  
  }

  unset($_POST);
  if(isset($res)){
    unset($_POST);
    $_SESSION['success'] = "Records sorted successfully.";    
  }
  else{
    $_SESSION['error'] = "Records not sorted successfully.";    
  }  

  redirect('product.php');
}
if (!empty($_POST['name'])) 
{
 // $save= $_POST;
 //echo "<pre>";print_r($_POST);
// echo "<pre>";print_r($product_variant);die;
  $save=array();
  $save['name']=$_POST['name'];  
  $save['slug']=$slug;
  $save['brand_id']=$_POST['brand_id'];
  $save['sub_category_id']=$_POST['sub_category_id'];
  $save['type']=$_POST['type'];
  $save['cancelable']=$_POST['cancelable'];
  $save['returnable']=$_POST['returnable'];
  $save['sku_code']=$_POST['sku_code'];
  $save['hsn_code']=$_POST['hsn_code'];
  $save['tax_id']=$_POST['tax_id'];
  $save['description']=$_POST['description'];
  $save['canonical_tag']=$_POST['canonical_tag'];
  $save['meta_title']=$_POST['meta_title'];
  $save['img_alt_tag']=$_POST['img_alt_tag'];
  $save['meta_desc']=$_POST['meta_desc'];
  $save['meta_keyword']=$_POST['meta_keyword'];
  $save['status']=isset($_POST['status']) && $_POST['status']!='A'?'I':'A'; 
  $save['created_by']= $_SESSION["Users_Id"];
  $save['created_date']= date('Y-m-d H:i:s');
  $product_id = $db->insertAry('product',$save);

  $slug=slugify($_POST['name']).'-'.$product_id;
  $save1=array();
  $save1['slug']=$slug;
  $save1['sort_order']=$product_id;  
  $res = $db->updateAry("product", $save1, "where product_id=".$product_id);  

  $prod_var_grp = $_POST['product_variant'];
// echo "<pre>";print_r($product_variant);die;
  $var_grp_ids=array();
  if(!empty($prod_var_grp)){
    foreach ($prod_var_grp as $key => $grp) {
      if(!empty($grp)){
        $save=array();
        $save['product_id']=$product_id;
        $id = $db->insertAry('product_variant_group',$save);    
        $var_grp_ids[]=$id;

        foreach ($grp as $key => $variant) {
          $save=array();
          $save=$variant;
          $save['product_id']=$product_id;
          $save['product_variant_group_id']=$id;
          $db->insertAry('product_variant',$save);    
        }
      }      
    }
  }

  // echo "<pre>";print_r($_FILES);exit;
  $img_sno=0;
  $img_grp_sno=0;
  if(!empty($_FILES['img'])){
    foreach ($_FILES['img']['name'] as $key => $file) {
      if(fmod($img_sno, 6)==0 && $img_sno>0)
        $img_grp_sno++;      
      
      if($file != ''){
        $fname = $file;
        $ext = strtolower(substr($fname, strrpos($fname, '.') + 1));
        if (in_array($ext, array('jpeg', 'jpg', 'png','bmp'))) {
          $file_path='../uploads/product';
          if(!file_exists($file_path))
            mkdir($file_path,0777,true); 

          $tmp_file = $_FILES['img']['tmp_name'][$key];
          // $newfile = md5($tmp_file) . "." . $ext;
          $newfile = $slug."-".$img_sno.".".$ext;
          if (move_uploaded_file($tmp_file, $file_path.'/'.$newfile)){
            $save=array();
            $save['product_id'] = $product_id;      
            $save['product_variant_group_id'] = $var_grp_ids[$img_grp_sno];      
            $save['img'] = $newfile;    
            $db->insertAry('product_img',$save);
          }
        }
      }

      $img_sno++;      
    }
  }
  $product_attribute = $_POST['product_attribute'];
  if(!empty($product_attribute)){
    foreach ($product_attribute as $key => $att) {
      if(isset($att['attribute_id']) && !empty($att['attribute_id']) && isset($att['attribute_value_ids']) && !empty($att['attribute_value_ids'])){
        $save=array();
        $save['product_id']=$product_id;
        $save['attribute_id']=$att['attribute_id'];
        $save['attribute_value_ids']=implode(",", $att['attribute_value_ids']);
        $db->insertAry('product_attribute',$save);
      }      
    }
  }

  if(!is_null($product_id))
    $_SESSION['success'] = "Product Added successfully.";
  else
    $_SESSION['error'] ="Product update failed.";
// echo $db->getLastQuery(); exit;
  unset($_POST);
  redirect('product.php');          
}
?>
<?php include 'includes/header.php'; ?>
<link href="dist/css/img_upl.css" rel="stylesheet">
<style type="text/css">
  .avatar-upload .avatar-preview {
    width: 150px;
    height: 150px;
  }
  /*.avatar-edit{
    right: unset !important;
    }*/
    .img-col{
      padding: 0px !important;
    }
  </style>
  <div class="row">                   
    <div class="col-lg-12 col-sm-12" style="padding: 0;"> 
      <div class="row panel panel-default" id="firstRow">      
        <div class="add-newproduct-tab">
          <div class="gradient-card-header">
            <h2 class="white-text mx-3">Product</h2>
          </div>
        </div>
        <?php echo !empty($stat)?msg($stat):'';?>
        <div class="courseAddPrmssn">               
          <button type="button" id="btn_add" class="btn btn-info button-addnew pull-right" ><i class="fa fa-angle-down" aria-hidden="true"></i>Add Product &nbsp;&nbsp; 
          </button>
          <br/><br/>
        </div>
        <form method="post" class="frm-save" name="doc-register" enctype="multipart/form-data">
          <div id="content" class="panel panel-default">
            <div class="panel-body add-newproduct-tab">
              <!-- prodtabs -->
              <ul class="nav nav-tabs custom-nav-tabs" id="myTab">
                <li class="active"><a id="menu_1" data-toggle="tab" href="#menu1">General</a></li>
                <li><a id="menu_2" data-toggle="tab" href="#menu2">Data</a></li>
                <li><a id="menu_3" data-toggle="tab" href="#menu3">Stock</a></li>
                <!-- <li><a data-toggle="tab" href="#menu4">Image</a></li> -->
                <li><a id="menu_4" data-toggle="tab" href="#menu4">Attributes</a></li>
                <li><a id="menu_5" data-toggle="tab" href="#menu5">SEO</a></li>
              </ul>

              <div class="tab-content">
                <div id="menu1" class="tab-pane fade in active" >
                 <br>
                 <div class="col-md-8">
                  <span class="badge-label">Product Name<span class="redstar">*</span></span>
                  <input class="form-control name" name="name" placeholder="">
                </div>
                <div class="col-md-4">
                 <span class="badge-label">Brand<span class="redstar">*</span></span>
                 <select class="select form-control brand_id" name="brand_id">
                  <option value="0">Select Brand</option>
                  <?php  $res = $db->getRows("SELECT brand_id,name FROM brand order by name");
                  if( count($res) > 0){
                    foreach($res as $res1){ ?>
                      <option value="<?= $res1["brand_id"] ?>"><?= $res1["name"] ?></option>
                    <?php } 
                  }?>     
                </select>
              </div>  
              <div class="col-md-4 top10">
               <span class="badge-label">Main Category<span class="redstar">*</span></span>
               <select class="select form-control main_category_id" onchange="get_categories(this,this.value);">
                <option value="0">Select Main Category</option>
                <?php  $res = $db->getRows("SELECT main_category_id,name FROM main_category order by name");
                if( count($res) > 0){
                  foreach($res as $res1){ ?>
                    <option value="<?= $res1["main_category_id"] ?>"><?= $res1["name"] ?></option>
                  <?php } 
                }?>     
              </select>
            </div>
            <div class="col-md-4 top10">
              <span class="badge-label">Category<span class="redstar">*</span></span>
              <select class="select form-control category_id" onchange="get_sub_categories(this,this.value);">
                <option value="0">Select Category</option>                    
              </select>
            </div>  
            <div class="col-md-4 top10">
              <span class="badge-label">Sub Category<span class="redstar">*</span></span>
              <select name="sub_category_id" class="select form-control sub_category_id" onchange="get_attrs(this,this.value);">
                <option value="0">Select Sub Category</option>                    
              </select>
            </div>
            <div class="col-md-4 top10">            
              <div class="form-group">
               <span class="badge-label">Type<span class="redstar">*</span></span><br/>
               <div class="radio">
                <label>
                  <input type="radio" class="prod-type" name="type" value="P" checked>Packet
                </label>
              </div>
              <div class="radio">
                <label>
                  <input type="radio" class="prod-type" name="type" value="L">Loose
                </label>
              </div>              
            </div>
          </div>
          <div class="col-md-4 top10">            
            <div class="form-group">
             <span class="badge-label">Cancelable<span class="redstar">*</span></span><br/>
             <div class="radio">
              <label>
                <input type="radio" class="cancelable" name="cancelable" value="Y" checked>Yes
              </label>
            </div>
            <div class="radio">
              <label>
                <input type="radio" class="cancelable" name="cancelable" value="N">No
              </label>
            </div>              
          </div>
        </div>
        <div class="col-md-4 top10">            
          <div class="form-group">
           <span class="badge-label">Returnable<span class="redstar">*</span></span><br/>
           <div class="radio">
            <label>
              <input type="radio" class="returnable" name="returnable" value="Y" checked>Yes
            </label>
          </div>
          <div class="radio">
            <label>
              <input type="radio" class="returnable" name="returnable" value="N">No
            </label>
          </div>              
        </div>        
      </div>
      <div class="col-md-4 top10">
        <span class="badge-label p-2">Status</span>
        <div class="switch top10">
          <label>Inactive
            <input type="checkbox" checked="true" name="status" value="A" >
            <span class="lever"></span> Active
          </label>
        </div>
      </div>
      <br/>
    </div>
    <div id="menu2" class="tab-pane fade">
      <br/> 
      <div class="col-md-3">
        <span class="badge-label">Product SKU ID</span>
        <input placeholder=""  class="form-control sku_code" name="sku_code" >
        <br/>
      </div>
      <div class="col-md-3">
        <span class="badge-label">HSN Code</span>
        <input placeholder="" class="form-control hsn_code" name="hsn_code" >
        <br/>
      </div>
      <div class="col-md-3">
        <span class="badge-label">Tax</span>
        <select class="select form-control tax_id" name="tax_id">
          <option value="0">Select</option>
          <?php  $res = $db->getRows("SELECT tax_id,name FROM tax order by name");
          if( count($res) > 0){
            foreach($res as $res1){ ?>
              <option value="<?= $res1["tax_id"] ?>"><?= $res1["name"] ?></option>
            <?php } 
          }?>     
        </select>
        <br/>
      </div>
      <div class="col-md-12">
        <span class="badge-label">Description</span>
        <textarea class="content" name="description"></textarea>
        <br/>
      </div>
    </div>
    <div id="menu3" class="tab-pane fade">
      <br/>
      <div class="panel-body" id="variant_cont">
        <div class="field_wrapper">
          <div class="row" style="display: flex;">
            <div class="col-md-11">
              <?php 
              for ($var_sno=0; $var_sno < strlen($seller_type); $var_sno++) { 
                 $row_type=$seller_type[$var_sno];
                if($row_type=='W')
                  $cap='Whole Sale (B2B)';
                elseif($row_type=='S')
                  $cap='Semi Whole Sale (B2B)';
                elseif($row_type=='R')
                  $cap='Retail (B2C)';
                ?>
                <button type="button"  class="collapsible collapsebtn var-row btn-r"><?=$cap?></button>
                <div class="divStockContent">
                  <br/>
                  <div class="row">
                    <div class="col-md-3">
                      <span class="badge-label ">Measurement Qty<span class="redstar">*</span></span>
                      <input class="form-control price_qty" onkeypress="return isNumber(event)" name="product_variant[0][<?=$var_sno?>][price_qty]">
                    </div>
                    <div class="col-md-3">
                      <span class="badge-label ">Measurement Unit<span class="redstar">*</span></span>
                      <select class="select form-control price_unit_id" name="product_variant[0][<?=$var_sno?>][price_unit_id]">
                        <option value="0">Select</option>
                        <?php  $res = $db->getRows("SELECT unit_id,name FROM unit order by name");
                        if( count($res) > 0){
                          foreach($res as $res1){ ?>
                            <option value="<?= $res1["unit_id"] ?>"><?= $res1["name"] ?></option>
                          <?php } 
                        }?>     
                      </select>
                    </div>
                    <div class="col-md-3">
                      <span class="badge-label ">Price<span class="redstar">*</span></span>
                      <input class="form-control price disc_calc" onkeypress="return isNumber(event)" name="product_variant[0][<?=$var_sno?>][price]">
                    </div>
                    <div class="clearfix"></div>
                    <div class="col-md-3 top10">
                      <span class="badge-label">Discount Type</span>
                      <select class="select form-control disc_type" onchange="calc_disc(this);" name="product_variant[0][<?=$var_sno?>][disc_type]">
                        <option value="0">Select</option>
                        <option value="P">Percent</option>
                        <option value="A">Amount</option>
                      </select>
                    </div>
                    <div class="col-md-3 top10">
                      <span class="badge-label ">Discount Amount</span>
                      <input class="form-control disc_amt disc_calc" onkeypress="return isFracNumber(event)" name="product_variant[0][<?=$var_sno?>][disc_amt]">
                    </div>
                    <div class="col-md-3 top10">
                      <span class="badge-label ">Discounted Price</span>
                      <input class="form-control discounted_price" readonly="true" onkeypress="return isNumber(event)" name="product_variant[0][<?=$var_sno?>][discounted_price]">
                    </div>
                    <div class="clearfix"></div>
                    <div class="col-md-3 top10">
                      <span class="badge-label ">Stock Qty<span class="redstar">*</span></span>
                      <input class="form-control stock_qty" onkeypress="return isNumber(event)" name="product_variant[0][<?=$var_sno?>][stock_qty]">
                    </div>
                    <div class="col-md-3 top10">
                      <span class="badge-label ">Stock Unit<span class="redstar">*</span></span>
                      <select class="select form-control stock_unit_id" name="product_variant[0][<?=$var_sno?>][stock_unit_id]">
                        <option value="0">Select</option>
                        <?php  $res = $db->getRows("SELECT unit_id,name FROM unit order by name");
                        if( count($res) > 0){
                          foreach($res as $res1){ ?>
                            <option value="<?= $res1["unit_id"] ?>"><?= $res1["name"] ?></option>
                          <?php } 
                        }?>     
                      </select>
                    </div>
                    <div class="col-md-3 top10">
                      <span class="badge-label ">Stock Status<span class="redstar">*</span></span>
                      <select class="select form-control" name="product_variant[0][<?=$var_sno?>][stock_status]">
                        <option value="AV">Available</option>
                        <option value="SO">Sold Out</option>
                        <option value="NA">Not Available</option>
                        <option value="SC">Shop Closed</option>
                      </select>
                    </div>
                    <div class="clearfix"></div>
                    <div class="col-md-3 top10">
                      <span class="badge-label ">Min.Order Qty</span>
                      <input class="form-control min_order_qty" onkeypress="return isNumber(event)" name="product_variant[0][<?=$var_sno?>][min_order_qty]">
                    </div> 
                    <div class="col-md-3 top10">
                      <span class="badge-label ">Delivery Time</span>
                      <div class="row">
                        <div class="col-md-6" style="padding-right: 0;">                      
                          <input style1="display: inline-block;width: 50% !important;position: relative;" class="form-control deliv_time" onkeypress="return isNumber(event)" name="product_variant[0][<?=$var_sno?>][deliv_time]">
                        </div>
                        <div class="col-md-6">
                          <select style1="display: inline-block;width: 50% !important;position: relative;" class="select form-control deliv_time_type" name="product_variant[0][<?=$var_sno?>][deliv_time_type]">
                            <option value="0">Select</option>
                            <option value="H">Hours</option>
                            <option value="D">Days</option>
                            <option value="W">Weeks</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3 top10">
                      <span class="badge-label ">Delivery Charge</span>
                      <input class="form-control deliv_charge" onkeypress="return isNumber(event)" name="product_variant[0][<?=$var_sno?>][deliv_charge]">
                    </div>
                    <div class="col-md-3 top10">            
                      <div class="form-group">
                       <span class="badge-label">COD Available<span class="redstar">*</span></span><br/>
                       <div class="radio">
                        <label>
                          <input type="radio" class="cod_available" name="product_variant[0][<?=$var_sno?>][cod_available]" value="Y" checked>Yes
                        </label>
                      </div>
                      <div class="radio">
                        <label>
                          <input type="radio" class="cod_available" name="product_variant[0][<?=$var_sno?>][cod_available]" value="N">No
                        </label>
                      </div>              
                    </div>
                    <input type="hidden" name="product_variant[0][<?=$var_sno?>][type]" value="<?=$row_type?>">
                  </div>
                </div>
                <br/>
              </div>
            <?php } ?>   
            <button type="button" class="collapsible collapsebtn">Add Images </button>
            <div class="divStockContent" style="overflow-y:scroll;">
              <br/>
              <div class="row">
                <?php for ($i=0; $i <=5 ; $i++) { ?>
                 <div class="col-md-2 top20 img-col">
                  <div class="avatar-upload">
                    <div class="avatar-edit">
                      <input type='file' class="img" id="img<?=$i;?>" name="img[]" multiple accept=".png, .jpg, .jpeg, .bmp" />
                      <label for="img<?=$i;?>"><i class="fa fa-pencil-alt"></i></label>
                    </div>
                    <div class="avatar-preview">
                      <div class="imagePreview" style="background-image: url(img/pl_hold_img.png);">
                      </div>
                    </div>
                  </div>
                </div>       
              <?php } ?>
         <!--  <div class="col-md-1 text-center" style="padding-top: 100px;padding-left: 40px;">
            <button  type="button" id="add_designicon" class="btn btn-primary btn-circle" onclick="addMoreImagesRows('0');" title="Add field"><i class="fa fa-plus"></i></button>
            <input  type="hidden" class="form-control su" name="su[]" value="productImageSizeColor0" >
          </div> -->
        </div>       
      </div>      
    </div>
  </div> <!-- Row ends -->
  <br>
</div> <!-- Field wrapper -->

<div class="row" id="add-variant-cont">
  <div class="col-md-12" style="background-color: #ebebeb; border: 1px dashed #122171;margin-top: 1em; padding: 3px 15px;">
    <div class="pull-right">
      <button type="button" class="btn btn-primary btn-circle btn-lg add_variant" title="Add Product Variant"><i class="fa fa-plus" ></i></button>
    </div>
  </div>
</div>
</div> <!-- panel-body -->
<br/>
<input type="hidden" id="var_grp_sno" value="0">
</div>
<div id="menu4" class="tab-pane fade">
  <div class="col-md-12 divProductAttributes">
    <div class="col-md-4" id="divAttrId">
      <span class="badge-label p-2">Attribute</span>
      <select name="product_attribute[0][attribute_id]" class="select form-control attribute_id" data-sno="0" onchange="get_attr_vals(this,this.value)">
        <option value="0">Select Attribute</option>                    
      </select>
    </div>
    <div class="col-md-4">
      <span class="badge-label p-2">Values</span>
      <div class="addToListListBox form-control attribute_value_ids" style1="display: none;"></div>      
    </div>    
  </div>
  <div class="col-md-12" id="add-attr-cont" style="background-color: #ebebeb; border: 1px dashed #122171;margin-top: 1em; padding: 3px 15px;margin-bottom: 10px;">
    <div class="pull-right">
      <button type="button" data-sno="1" class="btn btn-primary btn-circle btn-lg add_attr" title="Add Attribute"><i class="fa fa-plus" ></i></button>
    </div>
  </div>  
</div>
<div id="menu5" class="tab-pane fade divSeoContent">
  <br/><br/>
  <div class="col-md-7 col-md-offset-2">
    <span class="badge-label p-2">Canonical Tag</span>
    <textarea class="form-control canonical_tag" name="canonical_tag"  placeholder="Canonical page link" ></textarea>
    <br/>
  </div>
  <div class="clearfix"></div>
  <div class="col-md-7 col-md-offset-2">
    <span class="badge-label p-2">Meta Title</span>
    <textarea title="<title tag Content >" class="form-control meta_title" rows="2" name="meta_title" placeholder="<title tag Content >"  maxlength="90"></textarea>
      <span class="note-text">Note : Character Length 55 to 90.</span>

    </div>
    <div class="clearfix"></div>
    <div class="col-md-7 col-md-offset-2">
      <span class="badge-label p-2">Image Alt Tag</span>
      <textarea title="Image Alt tag content here" class="form-control img_alt_tag" name="img_alt_tag" placeholder="<alt tag Content >"  ></textarea>
        <br/>
      </div>  
      <div class="clearfix"></div>  
      <div class="col-md-10 col-md-offset-2">
        <span class="badge-label p-2">Meta Description</span>
        <textarea title="Maximum 200 Characters" class="form-control meta_desc" rows="3" name="meta_desc"  placeholder="<meta Description >" maxlength="220"></textarea>
        <span class="note-text">Note : Character Length 150 to 220.</span>

      </div>
      <div class="col-md-10 col-md-offset-2">
        <span class="badge-label p-2">Meta Keywords</span>
        <textarea title="Maximum 30 Keywords" class="form-control meta_keyword" rows="3" name="meta_keyword" placeholder="<meta Keywords >"  maxlength="255"></textarea>
        <span class="note-text">Note : Maximum 30 Keywords ( Separate by comma ' , ' )</span>
      </div>    
    </div>
  </div>
  <!-- /prodtabs -->
  <div class="col-md-12">
    <div class="pull-right">
      <label class="err_lbl"></label>&nbsp;&nbsp;
      <button class="btn blue-gradient button-save btn-save" title="Save" type="button" name="saveGroup"><i class="fa fa-check" aria-hidden="true"></i> Add</button>
      <button type="reset" title="Cancel" class="btn danger-gradient button-cancel"><i class="fa fa-times" aria-hidden="true"></i> Clear</button>
    </div>
  </div>
</div>
</div>
</form>
<div class="row">
  <div class="">
    <div class="panel-default">
      <div class="panel-body">
        <div style1="overflow-y: auto;">
          <form method="post" class="frm-sort">
            <table style="width: 100%" class="table table-striped table-hover table-bordered" id="data_table">
              <thead>
                <tr>
                 <th>Sort</th>
                 <th style="width: 20px;">SNo</th>
                 <th>Product Name</th>
                 <th>Brand</th>
                 <th>Main Category</th>
                 <th>Category</th>
                 <th>Sub Category</th>
                 <th>Status</th>              
                 <th class="text-center">Action</th>
               </tr>
             </thead>
             <tbody id="row-cont">
              <?php
                    //get images from database
              $res = $db->getRows("SELECT product_id,product.name as prod_name,brand.name as brand_name,main_category.name as main_cat_name,category.name as cat_name,sub_category.name as sub_cat_name,product.status,product.sort_order FROM product left join brand on brand.brand_id=product.brand_id left join sub_category on sub_category.sub_category_id=product.sub_category_id left join category on category.category_id=sub_category.category_id left join main_category on main_category.main_category_id=category.main_category_id where product.created_by=".$_SESSION["Users_Id"]." order by sort_order");
                  //   echo $db->getLastQuery(); exit;
              if( count($res) > 0){
                foreach($res as $key => $res1){ 
                  $id = $res1["product_id"];
                  ?>
                  <tr class="odd gradeX">
                    <td><?= $res1["sort_order"]; ?></td>
                    <td style="cursor: move;"><?= $key+1; ?></td>
                    <td><?= $res1['prod_name']; ?></td>
                    <td><?= $res1['brand_name']; ?></td>
                    <td><?= $res1['main_cat_name']; ?></td>
                    <td><?= $res1['cat_name']; ?></td>
                    <td><?= $res1['sub_cat_name']; ?></td>
                    <td class="<?= $res1['status']=='A'?'act-cls':'inact-cls'; ?>"><?= $res1['status']=='A'?'Active':'Inactive'; ?></td>
                    <td class="text-center">                                
                      <a href="edit-product.php?id=<?php echo $id ?>" class="btn btn-primary btn-circle courseEditPrmssn"value="<?php echo $id ?>"  data-id="<?php echo $id ?>" ><i class="fa fa-pencil-alt" title="Edit"></i></a>
                      <button type="button" id="delete" onclick="del_confirm(this)" name="delete" value="<?php  echo $id ?>" class="btn btn-danger btn-circle courseDeletePrmssn" title="Delete"><i class="fa fa-times"></i>
                      </button>
                      <input type="hidden" class="data_ord" name="data_ord[<?= $id; ?>]" value="<?= $key+1; ?>">                            
                    </td>                          
                  </tr>
                <?php  }
              } ?>                    
            </tbody>                  
          </table>
          <?php if( count($res) > 0){?>
           <div class="col-md-12">
            <button type="button" id="btn_save_order" name="save_order" class="btn btn-info button-addnew pull-left">Save Order</button>
          </div>
        <?php } ?>
      </form>
    </div>
  </div> <!-- panel-body-->
</div> <!-- panel-default-->
</div> <!-- empty class-->
</div> <!-- row-->
</div>          
</div>
</div>
<div class="modal fade" id="mod_data" role="dialog">
  <div class="modal-dialog cascading-modal" role="document" style="min-width: 1000px;">
    <!--Content-->
    <div class="modal-content">
      <!--Header-->
      <div class="modal-header light-blue darken-3 white-text">
        <button type="button" class="close waves-effect waves-light" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
        <h4 class="title"><i class="fa fa-pencil-alt"></i> EDIT</h4>
      </div>
      <!--Body-->
      <div class="modal-body mb-0">
        <form method="post" class="frm-upd" enctype="multipart/form-data">
          <div id="upd"></div>
          <br/>
          <div class="text-center">
            <label class="err_lbl"></label><br>
            <button type="button" name="update" id="btn_upd" data-id="0" class=" btn btn-success button-update btn-save"><i class="fa fa-check" aria-hidden="true"></i>Update
            </button>
            <button type="button" data-dismiss="modal" class="btn btn-warning button-cancel"><i class="fa fa-times"></i>Cancel</button>
          </div>
          <br/>
        </form>
      </div>
    </div>
    <!--/.Content-->
  </div>
</div>
<?php include 'includes/footer.php'; ?>
<script src="src/jquery.richtext.js"></script>
<script>  
 function readURL(input) {  
  $tis=$(input);
  if (input.files && input.files[0]) {
    var extension = input.files[0].name.split('.').pop().toLowerCase();
    var reader = new FileReader();
    reader.onload = function(e) {
      $tis.parent().parent().find('.imagePreview').css('background-image', 'url('+e.target.result +')');
      $tis.parent().parent().find('.imagePreview').hide();
      $tis.parent().parent().find('.imagePreview').fadeIn(650);
    }
    reader.readAsDataURL(input.files[0]);
  }
}
$(".img").change(function() {
  readURL(this);
});
$("#content").toggle();
$(document).ready(function(){
  $('.select').select2();
  $('.content').richText();
  $("#btn_add").click(function(){
    $("#content").toggle();
    $(this).find(".fa-angle-down").toggleClass('fa-angle-up');
  });    
  $('#data_table').DataTable({
    "scrollX": true,
    "columnDefs": [
    { "orderable": false, "targets": [8]},
    { "orderable": true, "targets": [0,2,3,4,5,6,7]},
    {"visible": false, "targets": [0]}
    ],
    "order": [[ 0, "asc" ]],
    "rowReorder" : [ "dataSrc", [1]]
  });    
});
$( ".btn_edit" ).click(function( event ) {
  event.preventDefault();

  var id =$(this).attr('data-id');
  $.ajax({
    url: 'aj_edit_prod.php?id='+id,
    dataType: 'html'
  })
  .done(function(data){      
    $('#upd').empty().append(data);
    $('#btn_upd').attr('data-id',id);
  })
  $('#mod_data').find('.err_lbl').html('');
  $('#mod_data').modal('show');
  return false;
});  
function del_confirm(e) {
  var id = e.value;
  $.confirm({
    icon: 'fa fa-warning',
    title: 'Confirm!',
    content: 'Do you want to Delete ?',
    type: 'red',
    buttons: {
      confirm:  {
        btnClass: 'btn-red',
        action: function(){
          $.confirm({
            icon: 'fa fa-warning',
            title: 'Confirm!',
            content: 'If you Delete, You cant restore this record !',
            type: 'red',
            buttons: {
              Okay: {
                btnClass: 'btn-red',
                action: function(){
                  $.ajax({
                    type: 'post',
                    url: 'aj_data.php',
                    data: 'action=del_setting&type=product&id='+id,
                    dataType: "json",
                    success: function (data) {
                      if(data['validation'] == '1'){
                       window.location.reload();
                     }
                     else{
                      $.alert(data['message']);
                    }
                  }
                });
                }
              },
              Cancel: function () { },
            }
          });
        }
      },
      cancel: function () { },
    }
  });
}  

$(document).on('input', '.disc_calc', function() {  
  calc_disc(this);
});

function calc_disc(ele){
  $tis=$(ele);  
  $price = $.trim($tis.parent().parent().find('.price').val());
  $disc_type = $tis.parent().parent().find('.disc_type').val();
  $disc_amt = $.trim($tis.parent().parent().find('.disc_amt').val());

  if($price=='')
    $price=0;

  if($disc_amt=='')
    $disc_amt=0;

  $amt =0;
  if($disc_type=='P'){
    $amt = $price * $disc_amt/100;
  }
  else if($disc_type=='A'){
    $amt = $disc_amt;
  }

  $discounted_price = $price-$amt;
  if($discounted_price<0)
    $discounted_price=0;

  $tis.parent().parent().find('.discounted_price').val($discounted_price);
}

$(document).on('click','.btn-save',function(e){    
  $err_lbl= $(this).parent().find('.err_lbl');
  $err_lbl.html('');

  $frm = $('.frm-save');        

  $val = '';
  $frm.find('input:text').each(function(){
    $(this).val($.trim($(this).val()));
  });

  $name=$frm.find('.name').val();

  if($name ==''){
    $err_lbl.html('Please enter name!');
    return false;
  }      

  $brand_id=$frm.find('.brand_id').val();
  if($brand_id ==0){
    $err_lbl.html('Please select Brand!');
    return false;
  }

  $main_category_id=$frm.find('.main_category_id').val();
  if($main_category_id ==0){
    $err_lbl.html('Please select Main category!');
    return false;
  }

  $category_id=$frm.find('.category_id').val();
  if($category_id ==0){
    $err_lbl.html('Please select Category!');
    return false;
  }
  $sub_category_id=$frm.find('.sub_category_id').val();
  if($sub_category_id ==0){
    $err_lbl.html('Please select Sub category!');
    return false;
  }

  // $tax_percent=$frm.find('.tax_percent').val();
  // if($tax_percent=='')
  //   $tax_percent=0;

  // if(parseFloat($tax_percent)>=100){
  //   $('#menu_2').click();
  //   $err_lbl.html('Invalid Tax percent!');
  //   return false;
  // } 

  $err =0;
  $(".divStockContent").css('max-height','0px');
  $(".divStockContent").each(function() {
    $val = $(this).find(".price_qty").val();
    if($val ==''){
      $('#menu_3').click();
      $err_lbl.html('Please enter Measurement Qty!');      
      $ele=$(this);
      setTimeout(
        function() 
        {
         $ele.css('max-height',$ele[0].scrollHeight+'px');
       }, 200);

      $err=1;
      return false;
    }
    $val = $(this).find(".price_unit_id").val();
    if($val ==0){
      $('#menu_3').click();
      $err_lbl.html('Please select Measurement Unit!');      
      $ele=$(this);
      setTimeout(
        function() 
        {
         $ele.css('max-height',$ele[0].scrollHeight+'px');
       }, 200);

      $err=1;
      return false;
    }
    $val = $(this).find(".price").val();
    if($val ==''){
      $('#menu_3').click();
      $err_lbl.html('Please enter Price!');      
      $ele=$(this);
      setTimeout(
        function() 
        {
         $ele.css('max-height',$ele[0].scrollHeight+'px');
       }, 200);

      $err=1;
      return false;
    }

    $disc_type = $(this).find(".disc_type").val();
    $disc_amt = $(this).find(".disc_amt").val();
    $disc_type = $(this).find(".disc_type").val();

    if ($disc_amt =='')
     $disc_amt=0;

   if($disc_type!='0'){
    if($disc_amt==0){
     $('#menu_3').click();
     $err_lbl.html('Please enter Discount Amount!');      
     $ele=$(this);
     setTimeout(
      function() 
      {
       $ele.css('max-height',$ele[0].scrollHeight+'px');
     }, 200);

     $err=1;
     return false;
   }
   else{
    if($disc_type=='P' && $disc_amt>100){
     $('#menu_3').click();
     $err_lbl.html('Invalid Discount %!');      
     $ele=$(this);
     setTimeout(
      function() 
      {
       $ele.css('max-height',$ele[0].scrollHeight+'px');
     }, 200);

     $err=1;
     return false;
   }
 }
}
else{
  if($disc_amt>0){
   $('#menu_3').click();
   $err_lbl.html('Please select Discount type!');      
   $ele=$(this);
   setTimeout(
    function() 
    {
     $ele.css('max-height',$ele[0].scrollHeight+'px');
   }, 200);

   $err=1;
   return false;
 }
}

if(parseFloat($disc_amt) >parseFloat($val) && $disc_type=='A'){
  $('#menu_3').click();
  $err_lbl.html('Discount amount exceeds price!');      
  $ele=$(this);
  setTimeout(
    function() 
    {
     $ele.css('max-height',$ele[0].scrollHeight+'px');
   }, 200);

  $err=1;
  return false;
}
$val = $(this).find(".discounted_price").val();
if($val ==''){
  $('#menu_3').click();
  $err_lbl.html('Please enter Discounted Price!');      
  $ele=$(this);
  setTimeout(
    function() 
    {
     $ele.css('max-height',$ele[0].scrollHeight+'px');
   }, 200);

  $err=1;
  return false;
}
$val = $(this).find(".stock_qty").val();
if($val ==''){
  $('#menu_3').click();
  $err_lbl.html('Please enter Stock Qty!');      
  $ele=$(this);
  setTimeout(
    function() 
    {
     $ele.css('max-height',$ele[0].scrollHeight+'px');
   }, 200);

  $err=1;
  return false;
}
$val = $(this).find(".stock_unit_id").val();
if($val ==0){
  $('#menu_3').click();
  $err_lbl.html('Please select Stock Unit!');      
  $ele=$(this);
  setTimeout(
    function() 
    {
     $ele.css('max-height',$ele[0].scrollHeight+'px');
   }, 200);

  $err=1;
  return false;
}

$deliv_time = $(this).find(".deliv_time").val();
$deliv_time_type = $(this).find(".deliv_time_type").val();

if($deliv_time!='' && $deliv_time_type=='0'){
 $('#menu_3').click();
 $err_lbl.html('Please select Delivery time type!');      
 $ele=$(this);
 setTimeout(
  function() 
  {
   $ele.css('max-height',$ele[0].scrollHeight+'px');
 }, 200);

 $err=1;
 return false;
}
else if($deliv_time=='' && $deliv_time_type!='0'){
  $('#menu_3').click();
  $err_lbl.html('Please enter Delivery time!');      
  $ele=$(this);
  setTimeout(
    function() 
    {
     $ele.css('max-height',$ele[0].scrollHeight+'px');
   }, 200);

  $err=1;
  return false;
}
});
if($err==1)
    return false;
  $(".attribute_id").each(function() {
    $tis=$(this);
    $val = $tis.val();
    $sno=$tis.attr('data-sno');
    if($val!=0){
      var $txt = $("option:selected",this).text();
      $(".attribute_id").each(function() {
        $val1 = $(this).val();
        $sno1=$(this).attr('data-sno');
        if($val==$val1 && $sno!=$sno1){
          $('#menu_4').click();
          $err_lbl.html($txt+' Attribute already selected!');      
          $ele=$(this);
          setTimeout(
            function() 
            {
             $ele.css('max-height',$ele[0].scrollHeight+'px');
           }, 200);

          $err=1;
          return false;
        }
      }); 

      if($err!=1){
        if ($tis.parent().parent().find('.attribute_value_opts:checked').length ==0) {
          $('#menu_4').click();
          $err_lbl.html($txt+' Attribute values not selected!');      
          $ele=$tis;
          setTimeout(
            function() 
            {
             $ele.css('max-height',$ele[0].scrollHeight+'px');
           }, 200);

          $err=1;
          return false;
        }  
      }
    }   
  });    
  if($err==1)
    return false;
  
  $.ajax({
    url : "aj_data.php",
    data: 'action=chk_dup&type=product&chk_fld=name&chk_val='+$name+'&chk_fld1=sub_category_id&chk_val1='+$sub_category_id+'&chk_id=0',
    success: function(res){
      res =$.trim(res);
      if(res=='E')
        $err_lbl.html('Product already exists!');
      else{
        // alert($frm.attr('name'));
        $frm.submit();
      }

    }
  }); 
}); 
function get_categories(ele,id)
{
  $tis=$(ele);
  $tis.parent().parent().find(".category_id").html(''); 
  $tis.parent().parent().find(".sub_category_id").html('<option value="0">Select Sub Category</option>'); 
  $tis.parent().parent().parent().find(".attribute_id").html('<option value="0">Select Attribute</option>');
  $tis.parent().parent().parent().find(".attribute_value_ids").html('');
  $.ajax({
    type: "POST",
    url : "aj_data.php",
    data: 'action=get_categories&main_category_id='+id,
    success: function(msg){
     $tis.parent().parent().find(".category_id").html(msg); 
   }
 });
}
function get_sub_categories(ele,id)
{
  $tis=$(ele);
  $tis.parent().parent().find(".sub_category_id").html(''); 
  $tis.parent().parent().parent().find(".attribute_id").html('<option value="0">Select Attribute</option>');
  $tis.parent().parent().parent().find(".attribute_value_ids").html('');
  $.ajax({
    type: "POST",
    url : "aj_data.php",
    data: 'action=get_sub_categories&category_id='+id,
    success: function(msg){
     $tis.parent().parent().find(".sub_category_id").html(msg); 
   }
 });
}
$(document).on('click', '.collapsible', function()
{ 
  this.classList.toggle("active1");
  $ele=$(this).next();
  if($ele.css('max-height')=='0px')
    $ele.css('max-height',$ele[0].scrollHeight+'px');
  else
    $ele.css('max-height','0px');

        // $('.divStockContent').maxHeight = null;
       // $(this).next().style.maxHeight = ($(this).next().scrollHeight+20) + "px";        
        // for (i = 0; i < coll.length; i++) {
        //   //coll[i].addEventListener("click", function() {
        //     this.classList.toggle("active1");
        //   // alert(this.classList);
        //     var contentC = this.nextElementSibling;
        //     if (contentC.style.maxHeight){
        //       contentC.style.maxHeight = null;
        //     } else {
        //       contentC.style.maxHeight = (contentC.scrollHeight+20) + "px";
        //     } 
        //   //});
        // }
      });

$('.add_variant').click(function(e){
  $var_grp_sno = parseFloat($('#var_grp_sno').val())+1;
  $seller_type='<?=$seller_type?>';
  $var_sno = $('.var-row').length;
  $.ajax({
    url : "aj_data.php",
    data: 'action=add_prod_variant&var_grp_sno='+$var_grp_sno+'&var_sno='+$var_sno+'&seller_type='+$seller_type,
    success: function(res){
      res =$.trim(res);
      $(res).insertBefore($("#add-variant-cont"));
      $('#var_grp_sno').val($var_grp_sno);
    }
  }); 
});
$('.add_attr').click(function(e){
 $sno = parseFloat($(this).attr('data-sno'));
 $sub_category_id=$(this).parent().parent().parent().parent().find(".sub_category_id").val();

 $.ajax({
  url : "aj_data.php",
  data: 'action=add_attr&sub_category_id='+$sub_category_id+'&sno='+$sno,
  success: function(res){
    res =$.trim(res);
    $(res).insertBefore($("#add-attr-cont"));
    $('.add_attr').attr('data-sno',$sno+1);
  }
}); 
});
$(document).on('click', '.rem_variant', function(e){
  e.preventDefault();
  $(this).parent().parent().parent().remove(); 
});
$(document).on('click', '.rem_attr', function(e){
  e.preventDefault();
  $(this).parent().parent().remove(); 
});
function get_attrs(ele,id)
{
  $tis=$(ele);
  $tis.parent().parent().parent().find(".attribute_id").html(''); 
  $tis.parent().parent().parent().find(".attribute_value_ids").html('');
  if(id!=0){
    $.ajax({
      type: "POST",
      url : "aj_data.php",
      data: 'action=get_attrs&sub_category_id='+id+'&mapped=1',
      success: function(msg){
       $tis.parent().parent().parent().find(".attribute_id").html(msg); 
     }
   })
  }    
}  
function get_attr_vals(ele,id)
{
  $tis=$(ele);
  $tis.parent().parent().find(".attribute_value_ids").html(''); 
  $sub_category_id=$tis.parent().parent().parent().parent().find(".sub_category_id").val();
  $sno =$tis.attr('data-sno');
  if(id!=0){
    $.ajax({
      type: "POST",
      url : "aj_data.php",
      data: 'action=get_attr_vals&attribute_id='+id+'&sub_category_id='+$sub_category_id+'&mapped=1&sno='+$sno,
      success: function(msg){
       $tis.parent().parent().find(".attribute_value_ids").html(msg); 
     }
   })
  }    
}
$( "#btn_save_order" ).click(function( event ) {
  var table = $('#data_table').DataTable();
  var info = table.page.info();
  cur_page = info.page;

  $sno=(cur_page*10)+1;
  $("#row-cont tr").each(function( index ) {
    $(this).find('.data_ord').val($sno++);      
  });

  $('.frm-sort').submit();
}); 
</script>
