  <?php include("../config.php");

  if(empty($_SESSION["Users_Id"]))  {
    echo "<script>window.location.href='login.php';</script>";
  }

  $view_perm=$add_perm=$edit_perm=$del_perm=true;  

  if (isset($_SESSION['success']) && ($_SESSION['success'] != "")) {
    $stat['success'] = $_SESSION['success'];
    unset($_SESSION['success']);
  }
  if (isset($_SESSION['error']) && ($_SESSION['error'] != "")) {
    $stat['danger'] = $_SESSION['error'];
    unset($_SESSION['error']);
  }
  $type=$_REQUEST['type'];
  if($type=='W')
    $type_str= 'Wholesaler';
  elseif($type=='S')
    $type_str= 'Semi Wholesaler';
  elseif($type=='R')
    $type_str= 'Retailer';
  if (!empty($_POST['data_ord'])) {
    foreach ($_POST['data_ord'] as $key => $ord) {
      $save=array();
      $save['sort_order'] = $ord;
      $res=$db->updateAry("top_seller", $save, "where top_seller_id=".$key);  
    }

    unset($_POST);
    if(isset($res)){
      unset($_POST);
      $_SESSION['success'] = "Records sorted successfully.";    
    }
    else{
      $_SESSION['error'] = "Records not sorted successfully.";    
    }  

    redirect('top-seller.php?type='.$type);          
  }
  if(!empty($_POST['save_show'])){
   $save=array();  
   $save['show_home']= isset($_POST['show_home']) && $_POST['show_home']=='Y'?'Y':'N';
   $res = $db->updateAry("top_seller", $save, "where type='".$type."'");
 }
 if (!empty($_POST['top_seller_id'])) {
  $save=array();  
  $save['seller_id']= $_POST['seller_id'];
  $save['status']=$_POST['status']!='A'?'I':'A';
  $res = $db->updateAry("top_seller", $save, "where top_seller_id=".$_POST['top_seller_id']);

  unset($_POST);
  if(isset($res)){
    unset($_POST);
    $_SESSION['success'] = "Top ".$type_str." updated successfully.";    
  }
  else{
    $_SESSION['error'] ="Top ".$type_str." update failed.";
  }  

  redirect('top-seller.php?type='.$type);          
}
elseif (!empty($_POST['seller_id'])) 
{ 
  $save=array();  
  $save['type']= $type;
  $save['seller_id']= $_POST['seller_id'];
  $save['status']=$_POST['status']!='A'?'I':'A'; 

  $res = $db->getRow("SELECT show_home FROM top_seller where type='".$type."' and show_home='Y'");
  if(count($res) > 0)
    $show_home='Y';
  else
    $show_home='N';      

  $save['show_home']= $show_home;
  $save['created_by']= $_SESSION["Users_Id"];
  $save['created_date']= date('Y-m-d H:i:s');      

  $id = $db->insertAry('top_seller',$save);
    // echo $db->getLastQuery(); exit;
  if(!is_null($id)){
    $save1=array();
    $save1['sort_order']=$id;
    $res = $db->updateAry("top_seller", $save1, "where top_seller_id=".$id);  

    if(!is_null($res))
      $_SESSION['success'] = "Top ".$type_str." Added successfully.";
    else
      $_SESSION['error'] ="Top ".$type_str." update failed.";
  }
  else
    $_SESSION['error'] ="Top ".$type_str." update failed.";

  // echo $db->getLastQuery(); exit;
  unset($_POST);
  redirect('top-seller.php?type='.$type);          
}

$res = $db->getRow("SELECT show_home FROM top_seller where type='".$type."' and show_home='Y'");
if(count($res) > 0)
  $show_home='Y';
else
  $show_home='N';      
?>
<?php include 'includes/header.php'; ?>
<link href="dist/css/img_upl.css" rel="stylesheet">
<div class="row">                   
  <div class="col-lg-12 col-sm-12" style="padding: 0;"> 
    <div class="row panel panel-default" id="firstRow">      
      <div class="add-newproduct-tab">
        <div class="gradient-card-header">
          <h2 class="white-text mx-3">Top <?=$type_str?></h2>
        </div>
      </div>
      <?php echo !empty($stat)?msg($stat):'';?>
      <div>
        <button type="button" id="btn_add" class="btn btn-info button-addnew pull-right" ><i class="fa fa-angle-down" aria-hidden="true"></i>Add <?=$type_str?> &nbsp;&nbsp; 
        </button>
        <form method="post" id="frm-show">
          <div class="switch">
            <span class="badge-label p-2">Show Home</span>
            &nbsp;&nbsp;&nbsp;
            <label>No<input type="checkbox" <?=$show_home=='Y'?'checked="true"':'';?> name="show_home" value="Y" >
              <span class="lever"></span>Yes
            </label>
            &nbsp;&nbsp;&nbsp;
            <button class="btn btn-info" id="btn-show" title="Save" type="submit" value="1" name="save_show">Update</button>
          </div>
        </form>
        <br> 
      </div>
      <form method="post" class="frm-save" name="doc-register" enctype="multipart/form-data">
        <div id="content" class="panel panel-default">
          <div class="panel-body">
            <div class="row">
              <div class="col-md-5">
                <span class="badge-label"><?=$type_str?><span class="redstar">*</span></span>
                <select class="select form-control seller_id" name="seller_id">
                  <option value="0">Select <?=$type_str?></option>
                  <?php  $res = $db->getRows("SELECT seller_id,name FROM seller where type like '%".strtoupper($type)."%' order by name");
                  if( count($res) > 0){
                    foreach($res as $res1){ ?>
                      <option value="<?= $res1["seller_id"] ?>"><?= $res1["name"] ?></option>
                    <?php } 
                  }?>     
                </select>
              </div>
              <div class="col-md-3">
                <span class="badge-label p-2">Status</span>
                <div class="switch top10">
                  <label>Inactive
                    <input type="checkbox" checked="true" name="status" value="A" >
                    <span class="lever"></span> Active
                  </label>
                </div>
              </div>
              <div class="col-md-4">
                <div class="pull-right top30">
                  <label style="position: absolute;top: -3px;padding-left:10px;" class="err_lbl"></label>&nbsp;&nbsp;
                  <button class="btn blue-gradient button-save btn-save" title="Save" type="button" name="saveGroup"><i class="fa fa-check" aria-hidden="true"></i> Add</button>
                  <button type="reset" title="Cancel" class="btn danger-gradient button-cancel"><i class="fa fa-times" aria-hidden="true"></i> Clear</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
      <div class="row">
        <div class="">
          <div class="panel-default">
            <div class="panel-body">
              <div style1="overflow-y: auto;">
                <form method="post" class="frm-sort">
                  <table style="width: 100%" class="table table-striped table-hover table-bordered" id="data_table">
                    <thead>
                      <tr>
                       <th>Sort</th>
                       <th style="width: 20px;">SNo</th>
                       <th><?=$type_str?></th>
                       <th>Status</th>              
                       <th class="text-center">Action</th>
                     </tr>
                   </thead>
                   <tbody id="row-cont">
                    <?php
                      //get images from database
                    $res = $db->getRows("SELECT top_seller_id,top_seller.status,seller.name as name,top_seller.sort_order FROM top_seller left join seller on top_seller.seller_id=seller.seller_id where top_seller.type='".$type."' order by top_seller.sort_order");
                      // echo $db->getLastQuery(); exit;
                    if( count($res) > 0){
                      foreach($res as $key => $res1){ 
                        $id = $res1["top_seller_id"];
                        ?>
                        <tr class="odd gradeX">
                          <td><?= $res1["sort_order"]; ?></td>
                          <td style="cursor: move;"><?= $key+1; ?></td>
                          <td><?= $res1['name']; ?></td>
                          <td class="<?= $res1['status']=='A'?'act-cls':'inact-cls'; ?>"><?= $res1['status']=='A'?'Active':'Inactive'; ?></td>
                          <td class="text-center">                                                         
                            <button class="btn_edit btn btn-primary btn-circle courseEditPrmssn" data-toggle="modal" data-target="#mod_data" name="edit" value="<?php echo $id ?>"  data-id="<?php echo $id ?>" ><i class="fa fa-pencil-alt" title="Edit"></i></button>
                            <button type="button" id="delete" onclick="del_confirm(this)" name="delete" value="<?php  echo $id ?>" class="btn btn-danger btn-circle courseDeletePrmssn" title="Delete"><i class="fa fa-times"></i>
                            </button>
                            <input type="hidden" class="data_ord" name="data_ord[<?= $id; ?>]" value="<?= $key+1; ?>">                            
                          </td>                          
                        </tr>
                      <?php  }
                    } ?>                    
                  </tbody>                  
                </table>
                <?php if( count($res) > 0){?>
                 <div class="col-md-12">
                  <button type="button" id="btn_save_order" name="save_order" class="btn btn-info button-addnew pull-left">Save Order</button>
                </div>
              <?php } ?>
            </form>
          </div>
        </div> <!-- panel-body-->
      </div> <!-- panel-default-->
    </div> <!-- empty class-->
  </div> <!-- row-->
</div>          
</div>
</div>
<div class="modal fade" id="mod_data" role="dialog">
  <div class="modal-dialog cascading-modal" role="document">
    <!--Content-->
    <div class="modal-content">
      <!--Header-->
      <div class="modal-header light-blue darken-3 white-text">
        <button type="button" class="close waves-effect waves-light" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
        <h4 class="title"><i class="fa fa-pencil-alt"></i> EDIT</h4>
      </div>
      <!--Body-->
      <div class="modal-body mb-0">
        <form method="post" class="frm-upd" enctype="multipart/form-data">
          <div id="upd"></div>
          <br/>
          <div class="text-center">
            <label class="err_lbl"></label><br>
            <button type="button" name="update" id="btn_upd" data-id="0" class=" btn btn-success button-update btn-save"><i class="fa fa-check" aria-hidden="true"></i>Update
            </button>
            <button type="button" data-dismiss="modal" class="btn btn-warning button-cancel"><i class="fa fa-times"></i>Cancel</button>
          </div>
          <br/>
        </form>
      </div>
    </div>
    <!--/.Content-->
  </div>
</div>
<?php include 'includes/footer.php'; ?>
<script>  
  $(document).ready(function(){
    $('.select').select2();
    $("#btn_add").click(function(){
      $("#content").toggle();
      $(this).find(".fa-angle-down").toggleClass('fa-angle-up');
    });
  });
  $("#content").toggle();
  $(document).ready(function() {
    $('#data_table').DataTable({
      "scrollX": true,
      "columnDefs": [
      { "orderable": false, "targets": [4]},
      { "orderable": true, "targets": [0, 2,3]},
      {"visible": false, "targets": [0]}
      ],
      "order": [[ 0, "asc" ]],
      "rowReorder" : [ "dataSrc", [1]]
    });    
  });
  $( "#btn_save_order" ).click(function( event ) {
    var table = $('#data_table').DataTable();
    var info = table.page.info();
    cur_page = info.page;

    $sno=(cur_page*10)+1;
    $("#row-cont tr").each(function( index ) {
      $(this).find('.data_ord').val($sno++);      
    });

    $('.frm-sort').submit();
  });
  $( ".btn_edit" ).click(function( event ) {
    event.preventDefault();
    $type='<?=$type?>';
    var id =$(this).attr('data-id');
    $.ajax({
      url: 'aj_data.php',
      type: 'POST',
      data: 'action=top_seller_edit&id='+id+'&type='+$type,
      dataType: 'html'
    })
    .done(function(data){      
      $('#upd').empty().append(data);
      $('#btn_upd').attr('data-id',id);
    })
    $('#mod_data').find('.err_lbl').html('');
    $('#mod_data').modal('show');
    return false;
  });  
  function del_confirm(e) {
    var id = e.value;
    $.confirm({
      icon: 'fa fa-warning',
      title: 'Confirm!',
      content: 'Do you want to Delete ?',
      type: 'red',
      buttons: {
        confirm:  {
          btnClass: 'btn-red',
          action: function(){
            $.confirm({
              icon: 'fa fa-warning',
              title: 'Confirm!',
              content: 'If you Delete, You cant restore this record !',
              type: 'red',
              buttons: {
                Okay: {
                  btnClass: 'btn-red',
                  action: function(){
                    $.ajax({
                      type: 'post',
                      url: 'aj_data.php',
                      data: 'action=del_setting&type=top_seller&id='+id,
                      dataType: "json",
                      success: function (data) {
                        if(data['validation'] == '1'){
                         window.location.reload();
                       }
                       else{
                        $.alert(data['message']);
                      }
                    }
                  });
                  }
                },
                Cancel: function () { },
              }
            });
          }
        },
        cancel: function () { },
      }
    });
  }  

  $(document).on('click','.btn-save',function(e){    
    $err_lbl= $(this).parent().find('.err_lbl');
    $err_lbl.html('');

    if($(this).attr('data-id')){
      $id=$(this).attr('data-id');
      $frm = $('.frm-upd');
    }
    else{
      $id =0;
      $frm = $('.frm-save');        
    }

    $seller_id=$frm.find('.seller_id').val();

    if($seller_id ==0){
      $err_lbl.html('Please select Seller!');
      return false;
    }

    $chk_val=$seller_id;   
    $type='<?=$type?>';
    $.ajax({
      url : "aj_data.php",
      data: 'action=chk_dup&type=top_seller&chk_fld=seller_id&chk_val='+$seller_id+'&chk_fld1=type&chk_val1='+$type+'&chk_id='+$id,
      success: function(res){
        res =$.trim(res);
        if(res=='E')
          $err_lbl.html('Seller already exists!');
        else
          $frm.submit();
      }
    }); 
  }); 

</script>
