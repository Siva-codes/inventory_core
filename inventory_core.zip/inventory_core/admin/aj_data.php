<?php include ('../config.php');
if(empty($_SESSION["Users_Id"]))  {
  echo "<script>window.location.href='login.php';</script>";
}

$action = $_REQUEST['action'];

switch ($action) {
 case 'chk_dup':{
  $type=$_GET['type'];
  $pri_id=$type.'_id';

  if($type=='seller'){
    $cond =" where (".$_GET['chk_fld']."='".$_GET['chk_val']."' or ".$_GET['chk_fld1']."='".$_GET['chk_val1']."')";
  }
  else{
    $cond =" where ".$_GET['chk_fld']."='".$_GET['chk_val']."'";

    if(!empty($_GET['chk_fld1']) && !empty($_GET['chk_val1']))
      $cond .=" and ".$_GET['chk_fld1']."='".$_GET['chk_val1']."'";
  } 

  if(!empty($_GET['chk_id']))
    $cond .=' and '.$pri_id.'!='.$_GET['chk_id'];       

  $res  = $db->getRows("SELECT ".$pri_id." FROM ".$type.$cond);
                // echo $db->getLastQuery(); die;
  if( count($res) > 0)
    echo "E";
  else
    echo "S";

  break; 
}
case "del_setting":{  
  $type=$_POST['type'];
  $pri_id=$type.'_id';
  $id = $_POST['id'];

  if($type=='main_category'){
    $res = $db->getRow("SELECT category_id FROM category where ".$pri_id."=".$id);
    if( count($res) > 0){ 
      echo json_encode(array('validation'=>'0','message'=>'Category exists under this Main category! Cannot be deleted.'));
      break;  
    }      
  }
  elseif($type=='category'){
    $res = $db->getRow("SELECT sub_category_id FROM sub_category where ".$pri_id."=".$id);
    if( count($res) > 0){ 
      echo json_encode(array('validation'=>'0','message'=>'Sub category exists under this Category! Cannot be deleted.'));
      break;  
    }      
  }
  elseif($type=='sub_category'){
    $res = $db->getRow("SELECT product_id FROM product where ".$pri_id."=".$id);
    if( count($res) > 0){ 
      echo json_encode(array('validation'=>'0','message'=>'Product exists under this Sub category! Cannot be deleted.'));
      break;  
    }      
  }
  elseif($type=='unit'){
    $res = $db->getRow("SELECT unit_id FROM unit where parent_unit_id=".$id);
    if( count($res) > 0){ 
      echo json_encode(array('validation'=>'0','message'=>'Unit under this Unit! Cannot be deleted.'));
      break;  
    }      
  }
  elseif($type=='product'){
    $q =$db->delete('product_variant',"where ".$pri_id."=".$id);
    $q =$db->delete('product_attribute',"where ".$pri_id."=".$id);

    $res = $db->getRows("SELECT img FROM product_img where product_id=".$id." order by product_img_id");
    if(!empty($res)){
      foreach ($res as $r) {
       if (!empty($r['img']))
        unlink('../uploads/product/'.$r['img']);
    }
    $db->delete('product_img',"where product_id =".$id);
  }
}

if($type=='main_category' || $type=='category' || $type=='sub_category' || $type=='brand' || $type=='banner' || $type=='seller'){
  $res = $db->getRow("SELECT img FROM ".$type." where ".$pri_id."=".$id);
  if( count($res) > 0){ 
    if(!empty($res['img']))
      unlink('../uploads/'.$type.'/'.$res['img']);
  }
}   
elseif($type=='attribute'){
  $q =$db->delete('attribute_value',"where ".$pri_id."=".$id);
  $q =$db->delete('attribute_map',"where ".$pri_id."=".$id);
}
elseif($type=='attribute_value'){
  $res = $db->getRows("SELECT attribute_map_id,attribute_value_ids FROM attribute_map where concat(',',attribute_value_ids,',') like '%,".$id.",%' order by attribute_map_id");
  if(!empty($res)){
    foreach ($res as $res1) {
      $ids = str_replace('id', '', $res1['']);
      $db->delete('product_img',"where product_img_id =".$r['product_img_id']);
    }
  }

  $q =$db->delete('attribute_map',"where ".$pri_id."=".$id);
}

$q =$db->delete($type,"where ".$pri_id."=".$id);

if(!empty($q)){
  echo json_encode(array('validation'=>'1','message'=>'Record deleted successfully !'));
}else{
  echo json_encode(array('validation'=>'0','message'=>'Action Failed ! Please try again.'));
} 
break;   
}
case "banner_edit":{
 $res = $db->getRow("SELECT * FROM banner where banner_id=".$_POST['id']);?>
 <input type="hidden" name="banner_id" value="<?= $res['banner_id'] ?>" />
 <div class="row">
  <div class="col-md-6 top15">
    <span class="badge-label">Image<span class="redstar"></span></span>
    <div class="avatar-upload">
      <div class="avatar-edit">
        <input type='file' id="img1" name="img" class="img" accept=".png, .jpg, .jpeg, .bmp" />
        <label for="img1"><i class="fa fa-pencil-alt"></i></label>
      </div>
      <div class="avatar-preview">
        <div class="imagePreview" style="background-image: url(<?php echo !empty($res['img'])?'../uploads/banner/'.$res["img"]:'img/pl_hold_img.png'; ?>">
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-12 top10">
    <span class="badge-label p-2">Status</span>
    <div class="switch top10">
      <label>Inactive
        <input type="checkbox" <?= $res['status']=='A'?'checked="true"':''; ?> name="status" value="A" >
        <span class="lever"></span> Active
      </label>
    </div>
  </div>
</div>
<script>
  function readURL(input) {
    $tis=$(input);
    if (input.files && input.files[0]) {
      var extension = input.files[0].name.split('.').pop().toLowerCase();
      var reader = new FileReader();
      reader.onload = function(e) {
        $tis.parent().parent().find('.imagePreview').css('background-image', 'url('+e.target.result +')');
        $tis.parent().parent().find('.imagePreview').hide();
        $tis.parent().parent().find('.imagePreview').fadeIn(650);
      }
      reader.readAsDataURL(input.files[0]);
    }
  }
  $(".img").change(function() {
    readURL(this);
  });
</script>
<?php
break;
}
case "main_category_edit":{
 $res = $db->getRow("SELECT * FROM main_category where main_category_id=".$_POST['id']);?>
 <input type="hidden" name="main_category_id" value="<?= $res['main_category_id'] ?>" />
 <div class="row">
  <div class="col-md-12 top15">
    <span class="badge-label">Name</span>
    <input class="form-control name" name="name" value="<?= $res['name'] ?>">
  </div>
  <div class="col-md-6 top15">
    <span class="badge-label">Image<span class="redstar"></span></span>
    <div class="avatar-upload">
      <div class="avatar-edit">
        <input type='file' id="img1" name="img" class="img" accept=".png, .jpg, .jpeg, .bmp" />
        <label for="img1"><i class="fa fa-pencil-alt"></i></label>
      </div>
      <div class="avatar-preview">
        <div class="imagePreview" style="background-image: url(<?php echo !empty($res['img'])?'../uploads/main_category/'.$res["img"]:'img/pl_hold_img.png'; ?>">
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-12 top10">
    <span class="badge-label p-2">Status</span>
    <div class="switch top10">
      <label>Inactive
        <input type="checkbox" <?= $res['status']=='A'?'checked="true"':''; ?> name="status" value="A" >
        <span class="lever"></span> Active
      </label>
    </div>
  </div>

</div>
<script>
  function readURL(input) {
    $tis=$(input);
    if (input.files && input.files[0]) {
      var extension = input.files[0].name.split('.').pop().toLowerCase();
      var reader = new FileReader();
      reader.onload = function(e) {
        $tis.parent().parent().find('.imagePreview').css('background-image', 'url('+e.target.result +')');
        $tis.parent().parent().find('.imagePreview').hide();
        $tis.parent().parent().find('.imagePreview').fadeIn(650);
      }
      reader.readAsDataURL(input.files[0]);
    }
  }
  $(".img").change(function() {
    readURL(this);
  });
</script>
<?php
break;
}
case "category_edit":{
 $res = $db->getRow("SELECT * FROM category where category_id=".$_POST['id']);?>
 <input type="hidden" name="category_id" value="<?= $res['category_id'] ?>" />
 <div class="row">
  <div class="col-md-12 top15">
    <span class="badge-label">Name</span>
    <input class="form-control name" name="name" value="<?= $res['name'] ?>">
  </div>
  <div class="col-md-12 top15">
    <span class="badge-label">Main Category</span>
    <select name="main_category_id" class="select form-control main_category_id">
      <option value="0">Select Main Category</option>
      <?php  $opts = $db->getRows("SELECT main_category_id,name FROM main_category order by name");
      if( count($opts) > 0){
        foreach($opts as $opt){ ?>
          <option <?= $opt['main_category_id']==$res['main_category_id']?' selected="true"':'';?> value="<?= $opt["main_category_id"] ?>"><?= $opt["name"] ?></option>
        <?php } 
      }?>     
    </select>
  </div>
  <div class="col-md-6 top15">
    <span class="badge-label">Image<span class="redstar"></span></span>
    <div class="avatar-upload">
      <div class="avatar-edit">
        <input type='file' id="img1" name="img" class="img" accept=".png, .jpg, .jpeg, .bmp" />
        <label for="img1"><i class="fa fa-pencil-alt"></i></label>
      </div>
      <div class="avatar-preview">
        <div class="imagePreview" style="background-image: url(<?php echo !empty($res['img'])?'../uploads/category/'.$res["img"]:'img/pl_hold_img.png'; ?>">
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-12 top10">
    <span class="badge-label p-2">Status</span>
    <div class="switch top10">
      <label>Inactive
        <input type="checkbox" <?= $res['status']=='A'?'checked="true"':''; ?> name="status" value="A" >
        <span class="lever"></span> Active
      </label>
    </div>
  </div>
</div>
<script>
  $('.select').select2();
  function readURL(input) {
    $tis=$(input);
    if (input.files && input.files[0]) {
      var extension = input.files[0].name.split('.').pop().toLowerCase();
      var reader = new FileReader();
      reader.onload = function(e) {
        $tis.parent().parent().find('.imagePreview').css('background-image', 'url('+e.target.result +')');
        $tis.parent().parent().find('.imagePreview').hide();
        $tis.parent().parent().find('.imagePreview').fadeIn(650);
      }
      reader.readAsDataURL(input.files[0]);
    }
  }
  $(".img").change(function() {
    readURL(this);
  });
</script>
<?php
break;
}
case 'get_categories':{
  ?>
  <option value="">Select Category</option>
  <?php  
  $res  = $db->getRows("SELECT category_id,name FROM category where main_category_id=".$_POST['main_category_id']." order by name");
            // echo $db->getLastQuery(); 
  if( count($res) > 0){
    foreach($res as $res1){ ?>
      <option value="<?php echo $res1["category_id"] ?>"><?= $res1['name']; ?></option>
    <?php }
  } ?>
  <?php
  break;
}
case 'get_sub_categories':{
  ?>
  <option value="">Select Sub Category</option>
  <?php  
  $res  = $db->getRows("SELECT sub_category_id,name FROM sub_category where category_id=".$_POST['category_id']." order by name");
            // echo $db->getLastQuery(); 
  if( count($res) > 0){
    foreach($res as $res1){ ?>
      <option value="<?php echo $res1["sub_category_id"] ?>"><?= $res1['name']; ?></option>
    <?php }
  } ?>
  <?php
  break;
}
case 'get_prods':{
  ?>
  <option value="">Select Product</option>
  <?php  
  $res  = $db->getRows("SELECT product_id,name FROM product where sub_category_id=".$_POST['sub_category_id']." and brand_id=".$_POST['brand_id']." order by name");
  echo $db->getLastQuery(); 
  if( count($res) > 0){
    foreach($res as $res1){ ?>
      <option value="<?php echo $res1["product_id"] ?>"><?= $res1['name']; ?></option>
    <?php }
  } ?>
  <?php
  break;
}
case 'get_attrs':{ ?>
 <option value="">Select Attribute</option>
 <?php  
   // $main_category_id = $_POST['main_category_id'];
   // $category_id = $_POST['category_id'];

   // $res  = $db->getRows("SELECT attribute_map.attribute_id,attribute_value_ids,attribute.name FROM attribute_map left join attribute on attribute.attribute_id=attribute_map.attribute_id where sub_category_id=".$_POST['sub_category_id']);
            // echo $db->getLastQuery(); 

 if(!isset($_POST['mapped'])){
  if(!empty($_POST['edit_attribute_id']))
    $res  = $db->getRows("SELECT attribute_id,name FROM attribute where (attribute_id not in(select attribute_id from attribute_map where sub_category_id=".$_POST['sub_category_id'].")) or( attribute_id =".$_POST['edit_attribute_id'].") order by name");
  else
   $res  = $db->getRows("SELECT attribute_id,name FROM attribute where attribute_id not in(select attribute_id from attribute_map where sub_category_id=".$_POST['sub_category_id'].") order by name");
}
else{
  $res  = $db->getRows("SELECT attribute_map.attribute_id,attribute.name FROM attribute_map left join attribute on attribute.attribute_id=attribute_map.attribute_id where attribute_map.sub_category_id=".$_POST['sub_category_id']." order by attribute.name");
} 

  //echo $db->getLastQuery();  exit;
if( count($res) > 0){
  foreach($res as $res1){ ?>
    <option value="<?php echo $res1["attribute_id"] ?>"><?= $res1['name']; ?></option>
  <?php }
} ?>
<?php
break;
}
case 'get_attr_vals':{
 if (isset($_REQUEST['sno']))
  $name='product_attribute['.$_REQUEST['sno'].'][attribute_value_ids][]';
else
  $name='attribute_value_ids[]';
?> 
<?php  
$res=array();
if(!isset($_POST['mapped']))
 $res  = $db->getRows("SELECT attribute_value_id,attr_value FROM attribute_value where attribute_id=".$_POST['attribute_id']);
else{
  $res1 = $db->getRow("SELECT attribute_value_ids FROM attribute_map where attribute_id=".$_POST['attribute_id']." and sub_category_id=".$_POST['sub_category_id']);

  if(!empty($res1)){
    $res  = $db->getRows("SELECT attribute_value_id,attr_value FROM attribute_value where attribute_value_id in(".$res1['attribute_value_ids'].")");  
  }  
} 

  //echo $db->getLastQuery();  exit;
if( count($res) > 0){
  foreach($res as $key => $res1){ $id=uniqid(time(), true); ?>
    <div class="pure-checkbox">
      &nbsp;<input type="checkbox" id="attribute_value_ids<?php echo $id ?>" value="<?php echo $res1['attribute_value_id']?>" class="attribute_value_opts" style="opacity:2" name="<?=$name?>"><label for="attribute_value_ids<?php echo $id ?>"><?php echo $res1['attr_value'];?></label>
    </div>
  <?php }
} ?>
<?php
break;
}
case "sub_category_edit":{
 $res = $db->getRow("SELECT sub_category.*,main_category.main_category_id FROM sub_category left join category on category.category_id=sub_category.category_id left join main_category on main_category.main_category_id=category.main_category_id where sub_category_id=".$_POST['id']);?>
 <input type="hidden" name="sub_category_id" value="<?= $res['sub_category_id'] ?>" />
 <div class="row">
  <div class="col-md-12 top15">
    <span class="badge-label">Name</span>
    <input class="form-control name" name="name" value="<?= $res['name'] ?>">
  </div>
  <div class="col-md-12 top15">
    <span class="badge-label">Main Category</span>
    <select class="select form-control main_category_id" onchange="get_categories(this,this.value);">
      <option value="0">Select Main Category</option>
      <?php  $opts = $db->getRows("SELECT main_category_id,name FROM main_category order by name");
       // print_r($opts);
      if( count($opts) > 0){
        foreach($opts as $opt){ ?>
          <option <?= $opt['main_category_id']==$res['main_category_id']?' selected="true"':'';?> value="<?= $opt["main_category_id"] ?>"><?= $opt["name"] ?></option>
        <?php } 
      }?>     
    </select>
  </div>
  <div class="col-md-12 top15">
    <span class="badge-label">Category</span>
    <select name="category_id" class="select form-control category_id">
      <option value="0">Select Category</option>
      <?php  $opts = $db->getRows("SELECT category_id,name FROM category where main_category_id=".$res['main_category_id']." order by name");
      if( count($opts) > 0){
        foreach($opts as $opt){ ?>
          <option <?= $opt['category_id']==$res['category_id']?' selected="true"':'';?> value="<?= $opt["category_id"] ?>"><?= $opt["name"] ?></option>
        <?php } 
      }?>     
    </select>
  </div>
  <div class="col-md-6 top15">
    <span class="badge-label">Image<span class="redstar"></span></span>
    <div class="avatar-upload">
      <div class="avatar-edit">
        <input type='file' id="img1" name="img" class="img" accept=".png, .jpg, .jpeg, .bmp" />
        <label for="img1"><i class="fa fa-pencil-alt"></i></label>
      </div>
      <div class="avatar-preview">
        <div class="imagePreview" style="background-image: url(<?php echo !empty($res['img'])?'../uploads/sub_category/'.$res["img"]:'img/pl_hold_img.png'; ?>">
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-12 top10">
    <span class="badge-label p-2">Status</span>
    <div class="switch top10">
      <label>Inactive
        <input type="checkbox" <?= $res['status']=='A'?'checked="true"':''; ?> name="status" value="A" >
        <span class="lever"></span> Active
      </label>
    </div>
  </div>
</div>
<script>
  $('.select').select2();
  function readURL(input) {
    $tis=$(input);
    if (input.files && input.files[0]) {
      var extension = input.files[0].name.split('.').pop().toLowerCase();
      var reader = new FileReader();
      reader.onload = function(e) {
        $tis.parent().parent().find('.imagePreview').css('background-image', 'url('+e.target.result +')');
        $tis.parent().parent().find('.imagePreview').hide();
        $tis.parent().parent().find('.imagePreview').fadeIn(650);
      }
      reader.readAsDataURL(input.files[0]);
    }
  }
  $(".img").change(function() {
    readURL(this);
  });
  function get_categories(ele,id)
  {
    $tis=$(ele);
    $tis.parent().parent().find("category_id").html(''); 
    $.ajax({
      type: "POST",
      url : "aj_data.php",
      data: 'action=get_categories&main_category_id='+id,
      success: function(msg){
       $tis.parent().parent().find(".category_id").html(msg); 
     }
   })
  }
</script>
<?php
break;
}
case "attribute_edit":{
 $res = $db->getRow("SELECT * FROM attribute where attribute_id=".$_POST['id']);?>
 <input type="hidden" name="attribute_id" value="<?= $res['attribute_id'] ?>" />
 <div class="row">
  <div class="col-md-12 top15">
    <span class="badge-label">Name</span>
    <input class="form-control name" name="name" value="<?= $res['name'] ?>">
  </div>
  <div class="col-md-12 top10">
    <span class="badge-label p-2">Status</span>
    <div class="switch top10">
      <label>Inactive
        <input type="checkbox" <?= $res['status']=='A'?'checked="true"':''; ?> name="status" value="A" >
        <span class="lever"></span> Active
      </label>
    </div>
  </div>
</div>   
<?php
break;
}
case "attribute_value_edit":{
 $res = $db->getRow("SELECT * FROM attribute_value where attribute_value_id=".$_POST['id']);?>
 <input type="hidden" name="attribute_value_id" value="<?= $res['attribute_value_id'] ?>" />
 <div class="row">
  <div class="col-md-12 top15">
    <span class="badge-label">Attribute<span class="redstar">*</span></span>
    <select class="select form-control attribute_id" name="attribute_id">
      <option value="0">Select Attribute</option>
      <?php  $opts = $db->getRows("SELECT attribute_id,name FROM attribute order by name");
      if( count($opts) > 0){
        foreach($opts as $opt){ ?>
          <option <?= $opt['attribute_id']==$res['attribute_id']?'selected="true"':''; ?> value="<?= $opt["attribute_id"] ?>"><?= $opt["name"] ?></option>
        <?php } 
      }?>     
    </select>
  </div>
  <div class="col-md-12 top15">
    <span class="badge-label">Value</span>
    <input class="form-control attr_value" name="attr_value" value="<?= $res['attr_value'] ?>">
  </div>
  <div class="col-md-12 top10">
    <span class="badge-label p-2">Status</span>
    <div class="switch top10">
      <label>Inactive
        <input type="checkbox" <?= $res['status']=='A'?'checked="true"':''; ?> name="status" value="A" >
        <span class="lever"></span> Active
      </label>
    </div>
  </div>
</div>
<script type="text/javascript">
  $('.select').select2();
</script>   
<?php
break;
}
case "attribute_map_edit":{
 $res = $db->getRow("SELECT attribute_map_id,main_category.main_category_id,category.category_id,attribute_map.sub_category_id,attribute_map.attribute_id,attribute_map.attribute_value_ids FROM attribute_map left join sub_category on sub_category.sub_category_id=attribute_map.sub_category_id left join category on category.category_id=sub_category.category_id left join main_category on main_category.main_category_id=category.main_category_id where attribute_map_id=".$_POST['id']);
   // echo $db->getLastQuery(); die;
 ?>
 <input type="hidden" name="attribute_map_id" value="<?= $res['attribute_map_id'] ?>" />
 <div class="row">
   <div class="col-md-12 top15">
    <span class="badge-label">Main Category</span>
    <select class="select form-control main_category_id" onchange="get_categories(this,this.value);">
      <option value="0">Select Main Category</option>
      <?php  $opts = $db->getRows("SELECT main_category_id,name FROM main_category order by name");
       // print_r($opts);
      if( count($opts) > 0){
        foreach($opts as $opt){ ?>
          <option <?= $opt['main_category_id']==$res['main_category_id']?' selected="true"':'';?> value="<?= $opt["main_category_id"] ?>"><?= $opt["name"] ?></option>
        <?php } 
      }?>     
    </select>
  </div>
  <div class="col-md-12 top15">
    <span class="badge-label">Category</span>
    <select name="category_id" class="select form-control category_id" onchange="get_sub_categories(this,this.value);">
      <option value="0">Select Category</option>
      <?php  $opts = $db->getRows("SELECT category_id,name FROM category where main_category_id=".$res['main_category_id']." order by name");
      if( count($opts) > 0){
        foreach($opts as $opt){ ?>
          <option <?= $opt['category_id']==$res['category_id']?' selected="true"':'';?> value="<?= $opt["category_id"] ?>"><?= $opt["name"] ?></option>
        <?php } 
      }?>     
    </select>
  </div>
  <div class="col-md-12 top15">
    <span class="badge-label">Sub Category</span>
    <select name="sub_category_id" class="select form-control sub_category_id" onchange="get_attrs(this,this.value,<?=$res['attribute_id']?>)">
      <option value="0">Select Sub Category</option>
      <?php  $opts = $db->getRows("SELECT sub_category_id,name FROM sub_category where category_id=".$res['category_id']." order by name");
      if( count($opts) > 0){
        foreach($opts as $opt){ ?>
          <option <?= $opt['sub_category_id']==$res['sub_category_id']?' selected="true"':'';?> value="<?= $opt["sub_category_id"] ?>"><?= $opt["name"] ?></option>
        <?php } 
      }?>     
    </select>
  </div>
  <div class="col-md-12 top15">
    <span class="badge-label">Attribute</span>
    <select name="attribute_id" class="select form-control attribute_id" onchange="get_attr_vals(this,this.value)">
      <option value="0">Select Attribute</option>
      <?php 
      $opts  = $db->getRows("SELECT attribute_id,name FROM attribute where (attribute_id not in(select attribute_id from attribute_map where sub_category_id=".$res['sub_category_id'].") or attribute_id=".$res['attribute_id'].") order by name");
         // echo $db->getLastQuery(); exit;
      if( count($opts) > 0){
        foreach($opts as $opt){ ?>
          <option <?= $opt['attribute_id']==$res['attribute_id']?' selected="true"':'';?> value="<?= $opt["attribute_id"] ?>"><?= $opt["name"] ?></option>
        <?php } 
      }?>     
    </select>
  </div>
  <div class="col-md-12 top15">
    <span class="badge-label">Attribute Values</span>
    <div class="addToListListBox form-control attribute_value_ids" style1="display: none;">
      <?php $opts  = $db->getRows("SELECT attribute_value_id,attr_value FROM attribute_value where attribute_id=".$res['attribute_id']);
  //echo $db->getLastQuery();  exit;
      if( count($opts) > 0){
        foreach($opts as $key => $opt){ 
          if(strpos(','.$res['attribute_value_ids'].',',','.$opt["attribute_value_id"].',') !== false)
            $checked='checked';
          else
            $checked='';
          ?>
          <div class="pure-checkbox">
            &nbsp;<input type="checkbox" id="attribute_value_ids<?php echo $key ?>" value="<?php echo $opt['attribute_value_id']?>" <?=$checked;?> class="attribute_value_opts" style="opacity:2" name="attribute_value_ids[]"><label for="attribute_value_ids<?php echo $key ?>"><?php echo $opt['attr_value'];?></label>
          </div>
        <?php }
      } ?>
    </div>
  </div>
</div>  
<script type="text/javascript">
  $('.select').select2();
</script> 
<?php
break;
}
case "brand_edit":{
 $res = $db->getRow("SELECT * FROM brand where brand_id=".$_POST['id']);?>
 <input type="hidden" name="brand_id" value="<?= $res['brand_id'] ?>" />
 <div class="row">
  <div class="col-md-12 top15">
    <span class="badge-label">Name</span>
    <input class="form-control name" name="name" value="<?= $res['name'] ?>">
  </div>
  <div class="col-md-6 top15">
    <span class="badge-label">Image<span class="redstar"></span></span>
    <div class="avatar-upload">
      <div class="avatar-edit">
        <input type='file' id="img1" name="img" class="img" accept=".png, .jpg, .jpeg, .bmp" />
        <label for="img1"><i class="fa fa-pencil-alt"></i></label>
      </div>
      <div class="avatar-preview">
        <div class="imagePreview" style="background-image: url(<?php echo !empty($res['img'])?'../uploads/brand/'.$res["img"]:'img/pl_hold_img.png'; ?>">
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-12 top10">
    <span class="badge-label p-2">Status</span>
    <div class="switch top10">
      <label>Inactive
        <input type="checkbox" <?= $res['status']=='A'?'checked="true"':''; ?> name="status" value="A" >
        <span class="lever"></span> Active
      </label>
    </div>
  </div>

</div>
<script>
  function readURL(input) {
    $tis=$(input);
    if (input.files && input.files[0]) {
      var extension = input.files[0].name.split('.').pop().toLowerCase();
      var reader = new FileReader();
      reader.onload = function(e) {
        $tis.parent().parent().find('.imagePreview').css('background-image', 'url('+e.target.result +')');
        $tis.parent().parent().find('.imagePreview').hide();
        $tis.parent().parent().find('.imagePreview').fadeIn(650);
      }
      reader.readAsDataURL(input.files[0]);
    }
  }
  $(".img").change(function() {
    readURL(this);
  });
</script>
<?php
break;
}
case "unit_edit":{
 $res = $db->getRow("SELECT * FROM unit where unit_id=".$_POST['id']);?>
 <input type="hidden" name="unit_id" value="<?= $res['unit_id'] ?>" />
 <div class="row">
   <div class="col-md-12 top15">
    <span class="badge-label">Name</span>
    <input class="form-control name" name="name" value="<?= $res['name'] ?>">
  </div>
  <div class="col-md-12 top15">
    <span class="badge-label">Parent Unit<span class="redstar">*</span></span>
    <select class="select form-control parent_unit_id" name="parent_unit_id">
      <option value="0">Select Parent Unit</option>
      <?php  $opts = $db->getRows("SELECT unit_id,name FROM unit where unit_id !=".$_POST['id']." order by name");
      if( count($opts) > 0){
        foreach($opts as $opt){ ?>
          <option <?= $opt['unit_id']==$res['parent_unit_id']?'selected="true"':''; ?> value="<?= $opt["unit_id"] ?>"><?= $opt["name"] ?></option>
        <?php } 
      }?>     
    </select>
  </div>
  <div class="col-md-12 top15">
    <span class="badge-label">Conversion</span>
    <input class="form-control conversion" name="conversion" onkeypress="return isNumber(event)" value="<?= $res['conversion'] ?>">
  </div>  
</div>
<script type="text/javascript">
  $('.select').select2();
</script>   
<?php
break;
}
case 'add_attr':{ 
  if(!empty($_GET['sub_category_id']))
    $res  = $db->getRows("SELECT attribute_map.attribute_id,attribute.name FROM attribute_map left join attribute on attribute.attribute_id=attribute_map.attribute_id where attribute_map.sub_category_id=".$_GET['sub_category_id']." order by attribute.name"); 
  else
    $res=array();

  $sno=isset($_REQUEST['sno'])?$_REQUEST['sno']:1;
  ?>

  <div class="col-md-12 divProductAttributes">
    <div class="col-md-4" id="divAttrId">
      <span class="badge-label p-2">Attribute</span>
      <select name="product_attribute[<?=$sno?>][attribute_id]" data-sno="<?=$sno?>" class="select form-control attribute_id" onchange="get_attr_vals(this,this.value)">
        <option value="0">Select Attribute</option>
        <?php if( count($res) > 0){
          foreach($res as $res1){ ?>
            <option value="<?php echo $res1["attribute_id"] ?>"><?= $res1['name']; ?></option>
          <?php }
        } ?>                  
      </select>
    </div>
    <div class="col-md-4">
      <span class="badge-label p-2">Values</span>
      <div class="addToListListBox form-control attribute_value_ids" style1="display: none;"></div>      
    </div>  
    <div class="col-md-1" style="align-self: center;text-align: center;"><button type="button" class="rem_attr btn btn-danger btn-circle" title="Remove Attribute"><i class="far fa-trash-alt" ></i></button>
    </div>  
  </div>
  <script type="text/javascript">
    $('.select').select2();
  </script>
  <?php break;
}

case 'add_prod_variant':{ $var_grp_sno=$_REQUEST['var_grp_sno'];$sno=$_REQUEST['var_sno'];$seller_type=$_REQUEST['seller_type']; ?>
<div class="field_wrapper">
  <div class="row" style="display: flex;">
    <div class="col-md-11">
      <?php 
      for ($var_sno=$sno; $var_sno < strlen($seller_type)+$sno; $var_sno++) { 
        $row_type = $seller_type[$var_sno-$sno];
        if($row_type=='W')
          $cap='Whole Sale (B2B)';
        elseif($row_type=='S')
          $cap='Semi Whole Sale (B2B)';
        elseif($row_type=='R')
          $cap='Retail (B2C)';
        ?>
        <button type="button"  class="collapsible collapsebtn var-row btn-r"><?=$cap?></button>
        <div class="divStockContent">
          <br/>
          <div class="row">
            <div class="col-md-3">
              <span class="badge-label ">Measurement Qty<span class="redstar">*</span></span>
              <input class="form-control price_qty" onkeypress="return isNumber(event)" name="product_variant[<?=$var_grp_sno?>][<?=$var_sno?>][price_qty]">
            </div>
            <div class="col-md-3">
              <span class="badge-label ">Measurement Unit<span class="redstar">*</span></span>
              <select class="select form-control price_unit_id" name="product_variant[<?=$var_grp_sno?>][<?=$var_sno?>][price_unit_id]">
                <option value="0">Select</option>
                <?php  $res = $db->getRows("SELECT unit_id,name FROM unit order by name");
                if( count($res) > 0){
                  foreach($res as $res1){ ?>
                    <option value="<?= $res1["unit_id"] ?>"><?= $res1["name"] ?></option>
                  <?php } 
                }?>     
              </select>
            </div>
            <div class="col-md-3">
              <span class="badge-label ">Price<span class="redstar">*</span></span>
              <input class="form-control price disc_calc" onkeypress="return isNumber(event)" name="product_variant[<?=$var_grp_sno?>][<?=$var_sno?>][price]">
            </div>
            <div class="clearfix"></div>
            <div class="col-md-3 top10">
              <span class="badge-label">Discount Type</span>
              <select class="select form-control disc_type" onchange="calc_disc(this);" name="product_variant[<?=$var_grp_sno?>][<?=$var_sno?>][disc_type]">
                <option value="0">Select</option>
                <option value="P">Percent</option>
                <option value="A">Amount</option>
              </select>
            </div>
            <div class="col-md-3 top10">
              <span class="badge-label ">Discount Amount</span>
              <input class="form-control disc_amt disc_calc" onkeypress="return isFracNumber(event)" name="product_variant[<?=$var_grp_sno?>][<?=$var_sno?>][disc_amt]">
            </div>
            <div class="col-md-3 top10">
              <span class="badge-label ">Discounted Price</span>
              <input class="form-control discounted_price" readonly="true" onkeypress="return isNumber(event)" name="product_variant[<?=$var_grp_sno?>][<?=$var_sno?>][discounted_price]">
            </div>
            <div class="clearfix"></div>
            <div class="col-md-3 top10">
              <span class="badge-label ">Stock Qty<span class="redstar">*</span></span>
              <input class="form-control stock_qty" onkeypress="return isNumber(event)" name="product_variant[<?=$var_grp_sno?>][<?=$var_sno?>][stock_qty]">
            </div>
            <div class="col-md-3 top10">
              <span class="badge-label ">Stock Unit<span class="redstar">*</span></span>
              <select class="select form-control stock_unit_id" name="product_variant[<?=$var_grp_sno?>][<?=$var_sno?>][stock_unit_id]">
                <option value="0">Select</option>
                <?php  $res = $db->getRows("SELECT unit_id,name FROM unit order by name");
                if( count($res) > 0){
                  foreach($res as $res1){ ?>
                    <option value="<?= $res1["unit_id"] ?>"><?= $res1["name"] ?></option>
                  <?php } 
                }?>     
              </select>
            </div>
            <div class="col-md-3 top10">
              <span class="badge-label ">Stock Status<span class="redstar">*</span></span>
              <select class="select form-control" name="product_variant[<?=$var_grp_sno?>][<?=$var_sno?>][stock_status]">
                <option value="AV">Available</option>
                <option value="SO">Sold Out</option>
                <option value="NA">Not Available</option>
                <option value="SC">Shop Closed</option>
              </select>
            </div>
            <div class="clearfix"></div>
            <div class="col-md-3 top10">
              <span class="badge-label ">Min.Order Qty</span>
              <input class="form-control min_order_qty" onkeypress="return isNumber(event)" name="product_variant[<?=$var_grp_sno?>][<?=$var_sno?>][min_order_qty]">
            </div> 
            <div class="col-md-3 top10">
              <span class="badge-label ">Delivery Time</span>
              <div class="row">
                <div class="col-md-6" style="padding-right: 0;">                      
                  <input style1="display: inline-block;width: 50% !important;position: relative;" class="form-control deliv_time" onkeypress="return isNumber(event)" name="product_variant[<?=$var_grp_sno?>][<?=$var_sno?>][deliv_time]">
                </div>
                <div class="col-md-6">
                  <select style1="display: inline-block;width: 50% !important;position: relative;" class="select form-control deliv_time_type" name="product_variant[<?=$var_grp_sno?>][<?=$var_sno?>][deliv_time_type]">
                    <option value="0">Select</option>
                    <option value="H">Hours</option>
                    <option value="D">Days</option>
                    <option value="W">Weeks</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="col-md-3 top10">
              <span class="badge-label ">Delivery Charge</span>
              <input class="form-control deliv_charge" onkeypress="return isNumber(event)" name="product_variant[<?=$var_grp_sno?>][<?=$var_sno?>][deliv_charge]">
            </div>
            <div class="col-md-3 top10">            
              <div class="form-group">
               <span class="badge-label">COD Available<span class="redstar">*</span></span><br/>
               <div class="radio">
                <label>
                  <input type="radio" class="cod_available" name="product_variant[<?=$var_grp_sno?>][<?=$var_sno?>][cod_available]" value="Y" checked>Yes
                </label>
              </div>
              <div class="radio">
                <label>
                  <input type="radio" class="cod_available" name="product_variant[<?=$var_grp_sno?>][<?=$var_sno?>][cod_available]" value="N">No
                </label>
              </div>              
            </div>
            <input type="hidden" name="product_variant[<?=$var_grp_sno?>][<?=$var_sno?>][type]" value="<?=$row_type?>">
          </div>
        </div>
        <br/>
      </div>
    <?php } ?>   
    <button type="button" class="collapsible collapsebtn">Add Images </button>
    <div class="divStockContent" style="overflow-y:scroll;">
      <br/>
      <div class="row">
        <?php for ($i=0; $i <=5 ; $i++) { $uid=uniqid(time(), true);?>
         <div class="col-md-2 top20 img-col">
          <div class="avatar-upload">
            <div class="avatar-edit">
              <input type='file' class="img" id="img<?=$uid;?>" name="img[]" multiple accept=".png, .jpg, .jpeg, .bmp" />
              <label for="img<?=$uid;?>"><i class="fa fa-pencil-alt"></i></label>
            </div>
            <div class="avatar-preview">
              <div class="imagePreview" style="background-image: url(img/pl_hold_img.png);">
              </div>
            </div>
          </div>
        </div>       
      <?php } ?>
    </div>       
  </div>      
</div>
<div class="col-md-1" style="align-self: center;text-align: center;"><button type="button" class="rem_variant btn btn-danger btn-circle" title="Remove Product Variant"><i class="far fa-trash-alt" ></i></button>
</div>
</div> <!-- Row ends -->
<br>
</div> <!-- Field wrapper -->
<script type="text/javascript">
  $('.select').select2();
  function readURL(input) {
    $tis=$(input);
    if (input.files && input.files[0]) {
      var extension = input.files[0].name.split('.').pop().toLowerCase();
      var reader = new FileReader();
      reader.onload = function(e) {
        $tis.parent().parent().find('.imagePreview').css('background-image', 'url('+e.target.result +')');
        $tis.parent().parent().find('.imagePreview').hide();
        $tis.parent().parent().find('.imagePreview').fadeIn(650);
      }
      reader.readAsDataURL(input.files[0]);
    }
  }
  $(".img").change(function() {
    readURL(this);
  });
</script>
<?php break;
}

case "featured_title_edit":{
 $res = $db->getRow("SELECT * FROM featured_title where featured_title_id=".$_POST['id']);?>
 <input type="hidden" name="featured_title_id" value="<?= $res['featured_title_id'] ?>" />
 <div class="row">
  <div class="col-md-12 top15">
    <span class="badge-label">Name</span>
    <input class="form-control name" name="name" value="<?= $res['name'] ?>">
  </div>
  <div class="col-md-12 top10">
    <span class="badge-label p-2">Status</span>
    <div class="switch top10">
      <label>Inactive
        <input type="checkbox" <?= $res['status']=='A'?'checked="true"':''; ?> name="status" value="A" >
        <span class="lever"></span> Active
      </label>
    </div>
  </div>
</div>   
<?php
break;
}
case "featured_product_edit":{
  $res = $db->getRow("SELECT featured_product.*,main_category.main_category_id,category.category_id,sub_category.sub_category_id,product.brand_id FROM featured_product left join product on product.product_id=featured_product.product_id left join sub_category on sub_category.sub_category_id=product.sub_category_id left join category on category.category_id=sub_category.category_id left join main_category on main_category.main_category_id=category.main_category_id where featured_product_id=".$_POST['id']);?>
  <input type="hidden" name="featured_product_id" value="<?= $res['featured_product_id'] ?>" />
  <div class="row">
    <div class="col-md-6 top15">
      <span class="badge-label">Main Category<span class="redstar">*</span></span>
      <select name="main_category_id" class="select form-control main_category_id" onchange="get_categories(this,this.value);">
        <option value="0">Select Main Category</option>
        <?php  $opts = $db->getRows("SELECT main_category_id,name FROM main_category order by name");
        if( count($opts) > 0){
          foreach($opts as $opt){ ?>
            <option <?= $opt['main_category_id']==$res['main_category_id']?' selected="true"':'';?> value="<?= $opt["main_category_id"] ?>"><?= $opt["name"] ?></option>
          <?php } 
        }?>     
      </select>
    </div>
    <div class="col-md-6 top15">
      <span class="badge-label">Category</span>
      <select name="category_id" class="select form-control category_id" onchange="get_sub_categories(this,this.value);">
        <option value="0">Select Category</option>
        <?php  $opts = $db->getRows("SELECT category_id,name FROM category where main_category_id=".$res['main_category_id']." order by name");
        if( count($opts) > 0){
          foreach($opts as $opt){ ?>
            <option <?= $opt['category_id']==$res['category_id']?' selected="true"':'';?> value="<?= $opt["category_id"] ?>"><?= $opt["name"] ?></option>
          <?php } 
        }?>     
      </select>
    </div>
  </div>
  <div class="row">
    <div class="col-md-6 top15">
      <span class="badge-label">Sub Category</span>
      <select name="sub_category_id" class="select form-control sub_category_id">
        <option value="0">Select Sub Category</option>
        <?php  $opts = $db->getRows("SELECT sub_category_id,name FROM sub_category where category_id=".$res['category_id']." order by name");
        if( count($opts) > 0){
          foreach($opts as $opt){ ?>
            <option <?= $opt['sub_category_id']==$res['sub_category_id']?' selected="true"':'';?> value="<?= $opt["sub_category_id"] ?>"><?= $opt["name"] ?></option>
          <?php } 
        }?>     
      </select>
    </div>

    <div class="col-md-6 top15">
      <span class="badge-label">Brand</span>
      <select name="brand_id" class="select form-control brand_id" onchange="get_prods(this)">
        <option value="0">Select Brand</option>
        <?php  $opts = $db->getRows("SELECT brand_id,name FROM brand order by name");
        if( count($opts) > 0){
          foreach($opts as $opt){ ?>
            <option <?= $opt['brand_id']==$res['brand_id']?' selected="true"':'';?> value="<?= $opt["brand_id"] ?>"><?= $opt["name"] ?></option>
          <?php } 
        }?>     
      </select>
    </div>
  </div>
  <div class="row">
    <div class="col-md-6 top15">
      <span class="badge-label">Product</span>
      <select name="product_id" class="select form-control product_id">
        <option value="0">Select Product</option>
        <?php  $opts = $db->getRows("SELECT product_id,name FROM product order by name");
        if( count($opts) > 0){
          foreach($opts as $opt){ ?>
            <option <?= $opt['product_id']==$res['product_id']?' selected="true"':'';?> value="<?= $opt["product_id"] ?>"><?= $opt["name"] ?></option>
          <?php } 
        }?>     
      </select>
    </div>
    <div class="col-md-6 top15">
      <span class="badge-label">Featured Title</span>
      <select name="featured_title_id" class="select form-control featured_title_id">
        <option value="0">Select Featured Title</option>
        <?php  $opts = $db->getRows("SELECT featured_title_id,name FROM featured_title order by name");
        if( count($opts) > 0){
          foreach($opts as $opt){ ?>
            <option <?= $opt['featured_title_id']==$res['featured_title_id']?' selected="true"':'';?> value="<?= $opt["featured_title_id"] ?>"><?= $opt["name"] ?></option>
          <?php } 
        }?>     
      </select>
    </div>
  </div>
  <script type="text/javascript">
    $('.select').select2();
    function get_categories(ele,id)
    {
      $tis=$(ele);
      $tis.parent().parent().find(".category_id").html(''); 
      $tis.parent().parent().find(".sub_category_id").html('<option value="0">Select Sub Category</option>'); 
      $tis.parent().parent().parent().find(".product_id").html('<option value="0">Select Product</option>'); 
      $.ajax({
        type: "POST",
        url : "aj_data.php",
        data: 'action=get_categories&main_category_id='+id,
        success: function(msg){
         $tis.parent().parent().find(".category_id").html(msg); 
       }
     });
    }
    function get_sub_categories(ele,id)
    {
      $tis=$(ele);
      $tis.parent().parent().parent().find(".sub_category_id").html(''); 
      $tis.parent().parent().parent().find(".product_id").html('<option value="0">Select Product</option>'); 
      $.ajax({
        type: "POST",
        url : "aj_data.php",
        data: 'action=get_sub_categories&category_id='+id,
        success: function(msg){
         $tis.parent().parent().parent().find(".sub_category_id").html(msg); 
       }
     });
    }
    function get_prods(ele)
    {
      $tis=$(ele);
      $tis.parent().parent().parent().find(".product_id").html(''); 

      sub_category_id=$tis.parent().parent().parent().find(".sub_category_id").val(); 
      brand_id=$tis.parent().parent().parent().find(".brand_id").val(); 

      if(sub_category_id!=0 && brand_id!=0){
        $.ajax({
          type: "POST",
          url : "aj_data.php",
          data: 'action=get_prods&sub_category_id='+sub_category_id+'&brand_id='+brand_id,
          success: function(msg){
           $tis.parent().parent().parent().find(".product_id").html(msg); 
         }
       })
      }    
    }  
  </script>   
  <?php
  break;
}
case "tax_edit":{
 $res = $db->getRow("SELECT * FROM tax where tax_id=".$_POST['id']);?>
 <input type="hidden" name="tax_id" value="<?= $res['tax_id'] ?>" />
 <div class="row">
  <div class="col-md-12 top15">
    <span class="badge-label">Code<span class="redstar">*</span></span>
    <input class="form-control name" name="name" value="<?= $res['name'] ?>">
  </div>
  <div class="col-md-12 top15">
    <span class="badge-label">Tax %<span class="redstar">*</span></span>
    <input class="form-control tax_percent" maxlength="5" onkeypress="return isNumber(event)" value="<?= $res['tax_percent'] ?>" name="tax_percent">
    <div class="col-md-12 top10">
      <span class="badge-label p-2">Status</span>
      <div class="switch top10">
        <label>Inactive
          <input type="checkbox" <?= $res['status']=='A'?'checked="true"':''; ?> name="status" value="A" >
          <span class="lever"></span> Active
        </label>
      </div>
    </div>
  </div>   
  <?php
  break;
}
case "seller_edit":{
 $res = $db->getRow("SELECT * FROM seller where seller_id=".$_POST['id']);?>
 <input type="hidden" name="seller_id" value="<?= $res['seller_id'] ?>" />
 <div class="row">
  <div class="col-md-12">
    <span class="badge-label">Name</span>
    <input class="form-control name" name="name" value="<?= $res['name'] ?>">
  </div>
  <div class="col-md-12 top15">
    <span class="badge-label">Type<span class="redstar">*</span></span>
    <div class="form-group">
      <div class="pure-checkbox" style="display: inline-block;">
        &nbsp;<input type="checkbox" <?=(strpos($res['type'],'W') !== false)?'checked':'';?> id="typeW1" class="type_opts" value="W" style="opacity:2" name="type[]"><label for="typeW1">Whole Sale</label>
      </div>
      <div class="pure-checkbox" style="display: inline-block;">
        &nbsp;<input type="checkbox" <?=(strpos($res['type'],'S') !== false)?'checked':'';?> id="typeS1" class="type_opts" value="S" style="opacity:2" name="type[]"><label for="typeS1">Semi Whole Sale</label>
      </div>
      <div class="pure-checkbox" style="display: inline-block;">
        &nbsp;<input type="checkbox" <?=(strpos($res['type'],'R') !== false)?'checked':'';?> id="typeR1" class="type_opts" value="R" style="opacity:2" name="type[]"><label for="typeR1">Retail</label>
      </div>
    </div>
  </div>
  <div class="col-md-6 top15">
    <span class="badge-label">Password</span>
    <input class="form-control password" type="password" name="password" value="<?= $res['password'] ?>">
  </div>
  <div class="col-md-6 top15">
    <span class="badge-label">Email</span>
    <input class="form-control email" name="email" value="<?= $res['email'] ?>">
  </div>  
  <div class="col-md-6 top15">
    <span class="badge-label">Mobile</span>
    <input class="form-control mobile" name="mobile" value="<?= $res['mobile'] ?>">
  </div>
  <div class="col-md-6 top15">
    <span class="badge-label">PIN</span>
    <input class="form-control pin" name="pin" value="<?= $res['pin'] ?>">
  </div>
  <div class="col-md-6 top15">
    <span class="badge-label">Address</span>
    <textarea class="form-control address" rows="6" name="address"><?= $res['address'] ?></textarea>
  </div>
  <div class="col-md-6 top15">
    <span class="badge-label">Image<span class="redstar"></span></span>
    <div class="avatar-upload">
      <div class="avatar-edit">
        <input type='file' id="img1" name="img" class="img" accept=".png, .jpg, .jpeg, .bmp" />
        <label for="img1"><i class="fa fa-pencil-alt"></i></label>
      </div>
      <div class="avatar-preview">
        <div class="imagePreview" style="background-image: url(<?php echo !empty($res['img'])?'../uploads/seller/'.$res["img"]:'img/pl_hold_img.png'; ?>">
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-12 top10">
    <span class="badge-label p-2">Status</span>
    <div class="switch top10">
      <label>Inactive
        <input type="checkbox" <?= $res['status']=='A'?'checked="true"':''; ?> name="status" value="A" >
        <span class="lever"></span> Active
      </label>
    </div>
  </div>
</div>
<input type="hidden" name="cur_password" value="<?= $res['password'] ?>">
<script>
  function readURL(input) {
    $tis=$(input);
    if (input.files && input.files[0]) {
      var extension = input.files[0].name.split('.').pop().toLowerCase();
      var reader = new FileReader();
      reader.onload = function(e) {
        $tis.parent().parent().find('.imagePreview').css('background-image', 'url('+e.target.result +')');
        $tis.parent().parent().find('.imagePreview').hide();
        $tis.parent().parent().find('.imagePreview').fadeIn(650);
      }
      reader.readAsDataURL(input.files[0]);
    }
  }
  $(".img").change(function() {
    readURL(this);
  });
</script>
<?php
break;
}
case "top_seller_edit":{
 $res = $db->getRow("SELECT * FROM top_seller where top_seller_id=".$_POST['id']);?>
 <input type="hidden" name="top_seller_id" value="<?= $res['top_seller_id'] ?>" />
 <div class="row">
  <div class="col-md-12 top15">
    <span class="badge-label">Seller</span>
    <select name="seller_id" class="select form-control seller_id">
      <option value="0">Select Seller</option>
      <?php  $opts = $db->getRows("SELECT seller_id,name FROM seller where type like '%".strtoupper($_POST['type'])."%' order by name");
      if( count($opts) > 0){
        foreach($opts as $opt){ ?>
          <option <?= $opt['seller_id']==$res['seller_id']?' selected="true"':'';?> value="<?= $opt["seller_id"] ?>"><?= $opt["name"] ?></option>
        <?php } 
      }?>     
    </select>
  </div>   
  <div class="col-md-12 top10">
    <span class="badge-label p-2">Status</span>
    <div class="switch top10">
      <label>Inactive
        <input type="checkbox" <?= $res['status']=='A'?'checked="true"':''; ?> name="status" value="A" >
        <span class="lever"></span> Active
      </label>
    </div>
  </div>
</div>
<script>
  $('.select').select2();
</script>
<?php
break;
}
case 'get_sellers':{
  ?>
  <option value="">Select Seller</option>
  <?php  
  $res  = $db->getRows("SELECT seller_id,name FROM seller where type like '%".strtoupper($_POST['type'])."%' order by name");
  if( count($res) > 0){
    foreach($res as $res1){ ?>
      <option value="<?php echo $res1["seller_id"] ?>"><?= $res1['name']; ?></option>
    <?php }
  } ?>
  <?php
  break;
}
case 'get_seller_prods':{
  ?>
  <option value="">Select Product</option>
  <?php  
  $res  = $db->getRows("SELECT product_id,name FROM product where created_by=".$_POST['seller_id']." order by name");  
  if( count($res) > 0){
    foreach($res as $res1){ ?>
      <option value="<?php echo $res1["product_id"] ?>"><?= $res1['name']; ?></option>
    <?php }
  } ?>
  <?php
  break;
}
case 'get_prod_vars':{
  ?>
  <option value="">Select Variant</option>
  <?php  
  $res  = $db->getRows("SELECT product_variant_id,price_qty,price,unit.name FROM product_variant left join unit on unit.unit_id=product_variant.price_unit_id where product_id=".$_POST['product_id']." order by name");

  if( count($res) > 0){
    foreach($res as $res1){ ?>
      <option value="<?php echo $res1["product_variant_id"] ?>"><?= $res1['price_qty'].' '.$res1['name'].' / &#8377;&nbsp;'.$res1['price']; ?></option>
    <?php }
  } ?>
  <?php
  break;
}
case "today_market_edit":{
 $res = $db->getRow("SELECT today_market.*,product.created_by as seller_id FROM today_market left join product on product.product_id=today_market.product_id where today_market_id=".$_POST['id']);?>
 <input type="hidden" name="today_market_id" value="<?= $res['today_market_id'] ?>" />
 <div class="row"> 
  <div class="col-md-12 top15">
    <span class="badge-label">Seller Type</span>
    <select class="select form-control seller_type" name="seller_type" onchange="get_sellers(this,this.value);">
      <option value="0">Select Type</option>
      <option <?=(strpos($res['seller_type'],'W') !== false)?'selected="true"':'';?> value="W">Whole Sale</option>
      <option <?=(strpos($res['seller_type'],'S') !== false)?'selected="true"':'';?> value="S">Semi Whole Sale</option>
      <option <?=(strpos($res['seller_type'],'R') !== false)?'selected="true"':'';?> value="R">Retail</option>
    </select>
  </div>
  <div class="col-md-12 top15">
    <span class="badge-label">Seller</span>
    <select name="seller_id" class="select form-control seller_id" onchange="get_seller_prods(this,this.value);">
      <option value="0">Select Seller</option>
      <?php  $opts = $db->getRows("SELECT seller_id,name FROM seller where type like '%".strtoupper($res['type'])."%' order by name"); //echo $db->getLastQuery(); exit;
      if( count($opts) > 0){
        foreach($opts as $opt){ ?>
          <option <?= $opt['seller_id']==$res['seller_id']?' selected="true"':'';?> value="<?= $opt["seller_id"] ?>"><?= $opt["name"] ?></option>
        <?php } 
      }?>     
    </select>
  </div>
  <div class="col-md-12 top15">
    <span class="badge-label">Product</span>
    <select name="product_id" class="select form-control product_id" onchange="get_prod_vars(this,this.value);">
      <option value="0">Select Product</option>
      <?php  $opts = $db->getRows("SELECT product_id,name FROM product where created_by=".$res['seller_id']." order by name");
      if( count($opts) > 0){
        foreach($opts as $opt){ ?>
          <option <?= $opt['product_id']==$res['product_id']?' selected="true"':'';?> value="<?= $opt["product_id"] ?>"><?= $opt["name"] ?></option>
        <?php } 
      }?>     
    </select>
  </div>
   <div class="col-md-12 top15">
    <span class="badge-label">Product Variant</span>
    <select name="product_variant_id" class="select form-control product_variant_id">
      <option value="0">Select Variant</option>
      <?php  
       $opts  = $db->getRows("SELECT product_variant_id,price_qty,price,unit.name FROM product_variant left join unit on unit.unit_id=product_variant.price_unit_id where product_id=".$res['product_id']." order by name");
      if( count($opts) > 0){
        foreach($opts as $opt){ ?>
          <option <?= $opt['product_variant_id']==$res['product_variant_id']?' selected="true"':'';?> value="<?= $opt["product_variant_id"] ?>"><?= $opt['price_qty'].' '.$opt['name'].' / &#8377;&nbsp;'.$opt['price']; ?></option>
        <?php } 
      }?>     
    </select>
  </div>
  <div class="col-md-12 top10">
    <span class="badge-label p-2">Status</span>
    <div class="switch top10">
      <label>Inactive
        <input type="checkbox" <?= $res['status']=='A'?'checked="true"':''; ?> name="status" value="A" >
        <span class="lever"></span> Active
      </label>
    </div>
  </div>
</div>
<script>
  $('.select').select2();

   
</script>
<?php
break;
}


}
?>