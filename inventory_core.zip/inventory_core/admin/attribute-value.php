<?php include("../config.php");

if(empty($_SESSION["Users_Id"]))  {
  echo "<script>window.location.href='login.php';</script>";
}

$view_perm=$add_perm=$edit_perm=$del_perm=true;  

if(!empty($_GET['attribute_id'])){
  $res = $db->getRow("SELECT name FROM attribute where attribute_id=".$_GET['attribute_id']);
  $list_attribute_name=$res['name'];
  $list_attribute_id=$_GET['attribute_id'];
}
else{
 $list_attribute_id=0;
 $list_attribute_name='';
}

if(isset($_GET['id']))
  $cond=" where attribute_value.attribute_id=".$_GET['id'];
else
  $cond="";

if (isset($_SESSION['success']) && ($_SESSION['success'] != "")) {
  $stat['success'] = $_SESSION['success'];
  unset($_SESSION['success']);
}
if (isset($_SESSION['error']) && ($_SESSION['error'] != "")) {
  $stat['danger'] = $_SESSION['error'];
  unset($_SESSION['error']);
}

if (!empty($_POST['attribute_value_id'])) {
  $save= $_POST;
  $save['status']=$save['status']!='A'?'I':'A';
  $save['modified_by']= $_SESSION["Users_Id"];
  $save['modified_date']= date('Y-m-d H:i:s'); 

  $res = $db->updateAry("attribute_value", $save, "where attribute_value_id=".$_POST['attribute_value_id']);

  unset($_POST);
  if(isset($res)){
    unset($_POST);
    $_SESSION['success'] = "Attribute value updated successfully.";    
  }
  else{
    $_SESSION['error'] ="Attribute value update failed.";
  }  

  redirect('attribute-value.php');
}
elseif (!empty($_POST['attr_value'])) 
{
 $save= $_POST;
 $save['status']=$save['status']!='A'?'I':'A'; 
 $save['created_by']= $_SESSION["Users_Id"];
 $save['created_date']= date('Y-m-d H:i:s');      

 $id = $db->insertAry('attribute_value',$save);
  // echo $db->getLastQuery(); exit;
 if(!is_null($id))
  $_SESSION['success'] = "Attribute value Added successfully.";
else
  $_SESSION['error'] ="Attribute value update failed.";
// echo $db->getLastQuery(); exit;
unset($_POST);
redirect('attribute-value.php');          
}
?>
<?php include 'includes/header.php'; ?>
<link href="dist/css/img_upl.css" rel="stylesheet">
<div class="row">                   
  <div class="col-lg-12 col-sm-12" style="padding: 0;"> 
    <div class="row panel panel-default" id="firstRow">      
      <div class="add-newproduct-tab">
        <div class="gradient-card-header">
          <h2 class="white-text mx-3"><?=!empty($list_attribute_id)?'Attribute Value for: '.$list_attribute_name:'Attribute Value';?></h2>
        </div>
      </div>
      <?php echo !empty($stat)?msg($stat):'';?>
      <div class="courseAddPrmssn" <?=!empty($list_attribute_id)?'style="display:none;"':''?>>
        <a <?=!isset($_GET['id'])?'style="display:none;"':''?> href="attribute.php" class="btn btn-info button-addnew pull-left" style="margin-bottom: 10px;"><i class="fa fa-angle-double-left" aria-hidden="true"></i>Go Back</a>          
        <button type="button" id="btn_add" class="btn btn-info button-addnew pull-right" ><i class="fa fa-angle-down" aria-hidden="true"></i>Add Attribute Value&nbsp;&nbsp; 
        </button>
        <br/><br/>
      </div>
      <div class="row col-lg-12">
        <a <?=empty($list_attribute_id)?'style="display:none;"':''?> href="attribute-value.php" class="btn btn-info button-addnew pull-left" style="margin-bottom: 10px;"><i class="fa fa-angle-double-left" aria-hidden="true"></i>Go Back</a>
      </div>
      <form method="post" class="frm-save" name="doc-register" enctype="multipart/form-data">
        <div id="content" class="panel panel-default" >
          <div class="panel-body">
            <div class="row">
             <div class="col-md-5">
              <span class="badge-label">Attribute Caption<span class="redstar">*</span></span>
              <select class="select form-control attribute_id" name="attribute_id">
                <option value="0">Select Attribute</option>
                <?php  $res = $db->getRows("SELECT attribute_id,name FROM attribute order by name");
                if( count($res) > 0){
                  foreach($res as $res1){ ?>
                    <option value="<?= $res1["attribute_id"] ?>"><?= $res1["name"] ?></option>
                  <?php } 
                }?>     
              </select>
            </div>      
            <div class="col-md-3">
              <span class="badge-label">Value<span class="redstar">*</span></span>
              <input class="form-control attr_value" name="attr_value">
            </div>
           <div class="col-md-3">
            <span class="badge-label p-2">Status</span>
            <div class="switch top10">
              <label>Inactive
                <input type="checkbox" checked="true" name="status" value="A" >
                <span class="lever"></span> Active
              </label>
            </div>
          </div>
          <div class="col-md-12">
            <div class="pull-right top30">
              <label class="err_lbl"></label>&nbsp;&nbsp;
              <button class="btn blue-gradient button-save btn-save" title="Save" type="button" name="saveGroup"><i class="fa fa-check" aria-hidden="true"></i> Add</button>
              <button type="reset" title="Cancel" class="btn danger-gradient button-cancel"><i class="fa fa-times" aria-hidden="true"></i> Clear</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </form>
  <div class="row">
    <div class="">
      <div class="panel-default">
        <div class="panel-body">
          <div style1="overflow-y: auto;">
            <form method="post">
              <table style="width: 100%" class="table table-striped table-hover table-bordered" id="data_table">
                <thead>
                  <tr>
                    <?php if(!empty($list_attribute_id)){ ?>
                      <th>Attribute Values</th>
                      <th>Status</th>
                      <th class="text-center">Action</th>
                    <?php } else { ?>
                      <th>Attribute Name</th>
                      <th>Attribute Values</th>
                      <th class="text-center">Action</th>
                    <?php } ?>
                  </tr>
                </thead>
                <tbody id="row-cont">
                  <?php
                    //get images from database                 

                  if(!empty($list_attribute_id)){
                    $res = $db->getRows("SELECT * FROM attribute_value where attribute_id=".$list_attribute_id." order by attribute_value_id desc");

                    if( count($res) > 0){
                      foreach($res as $key => $res1){ 
                        $id = $res1["attribute_value_id"];
                        ?>
                        <tr class="odd gradeX">
                          <td><?= $res1['attr_value']; ?></td>
                          <td class="<?= $res1['status']=='A'?'act-cls':'inact-cls'; ?>"><?= $res1['status']=='A'?'Active':'Inactive'; ?></td>
                          <td class="text-center">                                
                            <button class="btn_edit btn btn-primary btn-circle courseEditPrmssn" data-toggle="modal" data-target="#mod_data" name="edit" value="<?php echo $id ?>"  data-id="<?php echo $id ?>" ><i class="fa fa-pencil-alt" title="Edit"></i></button>
                            <button type="button" id="delete" onclick="del_confirm(this)" name="delete" value="<?php  echo $id ?>" class="btn btn-danger btn-circle courseDeletePrmssn" title="Delete"><i class="fa fa-times"></i>
                            </button>
                          </td>                          
                        </tr>
                      <?php  } }
                    }
                    else{
                      $res = $db->getRows("SELECT attribute_value.attribute_id,attribute.name FROM attribute_value left join attribute on attribute.attribute_id=attribute_value.attribute_id".$cond." group by attribute_id order by attribute_value_id desc");

                      if( count($res) > 0){
                        foreach($res as $key => $res1){ 
                          $res2 = $db->getRows("SELECT attr_value FROM attribute_value where attribute_id=".$res1['attribute_id']." order by attribute_value_id asc");
                          $values='';
                          foreach ($res2 as $val) {
                            if($values)
                              $values=$values.', '.$val['attr_value'];
                            else
                              $values=$val['attr_value'];
                          }
                          $id = $res1["attribute_id"];
                          ?>
                          <tr class="odd gradeX">
                            <td><?= $res1['name']; ?></td>
                            <td><?= $values; ?></td>
                            <td class="text-center">                                
                              <a class="btn btn-primary btn-circle courseEditPrmssn" href="attribute-value.php?attribute_id=<?php echo $id ?>"><i class="fa fa-pencil-alt" title="Edit"></i></a>
                              <input type="hidden" class="data_ord" name="data_ord[<?= $id; ?>]" value="<?= $key+1; ?>">                            
                            </td>                          
                          </tr>
                        <?php  }
                      }
                    } ?>                    
                  </tbody>                  
                </table>              
              </form>
            </div>
          </div> <!-- panel-body-->
        </div> <!-- panel-default-->
      </div> <!-- empty class-->
    </div> <!-- row-->
  </div>          
</div>
</div>
<div class="modal fade" id="mod_data" role="dialog">
  <div class="modal-dialog cascading-modal" role="document">
    <!--Content-->
    <div class="modal-content">
      <!--Header-->
      <div class="modal-header light-blue darken-3 white-text">
        <button type="button" class="close waves-effect waves-light" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
        <h4 class="title"><i class="fa fa-pencil-alt"></i> EDIT</h4>
      </div>
      <!--Body-->
      <div class="modal-body mb-0">
        <form method="post" class="frm-upd" enctype="multipart/form-data">
          <div id="upd"></div>
          <br/>
          <div class="text-center">
            <label class="err_lbl"></label><br>
            <button type="button" name="update" id="btn_upd" data-id="0" class=" btn btn-success button-update btn-save"><i class="fa fa-check" aria-hidden="true"></i>Update
            </button>
            <button type="button" data-dismiss="modal" class="btn btn-warning button-cancel"><i class="fa fa-times"></i>Cancel</button>
          </div>
          <br/>
        </form>
      </div>
    </div>
    <!--/.Content-->
  </div>
</div>
<?php include 'includes/footer.php'; ?>
<script>  
 $(document).ready(function() {
  $('.select').select2();

  $("#btn_add").click(function(){
    $("#content").toggle();
    $(this).find(".fa-angle-down").toggleClass('fa-angle-up');
  });
});
 $("#content").toggle();
 $(document).ready(function() {
  $('#data_table').DataTable({
    "scrollX": true,
    "columnDefs": [
    { "orderable": false, "targets": [2]},
    { "orderable": true, "targets": [0, 1]}
    ],
    "aaSorting": []
  });    
});
 $( ".btn_edit" ).click(function( event ) {
  event.preventDefault();

  var id =$(this).attr('data-id');
  $.ajax({
    url: 'aj_data.php',
    type: 'POST',
    data: 'action=attribute_value_edit&id='+id,
    dataType: 'html'
  })
  .done(function(data){      
    $('#upd').empty().append(data);
    $('#btn_upd').attr('data-id',id);
  })
  $('#mod_data').find('.err_lbl').html('');
  $('#mod_data').modal('show');
  return false;
});  
 function del_confirm(e) {
  var id = e.value;
  $.confirm({
    icon: 'fa fa-warning',
    title: 'Confirm!',
    content: 'Do you want to Delete ?',
    type: 'red',
    buttons: {
      confirm:  {
        btnClass: 'btn-red',
        action: function(){
          $.confirm({
            icon: 'fa fa-warning',
            title: 'Confirm!',
            content: 'If you Delete, You cant restore this record !',
            type: 'red',
            buttons: {
              Okay: {
                btnClass: 'btn-red',
                action: function(){
                  $.ajax({
                    type: 'post',
                    url: 'aj_data.php',
                    data: 'action=del_setting&type=attribute_value&id='+id,
                    dataType: "json",
                    success: function (data) {
                      if(data['validation'] == '1'){
                       window.location.reload();
                     }
                     else{
                      $.alert(data['message']);
                    }
                  }
                });
                }
              },
              Cancel: function () { },
            }
          });
        }
      },
      cancel: function () { },
    }
  });
}  

$(document).on('click','.btn-save',function(e){    
  $err_lbl= $(this).parent().find('.err_lbl');
  $err_lbl.html('');

  if($(this).attr('data-id')){
    $id=$(this).attr('data-id');
    $frm = $('.frm-upd');
  }
  else{
    $id =0;
    $frm = $('.frm-save');        
  }

  $val = '';
  $frm.find('input:text').each(function(){
    $(this).val($.trim($(this).val()));
  });

  $val=$frm.find('.attr_value').val();
  $attribute_id=$frm.find('.attribute_id').val();

  if($attribute_id =='' || $attribute_id ==0){
    $err_lbl.html('Please select attribute!');
    return false;
  }

  if($val ==''){
    $err_lbl.html('Please enter value!');
    return false;
  }      

  $chk_val=$val;   

  $.ajax({
    url : "aj_data.php",
    data: 'action=chk_dup&type=attribute_value&chk_fld=attr_value&chk_val='+$chk_val+'&chk_fld1=attribute_id&chk_val1='+$attribute_id+'&chk_id='+$id,
    success: function(res){
      res =$.trim(res);
      if(res=='E')
        $err_lbl.html('Attribute value already exists!');
      else
        $frm.submit();
    }
  }); 
}); 

</script>
