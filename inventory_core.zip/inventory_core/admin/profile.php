<?php 

 //Include database configuration file
 //include("../database/db_conection.php");
include '../config.php';
 
if(!empty($_SESSION["doctorlogin"]))
{
    if(!empty($_SESSION["dlogin"]))
    {
        $DoctorId = $_SESSION["dlogin"];
    }
    else { echo "<script>window.location.href='doctor_login.php';</script>"; }
}
else
{
    echo "<script>window.location.href='doctor_login.php';</script>";
}


    if (isset($_SESSION['success']) && ($_SESSION['success'] != "")) {
        $stat['success'] = $_SESSION['success'];
        unset($_SESSION['success']);
    }
    if (isset($_SESSION['error']) && ($_SESSION['error'] != "")) {
        $stat['error'] = $_SESSION['error'];
        unset($_SESSION['error']);
    }

    $validate=new Validation();

    if (isset($_POST['saveRegister'])) 
      {
        // print_r($_POST); exit;
        $active = isset($_POST['active'])?$_POST['active']:0;

        $Details = array(
          'doctorid'            => $DoctorId,
          'doctor_name'         => $_POST['doctorname'],
          'professional'        => $_POST['professional'],
          'experience'          => $_POST['experience'],
          'awards'              => $_POST['awards'],
          'mobile'              => $_POST['mobile'], 
          'land_line'           => $_POST['land-line'], 
          'email'               => $_POST['email'],
          'primary_address'     => $_POST['primary-address'], 
          'secondary_address'   => $_POST['secondary-address'], 
          'clinic_address'      => $_POST['clinic-address'],
          'active'              => $active,
          // 'password'            => '123456',
          // 'created_date'        => date('Y-m-d H:i:s')
        );

        if ($_FILES['imageUpload']['name'] != '') 
        {
          $fname = $_FILES['imageUpload']['name'];
          $ext = strtolower(substr($fname, strrpos($fname, '.') + 1));
          if (in_array($ext, array('jpeg', 'jpg', 'png','bmp'))) {
            $newfile = md5($_FILES['imageUpload']['tmp_name']) . "." . $ext;
            if (move_uploaded_file($_FILES['imageUpload']['tmp_name'], '../images/doctors_img/'.$CustomerId.'/'. $newfile)){
              $Details['image'] = $newfile;
            }
          }
        }

        $db->updateAry('doctors',$Details, "where doctorid='".$DoctorId."'");
        // echo $db->getLastQuery(); exit;
        unset($_POST);
        $_SESSION['success'] = "Details Updated successfully.";
        redirect('profile.php');
      }

  ?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Pet Butty</title>




    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">


     <link href="vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom Fonts -->
   
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css"/>

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<!-- <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> -->
<link href="dist/css/w3.css" rel="stylesheet">

<!----------------datatables---------->
 <link rel="stylesheet" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap.min.css">
 <link rel="stylesheet" href="https://cdn.datatables.net/fixedheader/3.1.4/css/fixedHeader.bootstrap.min.css">

 <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.2/css/responsive.bootstrap.min.css">

<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>


<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
<!------------------>
   
  
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">

<!---- Custom Css --->
<link href="dist/css/custom.css" rel="stylesheet">
<link href="dist/css/mdb-button-styles.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css?family=Tangerine|Inconsolata|Droid+Sans|Josefin+Sans|Roboto:400|Open+Sans:600|Sansita:400,800,900|Redressed
" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons">

</head>
<style type="text/css">
  a.sec-address, a.pri-address{
    text-decoration: none;
    cursor: pointer;
    margin-left: 55px;
    color: #8a8a8a;  
  }
.avatar-upload .avatar-edit input {

    display: none !important;

}
.avatar-upload {

    position: relative;
    /*max-width: 205px;*/
    /*margin: 55px auto;*/

}
.avatar-upload .avatar-edit {
    position: absolute;
    /* right: 0; */
    z-index: 1;
    top: 0px;
    right: 45px;

}

.avatar-upload .avatar-edit input + label {

    display: inline-block;
    width: 40px;
    height: 40px;
    margin-bottom: 0;
    border-radius: 100%;
    background: #FFFFFF;
    border: 1px solid transparent;
    /* box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.12); */
    box-shadow: 0px 0px 18px 0px rgb(54, 102, 185);
    cursor: pointer;
    font-weight: normal;
    transition: all 0.2s ease-in-out;

}
.avatar-upload .avatar-edit label i{
      /*content: "\f040";*/
    /*font-family: 'FontAwesome';*/
    color: #6b6b6b;
    position: absolute;
    top: 11px;
    left: 0;
    right: 0;
    font-size: 17px;
    text-align: center;
    margin: auto;
}
/*.avatar-upload .avatar-edit input + label::after {

    content: "\f040";
    font-family: 'FontAwesome';
    color: #e53031;
    position: absolute;
    top: 6px;
    left: 0;
    right: 0;
    text-align: center;
    margin: auto;

}*/
.avatar-upload .avatar-preview {

    width: 195px;
    height: 195px;
    position: relative;
    border-radius: 100%;
    /* border: 6px solid #F8F8F8; */
    /* box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.1); */
    box-shadow: 0 5px 15px 0 rgba(0,0,0,.18), 0 4px 15px 0 rgba(0,0,0,.15);
    margin: 0 auto 1em;

}
.avatar-upload .avatar-preview > div {

    width: 100%;
    height: 100%;
    border-radius: 100%;
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center;

} 

</style>
<body >

    <?php 
    $DocDetails = $db->getRow("select * from doctors where doctorid='".$DoctorId."' ");
    $arrProfessional = array(
        'Nutrition'=>'Nutrition',
        'Veterinary'=>'Veterinary',
        'Dental Specialist'=>'Dental Specialist',
        'Health&Care'=>'Health&Care'
    );
    ?>    
<!--------------------->
    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top w3-card-2" role="navigation"   style="margin-bottom: 0px">
            <div class="navbar-header" style="background-color: white">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>

                </button>
                <!-- <img src="../images/them-logo/petbuttylogo3.jpg" class="img-responsive" style="height: 60px;"> -->
            </div>
            <!-- /.navbar-header -->

            <div class="nav navbar-top-links navbar-right">
               
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        Welcome, <?php echo $DocDetails['doctor_name'] ?><i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                      <!--   <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li> -->
                       <!--  <li class="divider"></li> -->
                        <li><a href="login.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </div>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation"  style="background-color: white;">
                <div class="sidebar-nav navbar-collapse" style="padding: 12px;">
                    <ul class="nav" id="side-menu">
                      
                        <li>
                            <a href="doctor_home.php"><i class="material-icons">
                            dashboard
                            </i> Dashboard</a>
                        </li>
                        <li>
                            <a href="profile.php"><i class="material-icons">
                            person
                            </i> My Account</a>
                        </li>

                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>


<!-- /#page-wrapper -->
    <div id="page-wrapper">
      <div class="container-fluid">
        <?php //alert
            if (isset($stat) && $stat != "") {
                echo msg($stat);
            }
        ?>
        <form method="post" id="doc-register" name="doc-register" >
        <div class="row panel panel-default" style=" margin-top: 3em; padding: 0px 25px;">
          <div class="">
            <div class="gradient-card-header">
                <h2 class="white-text mx-3">Profile Details</h2>
            </div>

      <div class="row top15">
        <div class="">
          <div class="panel-default">
            <div class="panel-body">
              <form method="post" id="doc-register" name="doc-register" enctype="multipart/form-data">  
                <div class="">
                <br>
                <div class="row">
                  <div class="col-md-12" >
                    <div class="col-md-4">
                      <div class="avatar-upload">
                        <div class="avatar-edit">
                          <input type='file' id="imageUpload" name="imageUpload" accept=".png, .jpg, .jpeg, .txt, .docx" />
                          <label for="imageUpload"><i class="fa fa-pencil-alt"></i></label>
                        </div>
                        <div class="avatar-preview">
                          <div id="imagePreview" style="background-image: url(../images/doctors_img/<?= $DocDetails['image'] ?>);">
                          </div>
                        </div>
                        <p class="uload_img_text text-center">Profile Image</p>
                      </div>
                    </div>
                    <div class="col-md-8" style="padding-left: 0;padding-right: 0">
                      <div class="col-md-6" >
                        <span class="badge-label">Doctor Name</span>
                        <input class="form-control" name="doctorname" value="<?= $DocDetails['doctor_name'] ?>" required="">
                      </div>
                      <div class="col-md-6">
                        <span class="badge-label">Professional</span>
                        <input class="form-control" name="professional" value="<?= $DocDetails['professional'] ?>"  required="">
                      </div> 
                      <div class="col-md-12 top15">
                        <span class="badge-label">Experience</span>
                        <input class="form-control" name="experience" value="<?= $DocDetails['experience'] ?>"  required="">
                      </div>  
                      <div class="col-md-12 top15">
                        <span class="badge-label">Awards/Achievements</span>
                        <input class="form-control" name="awards" value="<?= $DocDetails['awards'] ?>"  required="">
                      </div>
                    </div>                
                  </div>
                </div>
                <div class="clearfix"></div>
                <br/>

                  <div class="col-md-4">
                    <span class="badge-label">Mobile</span>
                    <input class="form-control" name="mobile" value="<?= $DocDetails['mobile'] ?>"  required="">
                  </div>
                  <div class="col-md-4">
                    <span class="badge-label">Land Line</span>
                    <input class="form-control" name="land-line" value="<?= $DocDetails['land_line'] ?>" required="">
                  </div>    
                  <div class="col-md-4">
                    <span class="badge-label">Email Id</span>
                    <input type="email" class="form-control" name="email" value="<?= $DocDetails['email'] ?>" required="">
                  </div>              
                  <div class="clearfix"></div>
                  <br/>
                  <div class="col-md-4">
                    <span class="badge-label p-2">Primary Address</span>
                    <a class="pri-address"><i class="fa fa-copy"></i> copy</a>
                    <textarea title="Primary Address" class="form-control" name="primary-address" id="primary-address" required="" maxlength="255"><?= $DocDetails['primary_address'] ?></textarea>
                  </div>  
                  <div class="col-md-4">
                    <span class="badge-label p-2">Secondary Address</span>
                    <a class="sec-address"><i class="fa fa-copy"></i> copy</a>
                    <textarea title="Secondary Address" class="form-control" name="secondary-address" id="secondary-address" required="" maxlength="255"><?= $DocDetails['secondary_address'] ?></textarea>
                  </div> 
                  <div class="col-md-4">
                    <span class="badge-label p-2">Clinic Address</span>
                    <textarea title="Clinic Address" class="form-control" name="clinic-address" required="" maxlength="255"><?= $DocDetails['clinic_address'] ?></textarea>
                  </div>                     
                  <div class="clearfix"></div>
                  <br/>
                  <div class="col-md-4">
                    <div class="pure-checkbox">
                      <span class="badge-label p-2">Active</span>
                      &nbsp;&nbsp;&nbsp;<input type="checkbox" id="active" value="1"  style="opacity:2" name="active" <?php if($DocDetails['Active'] == 1){echo 'checked';} ?>><label  for="active"></label>
                    </div>
                  </div>   
                  <br/>                               
                </div>
                <div class="pull-right">
                  <button class="btn blue-gradient button-save" id="submitButton" title="Save" type="submit" name="saveRegister"><i class="fa fa-check" aria-hidden="true"></i> Update</button>
                  <button type="reset" title="Cancel" class="btn danger-gradient button-cancel"><i class="fa fa-times" aria-hidden="true"></i> Cancel</button>
                </div>
              </form>
              </div> <!-- /.Panel body -->
            </div> <!-- /.Panel default -->
          </div>
        </div>
            
          </div>

        </div>
        </form>
    </div> <!-- /.container-fluid -->
  </div> <!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->

    <!-- jQuery -->
<script>
if ( window.history.replaceState ) {
      window.history.replaceState( null, null, window.location.href );
    }
</script>
<!------------------------>
    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>

</body>

</html>
