<?php include("../config.php");

if(empty($_SESSION["Users_Id"]))  {
  echo "<script>window.location.href='login.php';</script>";
}

$view_perm=$add_perm=$edit_perm=$del_perm=true;  

if (isset($_SESSION['success']) && ($_SESSION['success'] != "")) {
  $stat['success'] = $_SESSION['success'];
  unset($_SESSION['success']);
}
if (isset($_SESSION['error']) && ($_SESSION['error'] != "")) {
  $stat['danger'] = $_SESSION['error'];
  unset($_SESSION['error']);
}

include('functions.php');

if (!empty($_POST['data_ord'])) {
  foreach ($_POST['data_ord'] as $key => $ord) {
    $save=array();
    $save['sort_order'] = $ord;
    $res=$db->updateAry("brand", $save, "where brand_id=".$key);  
  }

  unset($_POST);
  if(isset($res)){
    unset($_POST);
    $_SESSION['success'] = "Records sorted successfully.";    
  }
  else{
    $_SESSION['error'] = "Records not sorted successfully.";    
  }  

  redirect('brand.php');
}
if (!empty($_POST['brand_id'])) {
  $save= $_POST;
  unset($save['img']);
  $save['status']=$save['status']!='A'?'I':'A';
  $save['slug']=slugify($save['name']);//.'-'.$_POST['brand_id'];
  $save['modified_by']= $_SESSION["Users_Id"];
  $save['modified_date']= date('Y-m-d H:i:s');

  if ($_FILES['img']['name'] != '') 
  {
    $fname = $_FILES['img']['name'];
    $ext = strtolower(substr($fname, strrpos($fname, '.') + 1));
    if (in_array($ext, array('jpeg', 'jpg', 'png','bmp'))) {
      $file_path='../uploads/brand';
      if(!file_exists($dir_exists))
        mkdir($file_path,0777,true); 

      // $newfile = md5($_FILES['img']['tmp_name']) . "." . $ext;
      $newfile =  $save['slug'].".".$ext;
      if (move_uploaded_file($_FILES['img']['tmp_name'], $file_path.'/'.$newfile)){
        $save['img'] = $newfile;
        $res = $db->getRow("SELECT img FROM brand where brand_id=".$_POST['brand_id']);
        if( count($res) > 0){ 
          if($newfile!=$res['img'])
            unlink($file_path.'/'.$res['img']);
        }
      }
    }
  }

  $res = $db->updateAry("brand", $save, "where brand_id=".$_POST['brand_id']);

  unset($_POST);
  if(isset($res)){
    unset($_POST);
    $_SESSION['success'] = "Brand updated successfully.";    
  }
  else{
    $_SESSION['error'] ="Brand update failed.";
  }  

  redirect('brand.php');
}
elseif (!empty($_POST['name'])) 
{
 $save= $_POST;
 unset($save['img']);
 $save['status']=$save['status']!='A'?'I':'A';
 $save['slug']=slugify($save['name']);
 $save['created_by']= $_SESSION["Users_Id"];
 $save['created_date']= date('Y-m-d H:i:s');

 if (!empty($_FILES['img']['name'])) 
 {
  $fname = $_FILES['img']['name'];
  $ext = strtolower(substr($fname, strrpos($fname, '.') + 1));
  if (in_array($ext, array('jpeg', 'jpg', 'png','bmp'))) {
            // $dir_exists='images/stu_profile_img/'.$CompId.'/'.$_POST['branch_id'].'/'.$StudentId;
    $file_path='../uploads/brand';
      // echo $file_path;die;
    if(!file_exists($file_path))
      mkdir($file_path,0777,true); 

    // $newfile = md5($_FILES['img']['tmp_name']) . "." . $ext;
    $newfile =  $save['slug'].".".$ext;
    if (move_uploaded_file($_FILES['img']['tmp_name'], $file_path.'/'.$newfile)){
      $save['img'] = $newfile;
    }
  }
}        

$id = $db->insertAry('brand',$save);
if(!is_null($id)){
  $save1=array();
  $save1['sort_order']=$id;
  $res = $db->updateAry("brand", $save1, "where brand_id=".$id);  
  
  if(!is_null($res))
    $_SESSION['success'] = "Brand Added successfully.";
  else
    $_SESSION['error'] ="Brand update failed.";
}
else
  $_SESSION['error'] ="Brand update failed.";
// echo $db->getLastQuery(); exit;



unset($_POST);
redirect('brand.php');          
}
?>
<?php include 'includes/header.php'; ?>
<link href="dist/css/img_upl.css" rel="stylesheet">
<div class="row">                   
  <div class="col-lg-12 col-sm-12" style="padding: 0;"> 
    <div class="row panel panel-default" id="firstRow">      
      <div class="add-newproduct-tab">
        <div class="gradient-card-header">
          <h2 class="white-text mx-3">Brand</h2>
        </div>
      </div>
      <?php echo !empty($stat)?msg($stat):'';?>
      <div class="courseAddPrmssn">               
        <button type="button" id="btn_add" class="btn btn-info button-addnew pull-right" ><i class="fa fa-angle-down" aria-hidden="true"></i>Add Brand &nbsp;&nbsp; 
        </button>
        <br/><br/>
      </div>
      <form method="post" class="frm-save" name="doc-register" enctype="multipart/form-data">
        <div id="content" class="panel panel-default">
          <div class="panel-body">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <span class="badge-label">Name<span class="redstar">*</span></span>
                  <input class="form-control name" name="name">
                </div>
                <div class="form-group">
                 <span class="badge-label p-2">Status</span>
                 <div class="switch top10">
                  <label>Inactive
                    <input type="checkbox" checked="true" name="status" value="A" >
                    <span class="lever"></span> Active
                  </label>
                </div>
              </div>
            </div>             

            <div class="col-md-3">
              <div class="avatar-upload"  style1="float: right;">
                <div class="avatar-edit">
                  <input type='file' class="img" id="img" name="img" accept=".png, .jpg, .jpeg, .bmp" />
                  <label for="img"><i class="fa fa-pencil-alt"></i></label>
                </div>
                <div class="avatar-preview">
                  <div class="imagePreview" style="background-image: url(img/pl_hold_img.png);">
                  </div>
                </div>
                <p class="uload_img_text text-center">Image</p>
              </div>
            </div>              
          </div>              
          <div class="row">
            <div class="col-md-8 top10">
              <div class="pull-right">
                <label class="err_lbl"></label>&nbsp;&nbsp;
                <button class="btn blue-gradient button-save btn-save" title="Save" type="button" name="saveGroup"><i class="fa fa-check" aria-hidden="true"></i> Add</button>
                <button type="reset" title="Cancel" class="btn danger-gradient button-cancel"><i class="fa fa-times" aria-hidden="true"></i> Clear</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </form>
    <div class="row">
      <div class="">
        <div class="panel-default">
          <div class="panel-body">
            <div style1="overflow-y: auto;">
              <form method="post" class="frm-sort">
                <table style="width: 100%" class="table table-striped table-hover table-bordered" id="data_table">
                  <thead>
                    <tr>
                     <th>Sort</th>
                     <th style="width: 20px;">SNo</th>
                     <th>Brand Name</th>
                     <th>Status</th>              
                     <th class="text-center">Action</th>
                   </tr>
                 </thead>
                 <tbody id="row-cont">
                  <?php
                    //get images from database
                  $res = $db->getRows("SELECT * FROM brand order by sort_order");
                    // echo $db->getLastQuery(); exit;
                  if( count($res) > 0){
                    foreach($res as $key => $res1){ 
                      $id = $res1["brand_id"];
                      ?>
                      <tr class="odd gradeX">
                       <td><?= $res1["sort_order"]; ?> </td>
                       <td style="cursor: move;"><?= $key+1; ?></td>
                       <td><?= $res1['name']; ?></td>
                       <td class="<?= $res1['status']=='A'?'act-cls':'inact-cls'; ?>"><?= $res1['status']=='A'?'Active':'Inactive'; ?></td>
                       <td class="text-center">                                
                        <button class="btn_edit btn btn-primary btn-circle courseEditPrmssn" data-toggle="modal" data-target="#mod_data" name="edit" value="<?php echo $id ?>"  data-id="<?php echo $id ?>" ><i class="fa fa-pencil-alt" title="Edit"></i></button>
                        <button type="button" id="delete" onclick="del_confirm(this)" name="delete" value="<?php  echo $id ?>" class="btn btn-danger btn-circle courseDeletePrmssn" title="Delete"><i class="fa fa-times"></i>
                        </button>
                        <input type="hidden" class="data_ord" name="data_ord[<?= $id; ?>]" value="<?= $key+1; ?>">                            
                      </td>                          
                    </tr>
                  <?php  }
                } ?>                    
              </tbody>                  
            </table>
            <?php if( count($res) > 0){?>
             <div class="col-md-12">
              <button type="button" id="btn_save_order" name="save_order" class="btn btn-info button-addnew pull-left">Save Order</button>
            </div>
          <?php } ?>
        </form>
      </div>
    </div> <!-- panel-body-->
  </div> <!-- panel-default-->
</div> <!-- empty class-->
</div> <!-- row-->
</div>          
</div>
</div>
<div class="modal fade" id="mod_data" role="dialog">
  <div class="modal-dialog cascading-modal" role="document">
    <!--Content-->
    <div class="modal-content">
      <!--Header-->
      <div class="modal-header light-blue darken-3 white-text">
        <button type="button" class="close waves-effect waves-light" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
        <h4 class="title"><i class="fa fa-pencil-alt"></i> EDIT</h4>
      </div>
      <!--Body-->
      <div class="modal-body mb-0">
        <form method="post" class="frm-upd" enctype="multipart/form-data">
          <div id="upd"></div>
          <br/>
          <div class="text-center">
            <label class="err_lbl"></label><br>
            <button type="button" name="update" id="btn_upd" data-id="0" class=" btn btn-success button-update btn-save"><i class="fa fa-check" aria-hidden="true"></i>Update
            </button>
            <button type="button" data-dismiss="modal" class="btn btn-warning button-cancel"><i class="fa fa-times"></i>Cancel</button>
          </div>
          <br/>
        </form>
      </div>
    </div>
    <!--/.Content-->
  </div>
</div>
<?php include 'includes/footer.php'; ?>
<script>
  function readURL(input) {
    $tis=$(input);
    if (input.files && input.files[0]) {
      var extension = input.files[0].name.split('.').pop().toLowerCase();
      var reader = new FileReader();
      reader.onload = function(e) {
        $tis.parent().parent().find('.imagePreview').css('background-image', 'url('+e.target.result +')');
        $tis.parent().parent().find('.imagePreview').hide();
        $tis.parent().parent().find('.imagePreview').fadeIn(650);
      }
      reader.readAsDataURL(input.files[0]);
    }
  }
  $(".img").change(function() {
    readURL(this);
  });

  $("#content").toggle();
  $(document).ready(function(){    
    $("#btn_add").click(function(){
      $("#content").toggle();
      $(this).find(".fa-angle-down").toggleClass('fa-angle-up');
    });  
    $('#data_table').DataTable({
      "scrollX": true,
      "columnDefs": [
      { "orderable": false, "targets": [4]},
      { "orderable": true, "targets": [0, 2,3]},
      {"visible": false, "targets": [0]}
      ],
      "order": [[ 0, "asc" ]],
      "rowReorder" : [ "dataSrc", [1]]
    });    
  });
  $( ".btn_edit" ).click(function( event ) {
    event.preventDefault();
    
    var id =$(this).attr('data-id');
    $.ajax({
      url: 'aj_data.php',
      type: 'POST',
      data: 'action=brand_edit&id='+id,
      dataType: 'html'
    })
    .done(function(data){      
      $('#upd').empty().append(data);
      $('#btn_upd').attr('data-id',id);
    })
    $('#mod_data').find('.err_lbl').html('');
    $('#mod_data').modal('show');
    return false;
  });
  $( "#btn_save_order" ).click(function( event ) {
    var table = $('#data_table').DataTable();
    var info = table.page.info();
    cur_page = info.page;

    $sno=(cur_page*10)+1;
    $("#row-cont tr").each(function( index ) {
      $(this).find('.data_ord').val($sno++);      
    });

    $('.frm-sort').submit();
  });  
  function del_confirm(e) {
    var id = e.value;
    $.confirm({
      icon: 'fa fa-warning',
      title: 'Confirm!',
      content: 'Do you want to Delete ?',
      type: 'red',
      buttons: {
        confirm:  {
          btnClass: 'btn-red',
          action: function(){
            $.confirm({
              icon: 'fa fa-warning',
              title: 'Confirm!',
              content: 'If you Delete, You cant restore this record !',
              type: 'red',
              buttons: {
                Okay: {
                  btnClass: 'btn-red',
                  action: function(){
                    $.ajax({
                      type: 'post',
                      url: 'aj_data.php',
                      data: 'action=del_setting&type=brand&id='+id,
                      dataType: "json",
                      success: function (data) {
                        if(data['validation'] == '1'){
                         window.location.reload();
                       }
                       else{
                        $.alert(data['message']);
                      }
                    }
                  });
                  }
                },
                Cancel: function () { },
              }
            });
          }
        },
        cancel: function () { },
      }
    });
  }  

  $(document).on('click','.btn-save',function(e){    
    $err_lbl= $(this).parent().find('.err_lbl');
    $err_lbl.html('');

    if($(this).attr('data-id')){
      $id=$(this).attr('data-id');
      $frm = $('.frm-upd');
    }
    else{
      $id =0;
      $frm = $('.frm-save');        
    }

    $val = '';
    $frm.find('input:text').each(function(){
      $(this).val($.trim($(this).val()));
    });

    $val=$frm.find('.name').val();

    if($val ==''){
      $err_lbl.html('Please enter name!');
      return false;
    }      

    $chk_val=$val;   

    $.ajax({
      url : "aj_data.php",
      data: 'action=chk_dup&type=brand&chk_fld=name&chk_val='+$chk_val+'&chk_id='+$id,
      success: function(res){
        res =$.trim(res);
        if(res=='E')
          $err_lbl.html('Brand already exists!');
        else
          $frm.submit();
      }
    }); 
  }); 

</script>
