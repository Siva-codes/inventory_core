<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Sample Inventory</title>    
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
  <!-- <link rel="stylesheet" href="examples/css/site.css"> -->
  <link rel="stylesheet" href="src/richtext.min.css">
  <!-- Bootstrap Core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- MetisMenu CSS -->
  <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">
  <!-- Custom CSS -->
  <link href="dist/css/sb-admin-2.css" rel="stylesheet">
  <!--gallery-->
  <link rel="stylesheet" href="dist/css/lightbox.min.css">

  <link href="vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">
  <!-- DataTables Responsive CSS -->
  <link href="vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">
  <!-- Custom Fonts -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script type="text/javascript" src="tableExport/tableExport.js"></script>
  <script type="text/javascript" src="tableExport/jquery.base64.js"></script>
  <script type="text/javascript" src="tableExport/html2canvas.js"></script>
  <script type="text/javascript" src="tableExport/jspdf/libs/sprintf.js"></script>
  <script type="text/javascript" src="tableExport/jspdf/jspdf.js"></script>
  <script type="text/javascript" src="tableExport/jspdf/libs/base64.js"></script>
  <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  <script type="text/javascript" src="tableExport/jspdf/libs/sprintf.js"></script>
  <script type="text/javascript" src="tableExport/jspdf/jspdf.js"></script>
  <script type="text/javascript" src="tableExport/jspdf/libs/base64.js"></script>

  <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
  <!-- <script src="//code.jquery.com/jquery-1.11.1.min.js"></script> -->

  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

  <!----------------datatables---------->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/fixedheader/3.1.4/css/fixedHeader.bootstrap.min.css">

  <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.2/css/responsive.bootstrap.min.css">

  <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

  <script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
  <script src="https://cdn.datatables.net/rowreorder/1.2.7/js/dataTables.rowReorder.min.js"></script>
  <!-- Select2 css and js file -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
  <!----------------jquery alert plugin---------->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.js"></script>
  <!---- Custom Css --->
  <link href="dist/css/custom.css" rel="stylesheet">
  <link href="dist/css/mdb-button-styles.css" rel="stylesheet">

  <link href="https://fonts.googleapis.com/css?family=Tangerine|Inconsolata|Droid+Sans|Josefin+Sans|Roboto:400|Open+Sans:600|Sansita:400,800,900|Redressed
  " rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/rowreorder/1.2.7/css/rowReorder.dataTables.min.css">
  <style type="text/css">
    /*.sidebar ul li a.active{
      box-shadow:none !important;
      background:none !important;
      }*/
      #page-wrapper {
        min-height: 790px !important;
      }

    </style>
  </head>
  <body>
    <?php if(!empty($_SESSION["Users_Id"])) { 
     $IsCategory=$IsAttributes=$IsNewproduct=$IsBanner=$IsFeatureProd=$IsOrders=$IsReturns=$IsCancels=
     $IsCustomers=$IsSalesGnrl=$IsSalesDtld=$IsReturnGnrl=$IsReturnDtld=$IsSubadminView=$IsSubadminAdd=
     $IsSubadminEdit=$IsDoctorView=$IsDoctorAdd=$IsDoctorEdit=$IsDoctorDelete=$IsConsultChrgView=
     $IsConsultRqustView='yes';
    // $LoggedIn = $db->getRow("SELECT * FROM musers where users_id='". $_SESSION["Users_Id"]."' ");
    // echo $db->getLastQuery();die;
    // $sm_branch_view = $LoggedIn['branch_view'];
    // $sm_branch_add = $LoggedIn['branch_add'];
    // $sm_branch_edit = $LoggedIn['branch_edit'];
    // $sm_branch_delete = $LoggedIn['branch_delete'];

    // if($sm_branch_view != "yes"){echo "<script>window.addEventListener('load', function(){ $('.branchViewPrmssn').css('display','none');});</script>";}
    // if($sm_branch_add != "yes"){echo "<script>window.addEventListener('load', function(){ $('.branchAddPrmssn').css('display','none');});</script>";}
    // if($sm_branch_edit != "yes"){echo "<script>window.addEventListener('load', function(){ $('.branchEditPrmssn').css('display','none');});</script>";}
    // if($sm_branch_delete != "yes"){echo "<script>window.addEventListener('load', function(){ $('.branchDeletePrmssn').css('display','none');});</script>";}
     ?>
     <div id="wrapper">
      <nav class="navbar navbar-default navbar-static-top  w3-card-2" role="navigation"   style="margin-bottom: 0px">
        <div class="navbar-header" style="background-color: white">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
        <div class="nav navbar-top-links navbar-right">
          <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Welcome, <?php echo $_SESSION["Users_Name"] ?>
            <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i></a>
            <ul class="dropdown-menu dropdown-user">
              <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
          </li>
        </div>
        <div class="navbar-default sidebar" role="navigation"  style="background-color: white;">
          <div id="navbar" class="sidebar-nav navbar-collapse collapse">
            <ul class="nav" id="side-menu">
              <li>
                <a href="index.php"><i class="material-icons">
                  dashboard
                </i> Dashboard</a>
              </li>
              <?php if($_SESSION["Users_Type"]=='A') { ?>   
               <li>
                <a href="banner.php"><i class="material-icons">
                  brush
                </i> Banner</a>
              </li>
              <li>
                <a href="seller.php"><i class="material-icons">
                  supervisor_account
                </i> Seller</a>
              </li>
               <li>
                <a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Top Seller</a>
                <ul class="nav nav-second-level">
                  <li>
                    <a href="top-seller.php?type=W"><i class="fa fa-angle-double-right" aria-hidden="true"></i> WholeSale</a>
                  </li>
                 <li>
                    <a href="top-seller.php?type=S"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Semi WholeSale</a>
                  </li>
                 <li>
                    <a href="top-seller.php?type=R"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Retail</a>
                  </li>
                </ul>
              </li>
                <li>
              <a href="product.php"><i class="material-icons">widgets</i> Product </a>
            </li>
              <!--  <li>
                <a href="today-market.php"><i class="material-icons">
                  article
                </i> Today Market Price</a>
              </li>
              <li>
                <a href="#"><i class="material-icons">
                  supervisor_account
                </i> Customer</a>
              </li>
              <li>
                <a href="#"><i class="material-icons">
                  shopping_cart
                </i> Order</a>
              </li>
              <li>
                <a href="#"><i class="material-icons">
                  library_books
                </i> Reports</a>
              </li>
              <li>
                <a href="#"><i class="fab fa-searchengin" style="font-size: 24px;padding-right: 15px;">
                </i> SEO</a>
              </li>
              <li>
                <a href="#"><i class="material-icons">
                  person
                </i> Admin</a>
              </li> -->
            </ul>
          </li>

        <?php }elseif($_SESSION["Users_Type"]=='S'){ ?> 
          <li>
            <a href="#"><i class="material-icons">
              local_offer
            </i> Catalog<span class="fa arrow"></span></a>
            <ul class="nav nav-second-level">

              <li>
                <a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Category <span class="fa arrow"></span></a>
                <ul class="nav nav-third-level">
                  <li>
                    <a href="main-category.php"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Main Category</a>
                  </li>
                  <li>
                    <a href="category.php"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Category</a>
                  </li>
                  <li>
                    <a href="sub-category.php"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Sub Category</a>
                  </li>

                </ul>
              </li>

              <li>
               <a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Attribute <span class="fa arrow"></span></a>
               <ul class="nav nav-third-level">
                <li>
                  <a href="attribute.php"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Attribute</a>
                </li>
                <li>
                  <a href="attribute-value.php"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Attribute Value</a>
                </li>
                <li>
                  <a href="attribute-map.php"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Attribute Mapping</a>
                </li>

              </ul> 
            </li>
            
            <li>
              <a href="brand.php"><i class="material-icons">web</i>Brand </a>
            </li>
            <li>
              <a href="unit.php"><i class="material-icons">poll</i>Measurement Unit</a>
            </li>
            <li>
              <a href="tax.php"><i class="material-icons">playlist_add</i>Tax</a>
            </li>

            <li>
              <a href="product.php"><i class="material-icons">widgets</i> Product </a>
            </li>

          </li>
        </ul>
      </li>
      <!-- <li>
        <a href="#"><i class="material-icons">
          supervisor_account
        </i> Customer</a>
      </li>
      <li>
        <a href="#"><i class="material-icons">
          shopping_cart
        </i> Order</a>
      </li>
      <li>
        <a href="#"><i class="material-icons">
          library_books
        </i> Reports</a>
      </li> -->
    <?php } ?>
  </ul>     
</div>
</div>
</nav>
<div id="page-wrapper">
  <div class="container-fluid"> 
  <?php } ?>    
