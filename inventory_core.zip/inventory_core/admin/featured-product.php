<?php include("../config.php");

if(empty($_SESSION["Users_Id"]))  {
  echo "<script>window.location.href='login.php';</script>";
}

$view_perm=$add_perm=$edit_perm=$del_perm=true;  

if (isset($_SESSION['success']) && ($_SESSION['success'] != "")) {
  $stat['success'] = $_SESSION['success'];
  unset($_SESSION['success']);
}
if (isset($_SESSION['error']) && ($_SESSION['error'] != "")) {
  $stat['danger'] = $_SESSION['error'];
  unset($_SESSION['error']);
}

if (!empty($_POST['data_ord'])) {
  foreach ($_POST['data_ord'] as $key => $ord) {
    $save=array();
    $save['sort_order'] = $ord;
    $res=$db->updateAry("featured_product", $save, "where featured_product_id=".$key);  
  }

  unset($_POST);
  if(isset($res)){
    unset($_POST);
    $_SESSION['success'] = "Records sorted successfully.";    
  }
  else{
    $_SESSION['error'] = "Records not sorted successfully.";    
  }  

  redirect('featured-product.php');
}
if (!empty($_POST['featured_product_id'])) {
  $save=array();
  $save['product_id']= $_POST['product_id']; 
  $save['featured_title_id']= $_POST['featured_title_id']; 
  $save['modified_by']= $_SESSION["Users_Id"];
  $save['modified_date']= date('Y-m-d H:i:s');

  $res = $db->updateAry("featured_product", $save, "where featured_product_id=".$_POST['featured_product_id']);

  unset($_POST);
  if(isset($res)){
    unset($_POST);
    $_SESSION['success'] = "Featured Product updated successfully.";    
  }
  else{
    $_SESSION['error'] ="Featured Product update failed.";
  }  

  redirect('featured-product.php');
}
elseif (!empty($_POST['product_id'])) 
{
  $save=array();
  $save['product_id']= $_POST['product_id']; 
  $save['featured_title_id']= $_POST['featured_title_id']; 
  $save['created_by']= $_SESSION["Users_Id"];
  $save['created_date']= date('Y-m-d H:i:s');  
  // echo "<pre>";print_r($save);die;
  $id = $db->insertAry('featured_product',$save);
  if(!is_null($id)){
   $save1=array();
   $save1['sort_order']=$id;
   $res = $db->updateAry("featured_product", $save1, "where featured_product_id=".$id);  

   $_SESSION['success'] = "Featured Product Added successfully.";
 }
 else
  $_SESSION['error'] ="Featured Product update failed.";
// echo $db->getLastQuery(); exit;
unset($_POST);
redirect('featured-product.php');          
}
?>
<?php include 'includes/header.php'; ?>
<link href="dist/css/img_upl.css" rel="stylesheet">
<div class="row">                   
  <div class="col-lg-12 col-sm-12" style="padding: 0;"> 
    <div class="row panel panel-default" id="firstRow">      
      <div class="add-newproduct-tab">
        <div class="gradient-card-header">
          <h2 class="white-text mx-3">Featured Product</h2>
        </div>
      </div>
      <?php echo !empty($stat)?msg($stat):'';?>
      <div class="courseAddPrmssn">               
        <button type="button" id="btn_add" class="btn btn-info button-addnew pull-right" ><i class="fa fa-angle-down" aria-hidden="true"></i>Add Featured Product &nbsp;&nbsp; 
        </button>
        <br/><br/>
      </div>
      <form method="post" class="frm-save" name="doc-register" enctype="multipart/form-data">
        <div id="content" class="panel panel-default">
          <div class="panel-body">
            <div class="row">
              <div class="col-md-4">
               <span class="badge-label">Main Category<span class="redstar">*</span></span>
               <select class="select form-control main_category_id" onchange="get_categories(this,this.value);">
                <option value="0">Select Main Category</option>
                <?php  $res = $db->getRows("SELECT main_category_id,name FROM main_category order by name");
                if( count($res) > 0){
                  foreach($res as $res1){ ?>
                    <option value="<?= $res1["main_category_id"] ?>"><?= $res1["name"] ?></option>
                  <?php } 
                }?>     
              </select>
            </div>
            <div class="col-md-4">
              <span class="badge-label">Category<span class="redstar">*</span></span>
              <select class="select form-control category_id" onchange="get_sub_categories(this,this.value);">
                <option value="0">Select Category</option>                    
              </select>
            </div>  
            <div class="col-md-4">
              <span class="badge-label">Sub Category<span class="redstar">*</span></span>
              <select class="select form-control sub_category_id">
                <option value="0">Select Sub Category</option>                    
              </select>
            </div>            
          </div>
          <div class="row">           
            <div class="col-md-3 top10">
             <span class="badge-label">Brand<span class="redstar">*</span></span>
             <select class="select form-control brand_id" onchange="get_prods(this);">
              <option value="0">Select Brand</option>
              <?php  $res = $db->getRows("SELECT brand_id,name FROM brand order by name");
              if( count($res) > 0){
                foreach($res as $res1){ ?>
                  <option value="<?= $res1["brand_id"] ?>"><?= $res1["name"] ?></option>
                <?php } 
              }?>     
            </select>
          </div>
          <div class="col-md-5 top10">
           <span class="badge-label">Product<span class="redstar">*</span></span>
           <select class="select form-control product_id" name="product_id">
            <option value="0">Select Product</option>            
          </select>
        </div>
        <div class="col-md-4 top10">
          <span class="badge-label">Featured Title<span class="redstar">*</span></span>
          <select name="featured_title_id" class="select form-control featured_title_id">
            <option value="0">Select Featured Title</option>  
            <?php  $res = $db->getRows("SELECT featured_title_id,name FROM featured_title order by name");
            if( count($res) > 0){
              foreach($res as $res1){ ?>
                <option value="<?= $res1["featured_title_id"] ?>"><?= $res1["name"] ?></option>
              <?php } 
            }?>                      
          </select>
        </div>     
        <div class="col-md-12 top10">
          <div class="pull-right top30">
            <button class="btn blue-gradient button-save btn-save" title="Save" type="button" name="saveGroup"><i class="fa fa-check" aria-hidden="true"></i> Add</button>
            <button type="reset" title="Cancel" class="btn danger-gradient button-cancel"><i class="fa fa-times" aria-hidden="true"></i> Clear</button>
          </div>
          <label class="err_lbl" style="position: absolute;top: 0px !important;right: 20px;"></label>&nbsp;&nbsp;
        </div>
      </div>
    </div>
  </div>
</form>
<div class="row">
  <div class="">
    <div class="panel-default">
      <div class="panel-body">
        <div style1="overflow-y: auto;">
          <form method="post" class="frm-sort">
            <table style="width: 100%" class="table table-striped table-hover table-bordered" id="data_table">
              <thead>
                <tr>
                  <th>Sno</th>
                  <th>Product Name</th>
                  <th>Featured Title</th>                  
                  <th class="text-center">Action</th>
                </tr>
              </thead>
              <tbody id="row-cont">
                <?php
                $res = $db->getRows("SELECT featured_product_id,product.name as prod_name,featured_title.name as featured_name,featured_product.sort_order FROM featured_product left join featured_title on featured_title.featured_title_id=featured_product.featured_title_id left join product on product.product_id=featured_product.product_id order by featured_product.sort_order");
                     // echo $db->getLastQuery(); exit;
                if( count($res) > 0){
                  foreach($res as $key => $res1){ 
                    $id = $res1["featured_product_id"];                    
                    ?>
                    <tr class="odd gradeX">
                      <td><?= $res1["sort_order"]; ?> </td>
                      <td style="cursor: move;"><?= $res1['prod_name']; ?></td>
                      <td><?= $res1['featured_name']; ?></td>
                      <td class="text-center">                                
                        <button class="btn_edit btn btn-primary btn-circle courseEditPrmssn" data-toggle="modal" data-target="#mod_data" name="edit" value="<?php echo $id ?>"  data-id="<?php echo $id ?>" ><i class="fa fa-pencil-alt" title="Edit"></i></button>
                        <button type="button" id="delete" onclick="del_confirm(this)" name="delete" value="<?php  echo $id ?>" class="btn btn-danger btn-circle courseDeletePrmssn" title="Delete"><i class="fa fa-times"></i>
                        </button>
                        <input type="hidden" class="data_ord" name="data_ord[<?= $id; ?>]" value="<?= $key+1; ?>">   
                      </td>                          
                    </tr>
                  <?php  }
                } ?>                    
              </tbody>                  
            </table>
            <?php if( count($res) > 0){?>
             <div class="col-md-12">
              <button type="button" id="btn_save_order" name="save_order" class="btn btn-info button-addnew pull-left">Save Order</button>
            </div>
          <?php } ?>
        </form>
      </div>
    </div> <!-- panel-body-->
  </div> <!-- panel-default-->
</div> <!-- empty class-->
</div> <!-- row-->
</div>          
</div>
</div>
<div class="modal fade" id="mod_data" role="dialog">
  <div class="modal-dialog cascading-modal" role="document" style="min-width: 700px;">
    <!--Content-->
    <div class="modal-content">
      <!--Header-->
      <div class="modal-header light-blue darken-3 white-text">
        <button type="button" class="close waves-effect waves-light" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
        <h4 class="title"><i class="fa fa-pencil-alt"></i> EDIT</h4>
      </div>
      <!--Body-->
      <div class="modal-body mb-0">
        <form method="post" class="frm-upd" enctype="multipart/form-data">
          <div id="upd"></div>
          <br/>
          <div class="text-center">
            <label class="err_lbl"></label><br>
            <button type="button" name="update" id="btn_upd" data-id="0" class=" btn btn-success button-update btn-save"><i class="fa fa-check" aria-hidden="true"></i>Update
            </button>
            <button type="button" data-dismiss="modal" class="btn btn-warning button-cancel"><i class="fa fa-times"></i>Cancel</button>
          </div>
          <br/>
        </form>
      </div>
    </div>
    <!--/.Content-->
  </div>
</div>
<?php include 'includes/footer.php'; ?>
<script>
  function readURL(input) {
    $tis=$(input);
    if (input.files && input.files[0]) {
      var extension = input.files[0].name.split('.').pop().toLowerCase();
      var reader = new FileReader();
      reader.onload = function(e) {
        $tis.parent().parent().find('.imagePreview').css('background-image', 'url('+e.target.result +')');
        $tis.parent().parent().find('.imagePreview').hide();
        $tis.parent().parent().find('.imagePreview').fadeIn(650);
      }
      reader.readAsDataURL(input.files[0]);
    }
  }
  $(".img").change(function() {
    readURL(this);
  });  
  $("#content").toggle();
  $(document).ready(function() {
    $('.select').select2();
    $("#btn_add").click(function(){
      $("#content").toggle();
      $(this).find(".fa-angle-down").toggleClass('fa-angle-up');
    });
    $('#data_table').DataTable({
      "scrollX": true,
      "columnDefs": [
      { "orderable": false, "targets": [3]},
      { "orderable": true, "targets": [0, 1, 2]},
      {"visible": false, "targets": [0]}
      ],
      "order": [[ 0, "asc" ]],
      "rowReorder" : [ "dataSrc", [1]]
    });    
  });
  $( ".btn_edit" ).click(function( event ) {
    event.preventDefault();
    
    var id =$(this).attr('data-id');
    $.ajax({
      url: 'aj_data.php',
      type: 'POST',
      data: 'action=featured_product_edit&id='+id,
      dataType: 'html'
    })
    .done(function(data){      
      $('#upd').empty().append(data);
      $('#btn_upd').attr('data-id',id);
    })
    $('#mod_data').find('.err_lbl').html('');
    $('#mod_data').modal('show');
    return false;
  });
  $( "#btn_save_order" ).click(function( event ) {
    var table = $('#data_table').DataTable();
    var info = table.page.info();
    cur_page = info.page;

    $sno=(cur_page*10)+1;
    $("#row-cont tr").each(function( index ) {
      $(this).find('.data_ord').val($sno++);      
    });

    $('.frm-sort').submit();
  });  
  function del_confirm(e) {
    var id = e.value;
    $.confirm({
      icon: 'fa fa-warning',
      title: 'Confirm!',
      content: 'Do you want to Delete ?',
      type: 'red',
      buttons: {
        confirm:  {
          btnClass: 'btn-red',
          action: function(){
            $.confirm({
              icon: 'fa fa-warning',
              title: 'Confirm!',
              content: 'If you Delete, You cant restore this record !',
              type: 'red',
              buttons: {
                Okay: {
                  btnClass: 'btn-red',
                  action: function(){
                    $.ajax({
                      type: 'post',
                      url: 'aj_data.php',
                      data: 'action=del_setting&type=featured_product&id='+id,
                      dataType: "json",
                      success: function (data) {
                        if(data['validation'] == '1'){
                         window.location.reload();
                       }
                       else{
                        $.alert(data['message']);
                      }
                    }
                  });
                  }
                },
                Cancel: function () { },
              }
            });
          }
        },
        cancel: function () { },
      }
    });
  }  

  $(document).on('click','.btn-save',function(e){    
    $err_lbl= $(this).parent().parent().find('.err_lbl');
    $err_lbl.html('');

    if($(this).attr('data-id')){
      $id=$(this).attr('data-id');
      $frm = $('.frm-upd');
    }
    else{
      $id =0;
      $frm = $('.frm-save');        
    }

    $val = '';
    
    $main_category_id=$frm.find('.main_category_id').val();

    if($main_category_id ==0){
      $err_lbl.html('Please select Main category!');
      return false;
    }

    $category_id=$frm.find('.category_id').val();

    if($category_id ==0){
      $err_lbl.html('Please select Category!');
      return false;
    }
    $sub_category_id=$frm.find('.sub_category_id').val();

    if($sub_category_id ==0){
      $err_lbl.html('Please select Sub category!');
      return false;
    }

    $brand_id=$frm.find('.brand_id').val();

    if($brand_id ==0){
      $err_lbl.html('Please select Brand!');
      return false;
    }

    $product_id=$frm.find('.product_id').val();

    if($product_id ==0){
      $err_lbl.html('Please select Product!');
      return false;
    }

    $featured_title_id=$frm.find('.featured_title_id').val();

    if($featured_title_id ==0){
      $err_lbl.html('Please select Featured Title!');
      return false;
    }

    $.ajax({
      url : "aj_data.php",
      data: 'action=chk_dup&type=featured_product&chk_fld=product_id&chk_val='+$product_id+'&chk_fld1=featured_title_id&chk_val1='+$featured_title_id+'&chk_id='+$id,
      success: function(res){
        res =$.trim(res);
        if(res=='E')
          $err_lbl.html('Product already exists in this Title!');
        else
          $frm.submit();
      }
    }); 
  }); 
  function get_categories(ele,id)
  {
    $tis=$(ele);
    $tis.parent().parent().find(".category_id").html(''); 
    $tis.parent().parent().find(".sub_category_id").html('<option value="0">Select Sub Category</option>'); 
    $tis.parent().parent().parent().find(".product_id").html('<option value="0">Select Product</option>'); 
    $.ajax({
      type: "POST",
      url : "aj_data.php",
      data: 'action=get_categories&main_category_id='+id,
      success: function(msg){
       $tis.parent().parent().find(".category_id").html(msg); 
     }
   });
  }
  function get_sub_categories(ele,id)
  {
    $tis=$(ele);
    $tis.parent().parent().find(".sub_category_id").html(''); 
    $tis.parent().parent().parent().find(".product_id").html('<option value="0">Select Product</option>'); 
    $.ajax({
      type: "POST",
      url : "aj_data.php",
      data: 'action=get_sub_categories&category_id='+id,
      success: function(msg){
       $tis.parent().parent().find(".sub_category_id").html(msg); 
     }
   });
  }
  function get_prods(ele)
  {
    $tis=$(ele);
    $tis.parent().parent().parent().find(".product_id").html(''); 

    sub_category_id=$tis.parent().parent().parent().find(".sub_category_id").val(); 
    brand_id=$tis.parent().parent().find(".brand_id").val(); 

    if(sub_category_id!=0 && brand_id!=0){
      $.ajax({
        type: "POST",
        url : "aj_data.php",
        data: 'action=get_prods&sub_category_id='+sub_category_id+'&brand_id='+brand_id,
        success: function(msg){
         $tis.parent().parent().parent().find(".product_id").html(msg); 
       }
     })
    }    
  }  

</script>
