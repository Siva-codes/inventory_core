<?php include("../config.php");
session_destroy();
session_start();
// $_SESSION = array();

// if (ini_get("session.use_cookies")) {
//     $params = session_get_cookie_params();
//     setcookie(session_name(), '', time() - 42000,
//         $params["path"], $params["domain"],
//         $params["secure"], $params["httponly"]
//     );
// }

if(isset($_POST['submit']))
{
    $res = $db->getRow("select admin_id,type,name from admin where (name='".$_POST['mobile']."' or mobile='".$_POST['mobile']."' or email='".$_POST['mobile']."') and password= '".$_POST['psw']."' and status='A'");
    if(isset($res['admin_id'])){ 
      $_SESSION["Users_Id"]=$res['admin_id'];
      $_SESSION["Users_Name"]=$res['name'];
      // $_SESSION["Users_Type"]=$res['type'];
      $_SESSION["Users_Type"]='A';

      redirect('index.php');
  }
  else
  {
    $res = $db->getRow("select seller_id,name from seller where (email='".$_POST['mobile']."' or mobile='".$_POST['mobile']."') and password= '".md5($_POST['psw'])."' and status='A'");
    if(isset($res['seller_id'])){ 
      $_SESSION["Users_Id"]=$res['seller_id'];
      $_SESSION["Users_Name"]=$res['name'];
      $_SESSION["Users_Type"]="S";

      redirect('index.php');
  }
  else 
    echo "<script>alert('Please Enter Valid Username and Password')</script>";
}
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin | Sample Inventory</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.16/css/mdb.min.css" rel="stylesheet">

    <!-- JQuery -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.16/js/mdb.min.js"></script>

    <link href="MDB/css/compiled.min.css" rel="stylesheet" />
    <style type="text/css">
        .navbar.navbar-dark .navbar-nav .nav-item .nav-link {
            color: #000;
            -webkit-transition: .35s;
            -o-transition: .35s;
            transition: .35s;
        }    
        .navbar.navbar-dark .navbar-nav .nav-item .nav-link:hover {
            color: #000;
            font-weight: 500;
        }  
    </style>
</head>
<body style="background-color: #e9e9e9">
    <nav class="navbar fixed-top navbar-toggleable-md navbar-dark white scrolling-navbar double-nav">

           <!--  <ul class="nav navbar-nav nav-flex-icons ml-auto">
                <li class="nav-item">
                    <a href="doctor_login.php" class="nav-link waves-effect waves-light"><i class="fa fa-lock"></i> <span class="hidden-sm-down">Doctor Login</span></a>
                </li>
            </ul> -->

        </nav>
        <div class="main-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <!--Main column-->
                    <div class="col-lg-10 col-md-12">

                        <!--Documentation file-->
                        <div class="documentation">
                         <form id="form1" method="post" runat="server">
                            <!-- SECTION-->
                            <section id="form-h">

                                <br>
                                <br>                   
                                <br>
                                <br>                   
                                <br>
                                <br>

                                <!-- Live preview-->
                                <div class="row">

                                    <div class="col-md-5 col-sm-2 col-xs-12"></div>
                                    <div class="col-lg-5 col-md-7">

                                        <!--Form with header-->
                                        <div class="card">
                                            <div class="card-block">

                                                <!--Header-->
                                                <div class="form-header  purple darken-4">
                                                    <h3>Login</h3>
                                                </div>

                                                <!--Body-->
                                                <div class="md-form">
                                                    <i class="fa fa-user prefix"></i>
                                                    <input type="text" id="mobile" name="mobile"  class="form-control">
                                                    <label for="mobile">User Name</label>
                                                </div>
                                                <div class="md-form">
                                                    <i class="fa fa-lock prefix"></i>
                                                    <input type="password" id="psw"  name="psw" class="form-control">
                                                    <label for="psw">Password</label>
                                                </div>
                                                <div class="text-center">
                                                    <button type="submit"  name="submit" class="btn btn-deep-purple waves-effect waves-light">Login</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>   
</body>
<script type="text/javascript" src="MDB/js/compiled.min.js"></script>
<script>
        // SideNav init
        $(".button-collapse").sideNav();

        // Custom scrollbar init
        var el = document.querySelector('.custom-scrollbar');
        Ps.initialize(el);
        
        //Sticky
        $(function () {
            $(".sticky").sticky({
                topSpacing: 90
                , zIndex: 2
                , stopper: "#footer"
            });
        });
        
        //ScrollSpy
        $('body').scrollspy({
            target: '#scrollspy'
        })

    </script>
    </html>