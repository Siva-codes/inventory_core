<?php include("../config.php");

if(empty($_SESSION["Users_Id"]))  {
  echo "<script>window.location.href='login.php';</script>";
}

$view_perm=$add_perm=$edit_perm=$del_perm=true;  

if (isset($_SESSION['success']) && ($_SESSION['success'] != "")) {
  $stat['success'] = $_SESSION['success'];
  unset($_SESSION['success']);
}
if (isset($_SESSION['error']) && ($_SESSION['error'] != "")) {
  $stat['danger'] = $_SESSION['error'];
  unset($_SESSION['error']);
}

if (!empty($_POST['tax_id'])) {
  $save= $_POST;
  $save['status']=$save['status']!='A'?'I':'A';
  $save['modified_by']= $_SESSION["Users_Id"];
  $save['modified_date']= date('Y-m-d H:i:s'); 

  $res = $db->updateAry("tax", $save, "where tax_id=".$_POST['tax_id']);

  unset($_POST);
  if(isset($res)){
    unset($_POST);
    $_SESSION['success'] = "Tax updated successfully.";    
  }
  else{
    $_SESSION['error'] ="Tax update failed.";
  }  

  redirect('tax.php');
}
elseif (!empty($_POST['name'])) 
{
 $save= $_POST;
 $save['status']=$save['status']!='A'?'I':'A'; 
 $save['created_by']= $_SESSION["Users_Id"];
 $save['created_date']= date('Y-m-d H:i:s');      

 $id = $db->insertAry('tax',$save);
  // echo $db->getLastQuery(); exit;
 if(!is_null($id))
  $_SESSION['success'] = "Tax Added successfully.";
else
  $_SESSION['error'] ="Tax update failed.";
// echo $db->getLastQuery(); exit;
unset($_POST);
redirect('tax.php');          
}
?>
<?php include 'includes/header.php'; ?>
<link href="dist/css/img_upl.css" rel="stylesheet">
<div class="row">                   
  <div class="col-lg-12 col-sm-12" style="padding: 0;"> 
    <div class="row panel panel-default" id="firstRow">      
      <div class="add-newproduct-tab">
        <div class="gradient-card-header">
          <h2 class="white-text mx-3">Tax</h2>
        </div>
      </div>
      <?php echo !empty($stat)?msg($stat):'';?>
      <div class="courseAddPrmssn">               
        <button type="button" id="btn_add" class="btn btn-info button-addnew pull-right" ><i class="fa fa-angle-down" aria-hidden="true"></i>Add Tax &nbsp;&nbsp; 
        </button>
        <br/><br/>
      </div>
      <form method="post" class="frm-save" name="doc-register" enctype="multipart/form-data">
        <div id="content" class="panel panel-default">
          <div class="panel-body">
            <div class="row">
              <div class="col-md-3">
                <span class="badge-label">Tax Code<span class="redstar">*</span></span>
                <input class="form-control name" name="name">
              </div>
              <div class="col-md-2">
                <span class="badge-label">Tax %<span class="redstar">*</span></span>
                <input class="form-control tax_percent" maxlength="5" onkeypress="return isFracNumber(event)" name="tax_percent">
              </div>
              <div class="col-md-3">
                <span class="badge-label p-2">Status</span>
                <div class="switch top10">
                  <label>Inactive
                    <input type="checkbox" checked="true" name="status" value="A" >
                    <span class="lever"></span> Active
                  </label>
                </div>
              </div>
              <div class="col-md-4">
                <div class="pull-right top30">
                  <label style="position: absolute;top: -3px;padding-left:10px;" class="err_lbl"></label>&nbsp;&nbsp;
                  <button class="btn blue-gradient button-save btn-save" title="Save" type="button" name="saveGroup"><i class="fa fa-check" aria-hidden="true"></i> Add</button>
                  <button type="reset" title="Cancel" class="btn danger-gradient button-cancel"><i class="fa fa-times" aria-hidden="true"></i> Clear</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
      <div class="row">
        <div class="">
          <div class="panel-default">
            <div class="panel-body">
              <div style1="overflow-y: auto;">
                <form method="post" class="frm-sort">
                  <table style="width: 100%" class="table table-striped table-hover table-bordered" id="data_table">
                    <thead>
                      <tr>
                        <th>Tax Code</th>
                        <th>Tax%</th>
                        <th>Status</th>              
                        <th class="text-center">Action</th>
                      </tr>
                    </thead>
                    <tbody id="row-cont">
                      <?php
                    //get images from database
                      $res = $db->getRows("SELECT * FROM tax order by tax_id desc");
                    // echo $db->getLastQuery(); exit;
                      if( count($res) > 0){
                        foreach($res as $key => $res1){ 
                          $id = $res1["tax_id"];
                          ?>
                          <tr class="odd gradeX">
                            <td><?= $res1['name']; ?></td>
                            <td><?= $res1['tax_percent']; ?></td>
                            <td class="<?= $res1['status']=='A'?'act-cls':'inact-cls'; ?>"><?= $res1['status']=='A'?'Active':'Inactive'; ?></td>
                            <td class="text-center">
                              <a href="tax-value.php?id=<?= $id; ?>" title="Tax Values" class="btn btn-warning btn-circle courseEditPrmssn"><i class="fa fa-angle-double-right" aria-hidden="true"></i></a>                             
                              <button class="btn_edit btn btn-primary btn-circle courseEditPrmssn" data-toggle="modal" data-target="#mod_data" name="edit" value="<?php echo $id ?>"  data-id="<?php echo $id ?>" ><i class="fa fa-pencil-alt" title="Edit"></i></button>
                              <button type="button" id="delete" onclick="del_confirm(this)" name="delete" value="<?php  echo $id ?>" class="btn btn-danger btn-circle courseDeletePrmssn" title="Delete"><i class="fa fa-times"></i>
                              </button>
                              <input type="hidden" class="data_ord" name="data_ord[<?= $id; ?>]" value="<?= $key+1; ?>">                            
                            </td>                          
                          </tr>
                        <?php  }
                      } ?>                    
                    </tbody>                  
                  </table>
                  <?php if( count($res) > 0){?>
                   <div class="col-md-12">
                    <button type="button" id="btn_save_order" name="save_order" class="btn btn-info button-addnew pull-left">Save Order</button>
                  </div>
                <?php } ?>
              </form>
            </div>
          </div> <!-- panel-body-->
        </div> <!-- panel-default-->
      </div> <!-- empty class-->
    </div> <!-- row-->
  </div>          
</div>
</div>
<div class="modal fade" id="mod_data" role="dialog">
  <div class="modal-dialog cascading-modal" role="document">
    <!--Content-->
    <div class="modal-content">
      <!--Header-->
      <div class="modal-header light-blue darken-3 white-text">
        <button type="button" class="close waves-effect waves-light" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
        <h4 class="title"><i class="fa fa-pencil-alt"></i> EDIT</h4>
      </div>
      <!--Body-->
      <div class="modal-body mb-0">
        <form method="post" class="frm-upd" enctype="multipart/form-data">
          <div id="upd"></div>
          <br/>
          <div class="text-center">
            <label class="err_lbl"></label><br>
            <button type="button" name="update" id="btn_upd" data-id="0" class=" btn btn-success button-update btn-save"><i class="fa fa-check" aria-hidden="true"></i>Update
            </button>
            <button type="button" data-dismiss="modal" class="btn btn-warning button-cancel"><i class="fa fa-times"></i>Cancel</button>
          </div>
          <br/>
        </form>
      </div>
    </div>
    <!--/.Content-->
  </div>
</div>
<?php include 'includes/footer.php'; ?>
<script>  
  $(document).ready(function(){
    $("#btn_add").click(function(){
      $("#content").toggle();
      $(this).find(".fa-angle-down").toggleClass('fa-angle-up');
    });
  });
  $("#content").toggle();
  $(document).ready(function() {
    $('#data_table').DataTable({
      "scrollX": true,
      "columnDefs": [
      { "orderable": false, "targets": [3]},
      { "orderable": true, "targets": [0, 1,2]}
      ],
      "aaSorting": []
    });    
  });
  $( ".btn_edit" ).click(function( event ) {
    event.preventDefault();
    
    var id =$(this).attr('data-id');
    $.ajax({
      url: 'aj_data.php',
      type: 'POST',
      data: 'action=tax_edit&id='+id,
      dataType: 'html'
    })
    .done(function(data){      
      $('#upd').empty().append(data);
      $('#btn_upd').attr('data-id',id);
    })
    $('#mod_data').find('.err_lbl').html('');
    $('#mod_data').modal('show');
    return false;
  });  
  function del_confirm(e) {
    var id = e.value;
    $.confirm({
      icon: 'fa fa-warning',
      title: 'Confirm!',
      content: 'Do you want to Delete ?',
      type: 'red',
      buttons: {
        confirm:  {
          btnClass: 'btn-red',
          action: function(){
            $.confirm({
              icon: 'fa fa-warning',
              title: 'Confirm!',
              content: 'If you Delete, You cant restore this record !',
              type: 'red',
              buttons: {
                Okay: {
                  btnClass: 'btn-red',
                  action: function(){
                    $.ajax({
                      type: 'post',
                      url: 'aj_data.php',
                      data: 'action=del_setting&type=tax&id='+id,
                      dataType: "json",
                      success: function (data) {
                        if(data['validation'] == '1'){
                         window.location.reload();
                       }
                       else{
                        $.alert(data['message']);
                      }
                    }
                  });
                  }
                },
                Cancel: function () { },
              }
            });
          }
        },
        cancel: function () { },
      }
    });
  }  

  $(document).on('click','.btn-save',function(e){    
    $err_lbl= $(this).parent().find('.err_lbl');
    $err_lbl.html('');

    if($(this).attr('data-id')){
      $id=$(this).attr('data-id');
      $frm = $('.frm-upd');
    }
    else{
      $id =0;
      $frm = $('.frm-save');        
    }

    $val = '';
    $frm.find('input:text').each(function(){
      $(this).val($.trim($(this).val()));
    });

    $code=$frm.find('.name').val();

    if($code ==''){
      $err_lbl.html('Please enter Tax code!');
      return false;
    } 

    $val=$frm.find('.tax_percent').val();
    if($val ==''){
      $err_lbl.html('Please enter Tax percent!');
      return false;
    } 

    if(parseFloat($val)>=100){
      $err_lbl.html('Invalid Tax percent!');
      return false;
    }    

    $.ajax({
      url : "aj_data.php",
      data: 'action=chk_dup&type=tax&chk_fld=name&chk_val='+$code+'&chk_id='+$id,
      success: function(res){
        res =$.trim(res);
        if(res=='E')
          $err_lbl.html('Tax code already exists!');
        else
          $frm.submit();
      }
    }); 
  }); 

</script>
