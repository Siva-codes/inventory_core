<?php
/**
 * Created by PhpStorm.
 * User: Ehtesham Mehmood
 * Date: 11/21/2014
 * Time: 1:13 AM
 */

/* Server Connection */
// $dbcon=mysqli_connect("localhost","muvierec_admin","muviereckadmin@123");
// mysqli_select_db($dbcon,"muvierec_oman");

/* Local Connection */
$dbcon=mysqli_connect("localhost","root","");
mysqli_select_db($dbcon,"inventory_core");

?>