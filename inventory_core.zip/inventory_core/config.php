<?php session_start();

date_default_timezone_set("Asia/Calcutta");
$varAdminFolder = "manage";
$_SESSION['lang'] = 'french';

define("DS", DIRECTORY_SEPARATOR);

define("PATH_ROOT", dirname(__FILE__));

define("PATH_LIB", PATH_ROOT . DS . "library" . DS);

define("PATH_ADMIN", PATH_ROOT . DS . $varAdminFolder . DS);

define("PATH_ADMIN_MODULE", PATH_ADMIN . "modules" . DS);

define("PATH_CLASS", PATH_ROOT . DS . "classes" . DS);

define("PATH_IMAGES", PATH_ROOT . DS . 'images' . DS);

define("PATH_UPLOAD", PATH_ROOT . DS . "uploads" . DS);

define("PATH_UPLOAD_USER", PATH_UPLOAD . "user" . DS);

define("PATH_UPLOAD_ADMIN", PATH_UPLOAD . "admin" . DS);

define("PATH_UPLOAD_TEAM", PATH_UPLOAD . "team" . DS);

define("PATH_UPLOAD_TEAM_IMAGE", PATH_UPLOAD . "teamimage" . DS);

define("PATH_UPLOAD_BANNER", PATH_UPLOAD . "banner" . DS);

define("PATH_UPLOAD_LEAGUE", PATH_UPLOAD . "league" . DS);

define("PATH_UPLOAD_SECTION", PATH_UPLOAD . "section" . DS);

define("URL_ROOT", "http://localhost/inventory_core");
$base_url = constant('URL_ROOT');

//define("URL_ROOT_ADMIN", "http://localhost/classic/admin");

define("URL_CSS", URL_ROOT . "css/");

define("URL_JS", URL_ROOT . "js/");

define("URL_IMG", URL_ROOT . "images/");

define("URL_ADMIN", URL_ROOT . $varAdminFolder . "/");

define("URL_ADMIN_HOME", URL_ADMIN . "user-login.php");

define("URL_ADMIN_CSS", URL_ADMIN . "css/");

define("URL_ADMIN_JS", URL_ADMIN . "js/");

define("URL_ADMIN_IMG", URL_ADMIN . "img/");

define("SELF", basename($_SERVER['PHP_SELF']));

define("DATE_FORMAT", "d/m/Y H:i:s");


define("ADMIN_TITLE", "Muviereck1 Technology");
define("COPY_RIGHT", "Copyright  2018 . Powered By Muviereck Technology | All rights reserved .");

//define RegX expressions
define("REGX_MAIL", "/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/");
define("REGX_URL", "/^(http(s)?\:\/\/(?:www\.)?[a-zA-Z0-9]+(?:(?:\-|_)[a-zA-Z0-9]+)*(?:\.[a-zA-Z0-9]+(?:(?:\-|_)[a-zA-Z0-9]+)*)*\.[a-zA-Z]{2,4}(?:\/)?)$/i");
define("REGX_PHONE", "/^[0-9\+][0-9\-\(\)\s]+[0-9]$/");
define("REGX_PRICE", "/^[0-9\.]+$/");

require_once(PATH_LIB."validations.php");
require_once(PATH_LIB."class.database.php");

/* Local Connection */
 
$db=new MySqlDb("localhost","root","","inventory_core");

/* Server Connection */

// $host="localhost";
// $user="muviereckadmin";
// $pass="muviereckadmin@123";
// $dbs="healthya_yetlo";
// $db=new MySqlDb("localhost","muvierec_admin","muviereckadmin@123","muvierec_oman");

require_once(PATH_LIB."functions.php");

$pagename=basename($_SERVER['PHP_SELF']);

	//Display Product Name with limited character
	//10-jan-2019
	function custom_echo($x, $length)
	{
	    if(strlen($x)<=$length)
	    {
	      return $x;
	    }
	    else
	    {
	      $y=substr($x,0,$length) . '...';
	      return $y;
	    }
	}

	//fucntion : time_elapsed_string()
	//Desc : Get Last time ago calculation.
    function time_elapsed_string($datetime, $full = false) {
        $now = new DateTime;
        $ago = new DateTime($datetime);
        $diff = $now->diff($ago);

        $diff->w = floor($diff->d / 7);
        $diff->d -= $diff->w * 7;

        $string = array(
            'y' => 'year',
            'm' => 'month',
            'w' => 'week',
            'd' => 'day',
            'h' => 'hour',
            'i' => 'minute',
            's' => 'second',
        );
        foreach ($string as $k => &$v) {
            if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
            } else {
                unset($string[$k]);
            }
        }

        if (!$full) $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' ago' : 'just now';
    }


    // SMS generic codes
    $SMSapiKey = urlencode('8wuyy2y3tWw-y897JJQ5n8MwB6joh0pyTHbXXxL8CY');
    $senderID = urlencode('PETBTY');

    //Payment Response URL
    $consultPayReturnUrl = "http://localhost:81/oman/consult_pay_response.php"; 
    $productPayReturnUrl = "http://localhost:81/oman/product_pay_response.php"; 
?>
