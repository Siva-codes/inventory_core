<?php
 $name = base64_decode("S295YW1iZWR1QWRtaW4=");
 $pass= base64_decode("S295YW1iZWR1QWRtaW5ATXV2aWVyZWNr");

 $req_user = $_SERVER['PHP_AUTH_USER'];
 $req_pass = $_SERVER['PHP_AUTH_PW'];

 if (!($name ==$req_user && $pass ==$req_pass)) {
   header('WWW-Authenticate: Basic realm="My Realm"');
   header('HTTP/1.0 401 Unauthorized');
   die ("Not authorized");
 }
header('Content-type: application/json');
?>