	<?php
	error_reporting( E_ALL );
	ini_set( "display_errors", 1 );
	require '../config.php';	
	include 'header.php';

	$action = $_POST['action'];

	if ($action=='get_pay_key')
		include 'token_verify.php';	 

	$resp=array();
	$resp['status'] = $_POST['action']; 
	$resp['code'] = 200;  
	$resp['message'] = 'Success!';
	switch ($action) {
		case 'get_banner':
		{
			$res = $db->getRows("SELECT img FROM banner order by banner_id");

			if(!empty($res)){
				foreach ($res as $key => $res1) {				
					if(!empty($res1)){
						$img =!empty($res1['img'])?'uploads/banner/'.$res1['img']:'images/default_img.png';
						$res[$key]['img']= $base_url.'/'.$img;
						foreach ($res1 as $key1 => $val) {	
							if (is_int($key1)) {
								unset($res[$key][$key1]);
							}			
						}
					}
				}		
			}
			$resp['res'] =$res;
			$resp['status'] = 'success'; 
			$resp['code'] = 200;  
			$resp['message'] = 'Success!';			
			break;
		}
		case 'get_seller':
		{
			$res = $db->getRows("SELECT seller_id,type,img,name FROM seller where type like '%".strtoupper($_POST['type'])."%' order by sort_order");

			if(!empty($res)){
				foreach ($res as $key => $res1) {				
					if(!empty($res1)){
						$img =!empty($res1['img'])?'uploads/seller/'.$res1['img']:'img/default_img.png';
						$res[$key]['img']= $base_url.'/'.$img;
						foreach ($res1 as $key1 => $val) {	
							if (is_int($key1)) {
								unset($res[$key][$key1]);
							}			
						}
					}
				}		
			}

			$resp['res'] =$res;
			$resp['status'] = 'success'; 
			$resp['code'] = 200;  
			$resp['message'] = 'Success!';
			
			break;
		}
		case 'get_seller_product':
		{
			$res = $db->getRow("SELECT name,img FROM seller where seller_id=".$_POST['seller_id']);
			if(empty($res)){ 
				$resp['status'] = 'error'; 
				$resp['code'] = 203;  
				$resp['message'] = 'Invalid Seller ID!';
				break;  
			}      

			$seller_name=$res['name'];
			$seller_img =!empty($res['img'])?'uploads/seller/'.$res['img']:'img/default_img.png';
			$seller_img= $base_url.'/'.$seller_img;

			$prods = $db->getRows("SELECT product_id,product.name,description,tax.name as tax_name,tax_percent from product left join tax on product.tax_id=tax.tax_id where product.created_by =".$_POST['seller_id']." order by sort_order");
			//echo $db->getLastQuery(); die;
			if(!empty($prods)){
				foreach ($prods as $key => $prod) {				
					if(!empty($prod)){
						foreach ($prod as $key1 => $val) {	
							if (is_int($key1)) {
								unset($prods[$key][$key1]);
							}			
						}
					}
				}		
			}

			if(!empty($prods)){
				foreach ($prods as $prod_key => $prod) {				
					if(!empty($prod)){
						$img='';
						$tax_percent=!empty($prod['tax_percent'])?$prod['tax_percent']:0;

						$res  = $db->getRows("SELECT product_variant_id,product_variant_group_id,price_qty,price,price_unit_id,u1.name as price_unit_name,disc_type,disc_amt,discounted_price,stock_qty,stock_unit_id,u2.name as stock_unit_name,min_order_qty,deliv_time,deliv_time_type,deliv_charge,cod_available FROM product_variant left join unit u1 on u1.unit_id=product_variant.price_unit_id left join unit u2 on u2.unit_id=product_variant.stock_unit_id where product_id=".$prod['product_id']." order by product_variant_id");

						if(!empty($res)){
							foreach ($res as $key => $res1) {				
								if(!empty($res1)){
									foreach ($res1 as $key1 => $val) {	
										if (is_int($key1)) {
											unset($res[$key][$key1]);
										}			
									}
								}
							}		
						}
						$vars = array();						
						if(!empty($res)){
							foreach ($res as $key => $res1) {				
								if(!empty($res1)){
									// $var=array();
									// $var['product_variant_id']=$res1['product_variant_id'];
									// $var['product_variant_group_id']=$res1['product_variant_group_id'];
									// $var['measurement']=$res1['price_qty'].' '.$res1['unit_name'].' / ₹ '.$res1['price'];

									if($res1['disc_type']=='P')
										$res1['disc_type']='Percent';
									elseif($res1['disc_type']=='A')
										$res1['disc_type']='Amount';

									if($res1['deliv_time_type']=='H')
										$res1['deliv_time_type']='Hours';
									elseif($res1['deliv_time_type']=='D')
										$res1['deliv_time_type']='Days';
									elseif($res1['deliv_time_type']=='W')
										$res1['deliv_time_type']='Weeks';

									if($res1['cod_available']=='Y')
										$res1['cod_available']='Yes';
									else
										$res1['cod_available']='No';

									$res1['tax_amt']=($tax_percent/100)*$res1['discounted_price'];

									$vars[]=$res1;

									if(empty($img)){
										$res_img = $db->getRow("SELECT img from product_img where product_id=".$prod['product_id']." and product_variant_group_id =".$res1['product_variant_group_id']);
										if(!empty($res_img)){
											$img =!empty($res_img['img'])?'uploads/product/'.$res_img['img']:'img/default_img.png';
											$img =$base_url.'/'.$img;
										}
									}
								}
							}		
						}
						$prods[$prod_key]['img'] = $img;
						$prods[$prod_key]['vars'] = $vars;						
					}					
				}		
			}

			// $resp['res'][]=$prods;
			$resp['res'][0]['seller_name']=$seller_name;
			$resp['res'][0]['seller_img']=$seller_img;
			$resp['res'][0]['prods']=$prods;
			$resp['status'] = 'success'; 
			$resp['code'] = 200;  
			$resp['message'] = 'Success!';
			
			break;
		}
		case 'get_variant_dtl':
		{
			$res  = $db->getRow("SELECT product_id,product_variant_id,product_variant_group_id,price_qty,price,price_unit_id,u1.name as price_unit_name,disc_type,disc_amt,discounted_price,stock_qty,stock_unit_id,u2.name as stock_unit_name,min_order_qty,deliv_time,deliv_time_type,deliv_charge,cod_available FROM product_variant left join unit u1 on u1.unit_id=product_variant.price_unit_id left join unit u2 on u2.unit_id=product_variant.stock_unit_id where product_variant_id=".$_POST['product_variant_id']);

			if(!empty($res)){
				foreach ($res as $key => $res1) {
					if (is_int($key)) {
						unset($res[$key]);
					}	
				}		

				if($res['disc_type']=='P')
					$res['disc_type']='Percent';
				elseif($res['disc_type']=='A')
					$res['disc_type']='Amount';

				if($res['deliv_time_type']=='H')
					$res['deliv_time_type']='Hours';
				elseif($res['deliv_time_type']=='D')
					$res['deliv_time_type']='Days';
				elseif($res['deliv_time_type']=='W')
					$res['deliv_time_type']='Weeks';

				if($res['cod_available']=='Y')
					$res['cod_available']='Yes';
				else
					$res['cod_available']='No';
			}

			$res_prod = $db->getRow("SELECT tax.name as tax_name,tax_percent from product left join tax on product.tax_id=tax.tax_id where product_id =".$res['product_id']);
			if(!empty($res_prod)){
				$tax_name=$res_prod['tax_name'];
				$tax_percent=$res_prod['tax_percent'];
			}
			else{
				$tax_name='';
				$tax_percent=0;	
			}
			
			$res['tax_name']=$tax_name;
			$res['tax_percent']=$tax_percent;

			$img='';
			$res_img = $db->getRow("SELECT img from product_img where product_id=".$res['product_id']." and product_variant_group_id =".$res['product_variant_group_id']);
			if(!empty($res_img)){
				$img =!empty($res_img['img'])?'uploads/product/'.$res_img['img']:'img/default_img.png';
				$img =$base_url.'/'.$img;
			}

			$res['img']=$img;
			$resp['res'][] =$res;
			$resp['status'] = 'success'; 
			$resp['code'] = 200;  
			$resp['message'] = 'Success!';
			
			break;
		}
		case 'get_today_market':
		{
			$res  = $db->getRows("SELECT today_market.product_id,product.name as prod_name,seller.name as seller_name,today_market.product_variant_id,product_variant.product_variant_group_id,price_qty,price,price_unit_id,u1.name as price_unit_name,disc_type,disc_amt,discounted_price,stock_qty,stock_unit_id,u2.name as stock_unit_name,min_order_qty,deliv_time,deliv_time_type,deliv_charge,cod_available,product_img.img,tax.name as tax_name,tax_percent FROM today_market left join product on product.product_id=today_market.product_id left join tax on product.tax_id=tax.tax_id left join seller on product.created_by=seller.seller_id left join product_variant on product_variant.product_variant_id=today_market.product_variant_id left join unit u1 on u1.unit_id=product_variant.price_unit_id left join unit u2 on u2.unit_id=product_variant.stock_unit_id left join product_img on product_img.product_variant_group_id=product_variant.product_variant_group_id and product_img.product_id=product.product_id group by today_market.product_variant_id order by today_market.sort_order,product_img.product_img_id");

			//echo $db->getLastQuery(); die;
			// $res = $db->getRows("SELECT today_market.product_id,today_market.product_variant_id,product.name as prod_name,seller.name as seller_name,product_variant.price_qty,product_variant.price,unit.name as unit_name,product_img.img FROM today_market left join product on product.product_id=today_market.product_id left join seller on product.created_by=seller.seller_id left join product_variant on product_variant.product_variant_id=today_market.product_variant_id left join unit on unit.unit_id=product_variant.price_unit_id left join product_img on product_img.product_variant_group_id=product_variant.product_variant_group_id and product_img.product_id=product.product_id group by today_market.product_variant_id order by today_market.sort_order,product_img.product_img_id");

			if(!empty($res)){
				foreach ($res as $key => $res1) {				
					if(!empty($res1)){
						foreach ($res1 as $key1 => $val) {	
							if (is_int($key1)) {
								unset($res[$key][$key1]);
							}			
						}

						$tax_percent=!empty($res1['tax_percent'])?$res1['tax_percent']:0;

						if($res1['disc_type']=='P')
							$res[$key]['disc_type']='Percent';
						elseif($res1['disc_type']=='A')
							$res[$key]['disc_type']='Amount';

						if($res1['deliv_time_type']=='H')
							$res[$key]['deliv_time_type']='Hours';
						elseif($res1['deliv_time_type']=='D')
							$res[$key]['deliv_time_type']='Days';
						elseif($res1['deliv_time_type']=='W')
							$res[$key]['deliv_time_type']='Weeks';

						if($res1['cod_available']=='Y')
							$res[$key]['cod_available']='Yes';
						else
							$res[$key]['cod_available']='No';

						$res[$key]['tax_amt']=($tax_percent/100)*$res1['discounted_price'];						

						$img =!empty($res1['img'])?'uploads/product/'.$res1['img']:'img/default_img.png';
						$res[$key]['img']= $base_url.'/'.$img;
						// $res[$key]['measurement']=$res1['price_qty'].' '.$res1['unit_name'].' / ₹ '.$res1['price'];
					}
				}		
			}

			$resp['res'] =$res;
			$resp['status'] = 'success'; 
			$resp['code'] = 200;  
			$resp['message'] = 'Success!';
			
			break;
		}
		case 'get_product_dtl':
		{
			$prod = $db->getRow("SELECT product.name,description,tax.name as tax_name,tax_percent from product left join tax on product.tax_id=tax.tax_id where product_id=".$_POST['product_id']);

			foreach ($prod as $key => $val) {	
				if (is_int($key)) {
					unset($prod[$key]);
				}			
			}

			if(!empty($prod['tax_percent'])){
				$tax_name=$prod['tax_name'];
				$tax_percent=$prod['tax_percent'];	
			}
			else{
				$tax_name='';
				$tax_percent=0;
			}			

			$img='';
			$res  = $db->getRows("SELECT product_variant_id,product_variant_group_id,price_qty,price,price_unit_id,u1.name as price_unit_name,disc_type,disc_amt,discounted_price,stock_qty,stock_unit_id,u2.name as stock_unit_name,min_order_qty,deliv_time,deliv_time_type,deliv_charge,cod_available FROM product_variant left join unit u1 on u1.unit_id=product_variant.price_unit_id left join unit u2 on u2.unit_id=product_variant.stock_unit_id where product_id=".$_POST['product_id']." order by product_variant_id");
			//echo $db->getLastQuery(); die;
			// $res  = $db->getRows("SELECT product_variant_id,product_variant_group_id,price_qty,price,unit.name as unit_name FROM product_variant left join unit on unit.unit_id=product_variant.price_unit_id where product_id=".$_POST['product_id']." order by price_qty");
			if(!empty($res)){
				foreach ($res as $key => $res1) {				
					if(!empty($res1)){
						// $res[$key]['measurement']=$res1['price_qty'].' '.$res1['unit_name'].' / ₹ '.$res1['price'];
						foreach ($res1 as $key1 => $val) {	
							if (is_int($key1)) {
								unset($res[$key][$key1]);
							}			
						}

						if($res1['disc_type']=='P')
							$res[$key]['disc_type']='Percent';
						elseif($res1['disc_type']=='A')
							$res[$key]['disc_type']='Amount';

						if($res1['deliv_time_type']=='H')
							$res[$key]['deliv_time_type']='Hours';
						elseif($res1['deliv_time_type']=='D')
							$res[$key]['deliv_time_type']='Days';
						elseif($res1['deliv_time_type']=='W')
							$res[$key]['deliv_time_type']='Weeks';

						if($res1['cod_available']=='Y')
							$res[$key]['cod_available']='Yes';
						else
							$res[$key]['cod_available']='No';

						$res[$key]['tax_amt']=($tax_percent/100)*$res1['discounted_price'];

						if(empty($img)){
							$res_img = $db->getRow("SELECT img from product_img where product_id=".$_POST['product_id']." and product_variant_group_id =".$res1['product_variant_group_id']);
							if(!empty($res_img)){
								$img =!empty($res_img['img'])?'uploads/product/'.$res_img['img']:'img/default_img.png';
								$img =$base_url.'/'.$img;
							}
						}						
					}
				}	

				$resp['tax_name']=$tax_name;
				$resp['tax_percent']=$tax_percent;	
			}

			$prod['img'] = $img;
			$prod['vars'] = $res;

			$resp['res'][] =$prod;
			$resp['status'] = 'success'; 
			$resp['code'] = 200;  
			$resp['message'] = 'Success!';
			
			break;
		}
		case 'get_top_seller':
		{
			$res = $db->getRows("SELECT top_seller.seller_id,top_seller.type,seller.name as name,seller.img FROM top_seller left join seller on top_seller.seller_id=seller.seller_id where top_seller.show_home='Y' order by top_seller.type desc,top_seller.sort_order");
			
			$top_seller=array();
			$top_seller[0]['cap']='Top Wholesalers';
			$top_seller[0]['seller_type']='W';
			$top_seller[0]['seller_list']=array();
			$top_seller[1]['cap']='Top Semi Wholesalers';
			$top_seller[1]['seller_type']='S';
			$top_seller[1]['seller_list']=array();
			$top_seller[2]['cap']='Top Retailers';
			$top_seller[2]['seller_type']='R';
			$top_seller[2]['seller_list']=array();

			$seller_list1=$seller_list2=$seller_list3=array();

			if(!empty($res)){
				foreach ($res as $key => $res1) {				
					if(!empty($res1)){						
						$img =!empty($res1['img'])?'uploads/product/'.$res1['img']:'img/default_img.png';
						$res[$key]['img']= $base_url.'/'.$img;

						foreach ($res1 as $key1 => $val) {	
							if (is_int($key1)) {
								unset($res[$key][$key1]);
							}			
						}

						if($res1['type']=='W')
							$seller_list1[]= $res[$key];
						elseif($res1['type']=='S')
							$seller_list2[]= $res[$key];
						elseif($res1['type']=='R')
							$seller_list3[]= $res[$key];
					}
				}		
			}

			if(!empty($seller_list1))
				$top_seller[0]['seller_list'] = $seller_list1;
			else
				unset($top_seller[0]);

			if(!empty($seller_list2))
				$top_seller[1]['seller_list'] = $seller_list2;
			else
				unset($top_seller[1]);

			if(!empty($seller_list3))
				$top_seller[2]['seller_list'] = $seller_list3;
			else
				unset($top_seller[2]);			 

			foreach ($top_seller as $key => $seller) {	
				$resp['res'][]=$seller;				
			}

			$resp['status'] = 'success'; 
			$resp['code'] = 200;  
			$resp['message'] = 'Success!';
			
			break;
		}

		case 'get_main_category':
		{
			$res = $db->getRows("SELECT main_category_id,name,slug,img FROM main_category order by sort_order");

			if(!empty($res)){
				foreach ($res as $key => $res1) {				
					if(!empty($res1)){
						$img =!empty($res1['img'])?'uploads/main_category/'.$res1['img']:'img/default_img.png';
						$res[$key]['img']= $base_url.'/'.$img;
						foreach ($res1 as $key1 => $val) {	
							if (is_int($key1)) {
								unset($res[$key][$key1]);
							}			
						}
					}
				}		
			}

			//echo "<pre>"		;print_r($res);die;
			$resp['res'] =$res;

			$resp['status'] = 'success'; 
			$resp['code'] = 200;  
			$resp['message'] = 'Success!';
			
			break;
		}
		case 'get_category':
		{
			$res = $db->getRows("SELECT category_id,main_category_id,name,slug,img FROM category where main_category_id=".$_POST['main_category_id']." order by sort_order");

			if(!empty($res)){
				foreach ($res as $key => $res1) {				
					if(!empty($res1)){
						$img =!empty($res1['img'])?'uploads/category/'.$res1['img']:'img/default_img.png';
						$res[$key]['img']= $base_url.'/'.$img;
						foreach ($res1 as $key1 => $val) {	
							if (is_int($key1)) {
								unset($res[$key][$key1]);
							}			
						}
					}
				}		
			}

			//echo "<pre>"		;print_r($res);die;
			$resp['res'] =$res;

			$resp['status'] = 'success'; 
			$resp['code'] = 200;  
			$resp['message'] = 'Success!';
			
			break;
		}
		case 'get_sub_category':
		{
			$res = $db->getRows("SELECT sub_category_id,category_id,name,slug,img FROM sub_category where category_id=".$_POST['category_id']." order by sort_order");

			if(!empty($res)){
				foreach ($res as $key => $res1) {				
					if(!empty($res1)){
						$img =!empty($res1['img'])?'uploads/sub_category/'.$res1['img']:'img/default_img.png';
						$res[$key]['img']= $base_url.'/'.$img;
						foreach ($res1 as $key1 => $val) {	
							if (is_int($key1)) {
								unset($res[$key][$key1]);
							}			
						}
					}
				}		
			}

			//echo "<pre>"		;print_r($res);die;
			$resp['res'] =$res;

			$resp['status'] = 'success'; 
			$resp['code'] = 200;  
			$resp['message'] = 'Success!';
			
			break;
		}
		case 'get_city':
		{
			$res = $db->getRows("SELECT city_id,name FROM city order by name");

			if(!empty($res)){
				foreach ($res as $key => $res1) {				
					if(!empty($res1)){
						foreach ($res1 as $key1 => $val) {	
							if (is_int($key1)) {
								unset($res[$key][$key1]);
							}			
						}
					}
				}		
			}
			$resp['res'] =$res;
			$resp['status'] = 'success'; 
			$resp['code'] = 200;  
			$resp['message'] = 'Success!';			
			break;
		}
		case 'get_area':
		{
			$res = $db->getRows("SELECT area_id,name FROM area where city_id=".$_POST['city_id']." order by name");

			if(!empty($res)){
				foreach ($res as $key => $res1) {				
					if(!empty($res1)){
						foreach ($res1 as $key1 => $val) {	
							if (is_int($key1)) {
								unset($res[$key][$key1]);
							}			
						}
					}
				}		
			}
			$resp['res'] =$res;
			$resp['status'] = 'success'; 
			$resp['code'] = 200;  
			$resp['message'] = 'Success!';			
			break;
		}		
	}
	//echo "<pre>";print_r($resp);die;
	echo json_encode($resp);
	?>