<?php 
$resp=array();
if(!empty($_POST['token'])){
	$res = $db->getRow("SELECT customer_id FROM customer where customer_id=".$_POST['customer_id']." and api_token='".$_POST['token']."'");
	// print_r($res);die;
	if (count($res)==0) {
		$resp['status'] = 'error'; 
		$resp['code'] = 401;  
		$resp['message'] = 'Invalid mandatory fields!';    
		echo json_encode($resp);
		exit;
	}
}
else{
	$resp['status'] = 'error'; 
	$resp['code'] = 401;  
	$resp['message'] = 'Please fill mandatory fields!';    
	echo json_encode($resp);
	exit;
} 
?>