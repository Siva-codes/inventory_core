<?php
error_reporting( E_ALL );
ini_set( "display_errors", 1 );
require '../config.php';	
include 'header.php';

$action = $_POST['action'];

if($action!='check_stock')
	include 'token_verify.php';	 

$resp=array();
$resp['status'] = $_POST['action']; 
$resp['code'] = 200;  
$resp['message'] = 'Success!';
switch ($action) {
	case 'add_cart':{
		$res = $db->getRow("SELECT cart_id FROM cart where customer_id=".$_POST['customer_id']." and product_variant_id=".$_POST['product_variant_id']);
		if (count($res)==0) {
			$save= array();
			$save['customer_id']= $_POST['customer_id'];
			$save['product_id']= $_POST['product_id'];
			$save['product_variant_id']= $_POST['product_variant_id'];
			$save['qty']= $_POST['qty'];
			$save['created_date']= time(); 
			$id = $db->insertAry('cart',$save);
		}
		else{
			$save= array();
			$save['qty']= $_POST['qty'];
			$res = $db->updateAry("cart", $save, "where cart_id=".$res['cart_id']);
		}

		$resp['status'] = 'success'; 
		$resp['code'] = 200;  
		$resp['message'] = 'Success!';
		break; 
	}
	case 'view_cart':
	{
		$res=$prod=array();
		$cart_items=$_POST['cart_items'];
		$cart_items = json_decode($cart_items,true);

		$tot_amt=0;
		foreach ($cart_items as $key => $cart_item){
			$res  = $db->getRow("SELECT product_variant.product_id,product.name as product_name,product_variant_id,product_variant_group_id,price_qty,price,price_unit_id,u1.name as price_unit_name,disc_type,disc_amt,discounted_price,stock_qty,stock_unit_id,u2.name as stock_unit_name,min_order_qty,deliv_time,deliv_time_type,deliv_charge,cod_available FROM product_variant left join product on product_variant.product_id=product.product_id left join unit u1 on u1.unit_id=product_variant.price_unit_id left join unit u2 on u2.unit_id=product_variant.stock_unit_id where product_variant_id=".$cart_item['id']);

			//echo $db->getLastQuery(); die;
			if(!empty($res)){
				foreach ($res as $key => $res1) {
					if (is_int($key)) {
						unset($res[$key]);
					}	
				}		

				if($res['disc_type']=='P')
					$res['disc_type']='Percent';
				elseif($res['disc_type']=='A')
					$res['disc_type']='Amount';

				if($res['deliv_time_type']=='H')
					$res['deliv_time_type']='Hours';
				elseif($res['deliv_time_type']=='D')
					$res['deliv_time_type']='Days';
				elseif($res['deliv_time_type']=='W')
					$res['deliv_time_type']='Weeks';

				if($res['cod_available']=='Y')
					$res['cod_available']='Yes';
				else
					$res['cod_available']='No';

				$amt = (double)$res['discounted_price']*$cart_item['qty'];
				$res['amt']=$amt;				
				$tot_amt=$tot_amt+$amt;

				$img='';
				$res_img = $db->getRow("SELECT img from product_img where product_id=".$res['product_id']." and product_variant_group_id =".$res['product_variant_group_id']);
				if(!empty($res_img)){
					$img =!empty($res_img['img'])?'uploads/product/'.$res_img['img']:'img/default_img.png';
					$img =$base_url.'/'.$img;
				}

				$res['img']=$img;
				$res['qty']=$cart_item['qty'];
				
				$prod[]=$res;
			}			
		}
		
		$resp['res'] =$prod;
		$resp['tot_amt'] = $tot_amt;

		// $charge=0;
		// if($tot_amt>0){
		// 	$res = $db->getRows("SELECT shipcost from shipping where amount>=".$tot_amt." order by amount");
		// 	if(!empty($res))
		// 		$charge=$res[0]['shipcost'];   
		// }

		// $resp['charge_amt'] = $charge;

		$resp['status'] = 'success'; 
		$resp['code'] = 200;  
		$resp['message'] = 'Success!';

		break;
	}
	case 'check_stock':{
		$product_variant_id = $_POST['product_variant_id'];
		$qty = $_POST['qty'];

		$res = $db->getRow("SELECT price_unit_id,stock_qty,stock_unit_id,stock_status FROM product_variant  where product_variant_id =".$product_variant_id);
		$stock_status='';
		$stock_qty=0;
		if(!empty($res)){
			$stock_status='Available';
			$stock_qty = $res['stock_qty'];
			$price_unit_id = $res['price_unit_id']; 
			$stock_unit_id = $res['stock_unit_id'];

			if($res['stock_status']=='AV'){
				if($price_unit_id==$stock_unit_id){
					if($stock_qty < $qty)
						$stock_status='No Stock';
				}
				else{
					$res1 = $db->getRow("SELECT parent_unit_id,conversion FROM unit  where unit_id =".$price_unit_id);
					if($stock_unit_id==$res1['parent_unit_id']){
						$stock_qty = $stock_qty*(double)$res1['conversion'];
						if($stock_qty < $qty)
							$stock_status='No Stock';
					}
				}				
			}
			else{
				if($res['stock_status']=='SO')
					$stock_status='Sold Out';
				elseif($res['stock_status']=='NA')
					$stock_status='Not Available';
				elseif($res['stock_status']=='SC')
					$stock_status='Shop Closed';
				else
					$stock_status='-';
			}
		}

		$resp['stock_qty']=$stock_qty;
		$resp['stock_status']=$stock_status;
		$resp['status'] = 'success'; 
		$resp['code'] = 200;  
		$resp['message'] = 'Success!';
		break; 
	}
	case 'get_promo':
	{
		$customer_id=$_POST['customer_id'];
		$promo_code=$_POST['code'];
		$tot_amt=$_POST['tot_amt'];

		$res = $db->getRow("select * from promo_code where code=BINARY'".$promo_code."'");
		if(!empty($res)){
			foreach ($res as $key => $val) {	
				if (is_int($key)) {
					unset($res[$key]);
				}			
			}
		}

		if(empty($res)){
			$resp['status'] = 'error'; 
			$resp['code'] = 203;  
			$resp['message'] = "Invalid Promo code.";
			break;
		}
		if($res['status']!='A'){
			$resp['status'] = 'error'; 
			$resp['code'] = 203;  
			$resp['message'] = "This Promo code is either expired / invalid.";
			break;
		}

		$res1 = $db->getRow("select customer_id from customer where customer_id=".$customer_id);
		if(!empty($res1)){
			foreach ($res1 as $key => $val) {	
				if (is_int($key)) {
					unset($res1[$key]);
				}			
			}
		}

		if(empty($res1)){
			$resp['status'] = 'error'; 
			$resp['code'] = 203;  
			$resp['message'] = "Invalid Customer.";
			break;
		}

		$fr_date = $res['fr_date'];
		$to_date = $res['to_date'];
		$date = time();

		if($date<$fr_date){
			$resp['status'] = 'error'; 
			$resp['code'] = 203;  
			$resp['message'] = "This Promo code can't be used before ".date('d-m-Y',strtotime($fr_date))."";
			break;
		}
		if($date>$to_date){
			$resp['status'] = 'error'; 
			$resp['code'] = 203;  
			$resp['message'] ="This Promo code can't be used after ".date('d-m-Y',strtotime($to_date))."";
			break;
		}
		if($tot_amt<$res['min_order_amt']){
			$resp['status'] = 'error'; 
			$resp['code'] = 203;  
			$resp['message'] ="This Promo code is applicable only for order amount greater than or equal to ".$res['min_order_amt']."";
			break;
		}
		if($res['tot_usage']==0){
			$resp['status'] = 'error'; 
			$resp['code'] = 203;  
			$resp['message'] ="This Promo code is not usage!";
			break;
		}

		$res1 = $db->getRow("select count(orders_id) as tot_rec from orders where promo_code=BINARY'".$promo_code."' GROUP BY customer_id");
		if(!empty($res1) && $res1['tot_rec']>=$res['tot_customer']){
			$resp['status'] = 'error'; 
			$resp['code'] = 203;  
			$resp['message'] ="This Promo code is applicable only for first ".$res['tot_customer']." customers.";
			break;
		}

		$res1 = $db->getRow("select count(orders_id) as tot_rec from orders where customer_id=".$customer_id." and promo_code=BINARY'".$promo_code."'");
		if(!empty($res1) && $res1['tot_rec']>=$res['tot_usage']){
			$resp['status'] = 'error'; 
			$resp['code'] = 203;  
			$resp['message'] ="This Promo code is applicable only for ".$res['tot_usage']." times.";
			break;
		}

		if($res['disc_type']=='P'){
			$percent = $res['disc_amt'];
			$disc_amt = $tot_amt/100*$percent;

			if($disc_amt>$res['max_disc_amt'])
				$disc_amt=$res['max_disc_amt'];		
		}
		else
			$disc_amt=$res['disc_amt'];

		$discounted_amount = $tot_amt - $disc_amt;
		$res1=array();
		$res1['promo_code'] = $promo_code;
		$res1['promo_code_msg'] = $res['description'];
		$res1['tot_amt'] = $tot_amt;
		$res1['disc_amt'] = "$disc_amt";
		$res1['discounted_amount'] = "$discounted_amount";

		$resp['res']= $res1;
		$resp['status'] = 'success'; 
		$resp['code'] = 200;  
		$resp['message'] = 'Success!';
		break;	
	}
	case "save_order":{
		$res=$prod=array();
		$order_no='';
		$cart_items=$_POST['cart_items'];
		$cart_items = json_decode($cart_items,true);
		
		$delivery_date=$_POST['delivery_date'];
		$delivery_date = str_replace('/', '-', $delivery_date);
		$delivery_date = explode("-",$delivery_date);
		$delivery_date=mktime(0, 0, 0,$delivery_date[1],$delivery_date[0],$delivery_date[2]);
		$status= array('Received',date("d-m-Y h:i:sa"));
		$status = json_encode($status);

		$save = array(
			'customer_id'          =>$_POST['customer_id'],			
			'customer_address_id'          => $_POST['customer_address_id'],
			'delivery_boy_id'        =>0,
			'tot_amt'       => $_POST['tot_amt'],			
			'delivery_charge'           => $_POST['delivery_charge'],
			'tax_amt'           => 0,
			'tax_percent'           => '',
			'wallet_amt'           =>  $_POST['wallet_amt'],
			'disc_amt'           => 0,
			'promo_code'           =>  $_POST['promo_code'],
			'promo_disc_amt'           =>  $_POST['promo_disc_amt'],
			'delivery_date'           => $delivery_date,
			'time_slot_id'           => $_POST['time_slot_id'],
			'final_amt'           => $_POST['final_amt'],
			'pay_type'         => $_POST['pay_type'],
			'txn_id'         => $_POST['txn_id'],			 
			'latitude'           =>$_POST['latitude'],
			'longitude'           =>$_POST['longitude'],
			'order_status_id' =>1,
			'status' =>$status,
			'created_by'=>$_POST['customer_id'],
			'created_date'=> time()
		);

		$orders_id = $db->insertAry('orders',$save);			
		$order_no = 'KM'.$_POST['customer_id'].str_pad($orders_id,5,"0",STR_PAD_LEFT);
		$save = array('order_no'=>$order_no);
		$q = $db->updateAry("orders", $save,"where orders_id=".$orders_id);

		foreach ($cart_items as $key => $cart_item){				
			$qty = (double)$cart_item['qty'];

			$res  = $db->getRow("SELECT product_variant_id,price_qty,price,price_unit_id,price FROM product_variant where product_variant_id=".$cart_item['id']);
			// [{"id":"1","qty":"2","disc_amt":"2","discounted_price":"2","tax_id":"2","tax_amt":"2","amt":"5"},{"id":"2","qty":"12","disc_amt":"20","discounted_price":"6","tax_id":"7","tax_amt":"14","amt":"255"}]

			$save = array(
				'orders_id' => $orders_id,  
				'product_variant_id' => $cart_item['id'],
				'price_unit_id' => $res['price_unit_id'],
				'price_qty' => $res['price_qty'],
				'qty' =>$cart_item['qty'],
				'price' => $res['price_qty'],
				'disc_amt' => $cart_item['disc_amt'],
				'discounted_price' => $cart_item['discounted_price'],
				'tax_id' => $cart_item['tax_id'],
				'tax_amt' => $cart_item['tax_amt'],
				'amt' => $cart_item['amt'],
				'status' =>$status,
				'order_status_id' => 1
			);

			$db->insertAry('order_dtl',$save);
		}	 	
		
		$resp['res']= 'Order No.'.$order_no;
		$resp['status'] = 'success'; 
		$resp['code'] = 200;  
		$resp['message'] = 'Success!';
		break;	
	}
	case 'get_orders':
	{
		$res = $db->getRows("SELECT orders_id,order_no, customer_id, customer.name as customer_name, customer_address.mobile,  customer_address.city_id,customer_address.area_id,city.name as city_name,area.name as area_name,customer_address.pin,customer_address.street,customer_address.address,customer_address.latitude,customer_address.longitude, tot_amt, delivery_charge,wallet_amt,promo_code,promo_disc_amt,delivery_date,time_slot_id payid, coupon, couponprice, lat, lng, dtype, dcode, driverid, dname, dmobile, ordertime FROM orders LEFT JOIN deliveryboy on orders.driverid = deliveryboy.id where orders.user_id =".$_POST['user_id']." ORDER BY orderid DESC limit 50");
			 //echo $db->getLastQuery(); exit;
		if(!empty($res)){
			foreach ($res as $key => $res1) {				
				$res[$key]['ordertime'] = date('d/m/Y h:i A',$res1['ordertime']);
			}
			foreach ($res as $key => $res1) {				
				if(!empty($res1)){
					foreach ($res1 as $key1 => $val) {	
						if (is_int($key1)) {
							unset($res[$key][$key1]);
						}			
					}
				}
			}		
		}

			// echo "<pre>"		;print_r($res);die;
		$resp['res'] =$res;

		$resp['status'] = 'success'; 
		$resp['code'] = 200;  
		$resp['message'] = 'Success!';

		break;
	}

	case 'get_order_dtl':
	{
		$res = $db->getRow("SELECT orderid,order_no, user_id, fname, mobile, city, area, address ,status, total, shipping, paymenttype, payid, coupon, couponprice, ordertime,deliveryslot FROM orders where orderid =".$_POST['orderid']);
			 //echo $db->getLastQuery(); exit;
		if(!empty($res)){
			$res['ordertime'] = date('d/m/Y h:i A',$res['ordertime']);
			foreach ($res as $key => $val) {	
				if (is_int($key)) {
					unset($res[$key]);
				}			
			}
		}
		$resp['res']['order'] =$res;

		$order_dtl=array();
		$res = $db->getRows("SELECT items_id,itemname,itemquantitytype,itemquantity,Mquantity,itemprice,itemtotal FROM orderslist where orderid =".$_POST['orderid']." order by id");

		if(!empty($res)){
			foreach ($res as $key => $res1) {				
				if(!empty($res1)){
					foreach ($res1 as $key1 => $val) {	
						if (is_int($key1)) {
							unset($res[$key][$key1]);
						}			
					}
				}
			}		

			foreach ($res as $key => $res1) {	
				$prod = $db->getRow("SELECT image from items where id =".$res1['items_id']);
				$res2=array();
				$res2['items_id']=$res1['items_id'];
				$res2['name']=$res1['itemname'];
				$res2['img']=$base_url."/uploads/itemimg/".$prod['image'];
				$res2['unit_qty']=$res1['itemquantity'].$res1['itemquantitytype'];
				$res2['qty']=$res1['Mquantity'];
				$res2['price']=$res1['itemprice'];
				$amt = (double)$res1['itemtotal'];
				$res2['amt']=$amt;
				$order_dtl[]=$res2;
			}								
		}

			//echo "<pre>"		;print_r($res);die;
		$resp['res']['order_dtl'] =$order_dtl;

		$resp['status'] = 'success'; 
		$resp['code'] = 200;  
		$resp['message'] = 'Success!';

		break;
	}
	case 'get_order_track':
	{
		$res = $db->getRow("SELECT ordertime,order_no, status FROM orders where orderid =".$_POST['orderid']);
		if(!empty($res)){
			$res['ordertime'] = date('d/m/Y h:i A',$res['ordertime']);
			foreach ($res as $key => $val) {	
				if (is_int($key)) {
					unset($res[$key]);
				}			
			}
		}
		$resp['res']['order'] =$res;
		$resp['status'] = 'success'; 
		$resp['code'] = 200;  
		$resp['message'] = 'Success!';

		break;
	}
}
echo json_encode($resp);
?>