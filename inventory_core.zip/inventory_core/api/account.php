	<?php
	error_reporting( E_ALL );
	ini_set( "display_errors", 1 );
	require '../config.php';	
	include 'header.php';

	$action = $_POST['action'];

	if ($action=='save_profile' || $action=='save_pw' || $action=='save_address' || $action=='check_pw')
		include 'token_verify.php';

	if($action =='register'){
		$refferal_customer_id=0;
		if(!empty($_POST['email']))
			$res = $db->getRow("SELECT customer_id FROM customer where mobile='".$_POST['mobile']."' or email='".$_POST['email']."'");  
		else
			$res = $db->getRow("SELECT customer_id FROM customer where mobile='".$_POST['mobile']."'");  

		// echo $db->getLastQuery(); die;  
		if (count($res) > 0) {   		 
			$resp['status'] = 'error'; 
			$resp['code'] = 203;  

			if(!empty($_POST['email']))
				$resp['message'] = 'Mobile No. or Email id already exists!';
			else
				$resp['message'] = 'Mobile No. already exists!';

			echo json_encode($resp);
			exit;
		}	
		elseif(!empty($_POST['fr_referral_code'])){
			$res = $db->getRow("SELECT customer_id FROM customer where referral_code='".$_POST['fr_referral_code']."'");
			if (empty($res)) {   		 
				$resp['status'] = 'error'; 
				$resp['code'] = 203;  
				$resp['message'] = 'Invalid Referral code!';
				echo json_encode($resp);
				exit;
			}
			else
				$refferal_customer_id=$res['customer_id'];	
		}
	}	

	$resp=array();
	$resp['status'] = $_POST['action']; 
	$resp['code'] = 200;  
	$resp['message'] = 'Success!';
	switch ($action) {
		case 'register':
		{
			$api_token= implode('-', str_split(substr(strtolower(md5(microtime().rand(1000, 9999))), 0, 30), 6));
			$save=$_POST;
			$save['api_token']=$api_token;
			$save['created_date']=time();
			$save['refferal_customer_id']=$refferal_customer_id;
			unset($save['fr_referral_code']);
			unset($save['action']);
			$id = $db->insertAry('customer',$save);
			// echo $db->getLastQuery(); die;

			if(!is_null($id)){
				$save1=array();
				$save1['customer_id']=$id;
				$save1['mobile']=$save['mobile'];
				$save1['city_id']=$save['city_id'];
				$save1['area_id']=$save['area_id'];
				$save1['street']=$save['street'];
				$save1['pin']=$save['pin'];
				$save1['address']=$save['address'];
				$save1['latitude']=$save['latitude'];
				$save1['longitude']=$save['longitude'];
				$save1['status']='A';
				$save1['pin']=$save['pin'];
				$save1['created_date']= time(); 
				$db->insertAry('customer_address',$save1);

				$res = $db->getRow("SELECT * FROM customer where customer_id=".$id); 
				$resp['customer_id'] = $id;
				$resp['customer_name'] =$res['name'];	
				$resp['api_token'] = $res['api_token'];	

				$resp['status'] = 'success'; 
				$resp['code'] = 200;  
				$resp['message'] = 'Customer registered successfully!';	
			}
			else{
				$resp['status'] = 'error'; 
				$resp['code'] = 400;  
				$resp['message'] = 'Customer registeration failed!';
			}

			break;
		}	
		case 'send_otp':
		{
			if(!empty($_POST['mobile']) && !empty($_POST['type'])){
				$res = $db->getRow("SELECT * FROM customer where mobile='".$_POST['mobile']."'");
				if($_POST['type']=='L'){					
					if (empty($res)) {   
						$resp['status'] = 'error'; 
						$resp['code'] = 400;  
						$resp['message'] = 'Mobile No. not registered!';  

						break;  
					}
				}
				else{
					if (!empty($res)) {   
						$resp['status'] = 'error'; 
						$resp['code'] = 400;  
						$resp['message'] = 'Mobile No. alrady registered!';  

						break;  
					}
				}				
				
				$otp = rand(10000 , 99999);
				$resp['otp'] = $otp;	

				$resp['status'] = 'success'; 
				$resp['code'] = 200;  
				$resp['message'] = 'OTP sent successfully!';	
			}
			else{
				$resp['status'] = 'error'; 
				$resp['code'] = 400;  
				$resp['message'] = 'Please fill mandatory fields!';    
			} 
			break;
		}	 
		
		case 'login':
		{
			if((!empty($_POST['mobile']) && !empty($_POST['password'])) || (!empty($_POST['mobile']) && !empty($_POST['otp_verified'])) || !empty($_POST['fb_id']) || !empty($_POST['gmail_id'])){
				
				$log_suc=0;
				if(!empty($_POST['mobile']) && (!empty($_POST['password']) || !empty($_POST['otp_verified']))){
					$mobile = $_POST['mobile'];

					if(!empty($_POST['password']))
						$res = $db->getRow("SELECT * FROM customer where (mobile='".$mobile."' or email='".$mobile."') and password='".$_POST['password']."'");    
					elseif($_POST['otp_verified']=='1')
						$res = $db->getRow("SELECT * FROM customer where mobile='".$mobile."' or email='".$mobile."'");

					if (count($res) > 0) {  
						$log_suc = 1;	 						
					}
					else{
						$resp['status'] = 'error'; 
						$resp['code'] = 203;  
						$resp['message'] = 'Invalid mobile/password!';
					}
				}
				else{
					$fb_id = $_POST['fb_id'];
					$gmail_id = $_POST['gmail_id'];

					if(!empty($_POST['fb_id']))	
						$res = $db->getRow("SELECT * FROM customer where fb_id='".$_POST['fb_id']."'");    
					elseif(!empty($_POST['gmail_id']))	
						$res = $db->getRow("SELECT * FROM customer where gmail_id='".$_POST['gmail_id']."'");    

					if (count($res) > 0) {   
						$log_suc = 1;
					}
					else{
						$api_token= implode('-', str_split(substr(strtolower(md5(microtime().rand(1000, 9999))), 0, 30), 6));
						// $otp = rand(10000 , 99999);

						$save=array();
						if(isset($_POST['name']))
							$save['name'] = $_POST['name'];	

						if(isset($_POST['email']))
							$save['email'] = $_POST['email'];	

						if(isset($_POST['mobile']))
							$save['mobile'] = $_POST['mobile'];	

						if(isset($_POST['fb_id']))
							$save['fb_id'] = $_POST['fb_id'];	

						if(isset($_POST['gmail_id']))
							$save['gmail_id'] = $_POST['gmail_id'];	

						$save['api_token'] = $api_token;	
						// $save['otp'] = $otp;	
						$save['created_date'] = time();

						$id = $db->insertAry('customer',$save);
						if(!is_null($id)){
							$res = $db->getRow("SELECT * FROM customer where customer_id=".$id); 
							$resp['customer_id'] = $id;
							$resp['customer_name'] =$res['name'];	
							$resp['api_token'] = $res['api_token'];	
							// $resp['otp'] = $res['otp'];	

							$resp['status'] = 'success'; 
							$resp['code'] = 200;  
							$resp['message'] = 'Customer logged in successfully!';	
						}
						else{
							$resp['status'] = 'error'; 
							$resp['code'] = 400;  
							$resp['message'] = 'Customer logged in failed!';
						}
					}
				}

				if($log_suc==1){
					$api_token= implode('-', str_split(substr(strtolower(md5(microtime().rand(1000, 9999))), 0, 30), 6));

					$save=array();
					$save['api_token'] =$api_token;
					$db->updateAry("customer", $save, " WHERE customer_id=".$res['customer_id']);

					$resp['customer_id'] = $res['customer_id'];
					$resp['customer_name'] =$res['name'];	
					$resp['api_token'] =$api_token;   

					$resp['status'] = 'success'; 
					$resp['code'] = 200;  
					$resp['message'] = 'Customer logged in successfully!';
				}
			}
			else{
				$resp['status'] = 'error'; 
				$resp['code'] = 400;  
				$resp['message'] = 'Please fill mandatory fields!';    
			} 
			break;
		}
		case 'get_profile':
		{
			$res = $db->getRow("SELECT customer.*,area.name as area_name,city.name as city_name FROM customer left join city on customer.city_id=city.city_id left join area on customer.area_id=area.area_id where customer_id=".$_POST['customer_id']);

			if(!empty($res)){
				foreach ($res as $key => $val) {	
					if (is_int($key)) {
						unset($res[$key]);
					}			
				}
			}

			$resp['res'][]=$res;

			$resp['status'] = 'success'; 
			$resp['code'] = 200;  
			$resp['message'] = 'Success!';

			break;
		}
		case "check_pw":
		{
			$res  = $db->getRow("SELECT password FROM customer where password='".$_POST['password']."' and customer_id=".$_POST["customer_id"]);
			if( count($res) > 0){
				$resp['status'] = 'success'; 
				$resp['code'] = 200;  
				$resp['message'] = 'Success!';
			}
			else{
				$resp['status'] = 'error'; 
				$resp['code'] = 400;  
				$resp['message'] = 'Invalid password!'; 
			}

			break;
		}
		case 'save_profile':
		{
			$save=$_POST;
			
			if(isset($_POST['password']))
				$save['password'] = $_POST['password'];
			else
				unset($save['password']);
			
			unset($save['action']);
			unset($save['token']);

			$save['modified_by']= $_POST['customer_id']; 
			$save['modified_date']= time(); 
			$qry = $db->updateAry("customer", $save, "where customer_id=".$_POST['customer_id']);

			if(!is_null($qry)){
				$res = $db->getRows("SELECT customer_address_id from customer_address where customer_id=".$_POST['customer_id']." order by customer_address_id");
				if(!empty($res)){
					$save1=array();
					$save1['mobile']=$save['mobile'];
					$save1['city_id']=$save['city_id'];
					$save1['area_id']=$save['area_id'];
					$save1['street']=$save['street'];
					$save1['pin']=$save['pin'];
					$save1['address']=$save['address'];
					$save1['latitude']=$save['latitude'];
					$save1['longitude']=$save['longitude'];
					$save1['pin']=$save['pin'];
					$save1['modified_date']= time(); 
					$db->updateAry("customer_address", $save1, "where customer_address_id=".$res[0]['customer_address_id']);
				}

				$resp['customer_name'] =$_POST['name'];	

				$resp['status'] = 'success'; 
				$resp['code'] = 200;  
				$resp['message'] = 'Profile updated successfully!';	
			}
			else{
				$resp['status'] = 'error'; 
				$resp['code'] = 400;  
				$resp['message'] = 'Profile update failed!';
			}

			break;
		}
		case 'save_pw':
		{
			$save = array(
				'password'     => $_POST['password'] 
			);

			$qry = $db->updateAry("customer", $save, "where customer_id=".$_POST['customer_id']);

			if(!is_null($qry)){
				$resp['status'] = 'success'; 
				$resp['code'] = 200;  
				$resp['message'] = 'Profile updated successfully!';	
			}
			else{
				$resp['status'] = 'error'; 
				$resp['code'] = 400;  
				$resp['message'] = 'Profile update failed!';
			}

			break;
		}
		case 'get_address':
		{
			$add=array();
			// $res = $db->getRow("SELECT mobile,customer.city_id,customer.area_id,street,pin,latitude,longitude,address,city.name as city_name,area.name as area_name FROM customer left join city on customer.city_id=city.city_id left join area on customer.area_id=area.area_id where customer.customer_id=".$_POST['customer_id']);

			// //echo $db->getLastQuery(); die;
			// if(!empty($res)){
			// 	foreach ($res as $key => $val) {	
			// 		if (is_int($key)) {
			// 			unset($res[$key]);
			// 		}			
			// 	}
			// }
			// $add[]=$res;
			$res = $db->getRows("SELECT customer_address.*,city.name as city_name,area.name as area_name FROM customer_address left join city on customer_address.city_id=city.city_id left join area on customer_address.area_id=area.area_id where customer_address.customer_id=".$_POST['customer_id']." order by customer_address_id desc");

			//echo $db->getLastQuery(); die;
			if(!empty($res)){
				foreach ($res as $key => $res1) {	
					foreach ($res1 as $key1 => $val) {	
						if (is_int($key1)) {
							unset($res1[$key1]);
						}			
					}					 	
					$add[]=$res1;
				}
			}

			$resp['res']=$add;
			$resp['status'] = 'success'; 
			$resp['code'] = 200;  
			$resp['message'] = 'Success!';

			break;
		}
		case 'save_address':
		{	
			$save= $_POST;
			unset($save['action']);
			unset($save['token']);

			if(empty($_POST['customer_address_id'])){
				$save['created_date']= time(); 
				$id = $db->insertAry('customer_address',$save);
			}
			else{
				$save['modified_date']= time(); 
				$qry = $db->updateAry("customer_address", $save, "where customer_address_id=".$_POST['customer_address_id']);
				$id=$_POST['customer_id'];
			}
			//echo $db->getLastQuery(); die;
			if(!is_null($id)){
				$resp['status'] = 'success'; 
				$resp['code'] = 200;  
				$resp['message'] = 'Profile updated successfully!';	
			}
			else{
				$resp['status'] = 'error'; 
				$resp['code'] = 400;  
				$resp['message'] = 'Profile update failed!';
			}

			break;
		}
	}
	echo json_encode($resp);
	?>