  $('.btnSignupSubmit').hide();
  $('.btnGetOtp').click(function(){
    var Name = $('#cust-name').val();
    var Mobile = $('#cust-mobile').val();
    // alert(Mobile);
        $.ajax({
            type: 'post',
            url: 'ajax_request.php',
            data: 'action=signup_save&Name='+Name+'&Mobile='+Mobile,
            dataType: "json",
            beforeSend: function() {
                $('.btnGetOtp').prop('disabled', true);
                $('.btnGetOtp').html('Please Wait...');
            },
            success: function (data) {
              $('.btnGetOtp').prop('disabled', false);
              $('.btnGetOtp').html('Get OTP');
              if(data['validation'] == '1'){
                $('.btnGetOtp').hide();
                $('.btnSignupSubmit').show();
                $('#otp').prop('disabled', false);
                $('#new-passwd').prop('disabled', false);
              }
              else if(data['validation'] == '2'){
                // alert("Wrong OTP !");
                $("#resultSignupDiv").html('<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Please Fill the Empty Fields !</div>');
              }   
              else if(data['validation'] == '3'){
                // alert("Wrong OTP !");
                $("#resultSignupDiv").html('<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Mobile Number already Exsist !</div>');
              }  
              else if(data['validation'] == '0'){
                // alert("Wrong OTP !");
                $("#resultSignupDiv").html('<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Register Failed !</div>');
              }                                      
            }
        });    
  });

  // $('#signup-form').on('submit', function (e) {
  $('.btnSignupSubmit').click(function(){
    var Name = $('#cust-name').val();
    var Mobile = $('#cust-mobile').val();
    var Otp = $('#otp').val();
    var passwd = $('#new-passwd').val();
    // alert(Mobile);
      $.ajax({
          type: 'post',
          url: 'ajax_request.php',
          data: 'action=validate_otp&Name='+Name+'&Mobile='+Mobile+'&Otp='+Otp+'&Passwd='+passwd,
          dataType: "json",
          beforeSend: function() {
              $('.btnSignupSubmit').prop('disabled', true);
              $('.btnSignupSubmit').html('Please Wait...');
          },
          success: function (data) {
            $('.btnSignupSubmit').prop('disabled', false);
            $('.btnSignupSubmit').html('Signup');

            if(data['validation'] == '1'){
              //$('#otp').prop('disabled', false);
              $("#resultSignupDiv").html('<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Registration Successful !</div>');
              //alert("Registered Successful !");
              setTimeout(function(){
               location.reload(); }, 
               1000);
            }
            else if(data['validation'] == '2'){
              // alert("Wrong OTP !");
              $("#resultSignupDiv").html('<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Please Enter The OTP !</div>');
            }
            else if(data['validation'] == '0'){
              // alert("Wrong OTP !");
              $("#resultSignupDiv").html('<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Invalid OTP !</div>');
            }      
            else if(data['validation'] == '3'){
              // alert("Wrong OTP !");
              $("#resultSignupDiv").html('<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Please Enter Your New Password !</div>');
            }                    
          }
      }); 
      return false;   
  });
  
  $('#login-form').on('submit', function (e) {
  // $('.btnLoginSubmit').click(function(){
    var usernme = $('#username').val();
    var passwd = $('#passwd').val();
    // alert(usernme);
      $.ajax({
          type: 'post',
          url: 'ajax_request.php',
          data: 'action=validate_login&Username='+usernme+'&Passwd='+passwd,
          dataType: "json",
          beforeSend: function() {
              $('.btnLoginSubmit').prop('disabled', true);
              $('.btnLoginSubmit').html('Please Wait...');
          },
          success: function (data) {
            $('.btnLoginSubmit').prop('disabled', false);
            $('.btnLoginSubmit').html('<i class="fa fa-check" aria-hidden="true"></i>Submit');

            if(data['validation'] == '1'){
              // alert("Login Successful !");
              $("#resultLoginDiv").html('<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Login Successful !</div>');
              setTimeout(function(){location.reload(); }, 1000);
            }
            else if(data['validation'] == '0'){
              // alert("Password Wrong !");
              $("#resultLoginDiv").html('<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Invalid Credential !</div>');
            }
            else if(data['validation'] == '2'){
              // alert("Mobile / Email is Wrong !");
              $("#resultLoginDiv").html('<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Please Fill the Empty Fields !</div>');
            }

          }
      });
      return false;    
  });

  $('#btnSubmitForRstPwsd').hide();
  $('#resetPswdHeader').hide();
  $('#btnForgotPassword').click(function(){
    // alert();
    $('.tab-content').hide();
    $('#tabMenu').hide();
    $('#forgotPasswordFormDiv').show();
    $('#resetPswdHeader').show();
  });


  $('#btnBackToLogin').click(function(){
    // alert();
    $('.tab-content').show();
    $('#tabMenu').show();
    $('#forgotPasswordFormDiv').hide();
    $('#resetPswdHeader').hide();
  });
  
  $('#btnGetOtpForRstPwsd').click(function(){
    // $('#btnSubmitForRstPwsd').show();
    // $('#btnGetOtpForRstPwsd').hide();

    var Mobile = $('#customer-mobile').val();
    // alert(Mobile);
      $.ajax({
          type: 'post',
          url: 'ajax_request.php',
          data: 'action=otpForResetPassword&Mobile='+Mobile,
          dataType: "json",
          beforeSend: function() {
              $('#btnGetOtpForRstPwsd').prop('disabled', true);
              $('#btnGetOtpForRstPwsd').html('Please Wait...');
          },
          success: function (data) {
            $('#btnGetOtpForRstPwsd').prop('disabled', false);
            $('#btnGetOtpForRstPwsd').html('Get OTP');
            if(data['validation'] == '1'){
              $('#btnGetOtpForRstPwsd').hide();
              $('#btnSubmitForRstPwsd').show();
              $('#reset-otp').prop('disabled', false);
              $('#reset-new-passwd').prop('disabled', false);
            }
            else if(data['validation'] == '2'){
              // alert("Wrong OTP !");
              $("#resultResetPwdDiv").html('<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Please Fill the Empty Fields !</div>');
            }   
            else if(data['validation'] == '3'){
              // alert("Wrong OTP !");
              $("#resultResetPwdDiv").html('<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>It is not a Registered Mobile Number !</div>');
            }  
            else if(data['validation'] == '0'){
              // alert("Wrong OTP !");
              $("#resultResetPwdDiv").html('<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Failed ! DB Error</div>');
            }                                      
          }
      }); 
  });

    $('#btnSubmitForRstPwsd').click(function(){
    var Mobile = $('#customer-mobile').val();
    var Otp = $('#reset-otp').val();
    var passwd = $('#reset-new-passwd').val();
    // alert(Mobile);
      $.ajax({
          type: 'post',
          url: 'ajax_request.php',
          data: 'action=resetPassword&Mobile='+Mobile+'&Otp='+Otp+'&Passwd='+passwd,
          dataType: "json",
          beforeSend: function() {
              $('#btnSubmitForRstPwsd').prop('disabled', true);
              $('#btnSubmitForRstPwsd').html('Please Wait...');
          },
          success: function (data) {
            $('#btnSubmitForRstPwsd').prop('disabled', false);
            $('#btnSubmitForRstPwsd').html('Submit');

            if(data['validation'] == '1'){
              //$('#otp').prop('disabled', false);
              $("#resultResetPwdDiv").html('<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Password Reset Successfuly !</div>');
              //alert("Registered Successful !");
              setTimeout(function(){
               location.reload(); }, 
               1000);
            }
            else if(data['validation'] == '2'){
              // alert("Wrong OTP !");
              $("#resultResetPwdDiv").html('<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Please Enter The OTP !</div>');
            }
            else if(data['validation'] == '0'){
              // alert("Wrong OTP !");
              $("#resultResetPwdDiv").html('<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Invalid OTP !</div>');
            }      
            else if(data['validation'] == '3'){
              // alert("Wrong OTP !");
              $("#resultResetPwdDiv").html('<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Please Enter Your New Password !</div>');
            }    
            else if(data['validation'] == '4'){
              // alert("Wrong OTP !");
              $("#resultResetPwdDiv").html('<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Failed ! DB Error</div>');
            }                              
          }
      }); 
      return false;   
  });