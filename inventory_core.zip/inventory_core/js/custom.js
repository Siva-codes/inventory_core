// custom js file

    // Created on   : 11/08/2017.
    // Theme Name   : myPat.
    // Description  : myPat - Responsive html5 template.
    // Version      : 1.0.
    // Author       : @Unifytheme.
    // Developed by : @Unifytheme.

"use strict";

// Prealoder
 function prealoader () {
   if ($('#loader').length) {
     $('#loader').fadeOut(); // will first fade out the loading animation
     $('#loader-wrapper').delay(350).fadeOut('slow'); // will fade out the white DIV that covers the website.
     $('body').delay(350).css({'overflow':'visible'});
  };
 }

// placeholder remove
function removePlaceholder () {
  if ($("input,textarea").length) {
    $("input,textarea").each(
        function(){
            $(this).data('holder',$(this).attr('placeholder'));
            $(this).on('focusin', function() {
                $(this).attr('placeholder','');
            });
            $(this).on('focusout', function() {
                $(this).attr('placeholder',$(this).data('holder'));
            });
            
    });
  }
}

// scroll header
function stickyHeader () {
  var sticky = $('.theme-main-menu'),
      scroll = $(window).scrollTop();

  if (sticky.length) {
    if (scroll >= 190){
      sticky.addClass('fixed');
      $('.btn-brand-alphabet').addClass('fixed');
      $('#divBrands').addClass('fixed');
    }
    else {
      sticky.removeClass('fixed');
      $('.btn-brand-alphabet').removeClass('fixed');
      $('#divBrands').removeClass('fixed');
    }
  };
}

// toggle menu for mobile
function mobileDropdown () {
  if($('.main-menu').length) {
    $('.main-menu nav ul li.dropdown-holder').append(function () {
      return '<i class="fa fa-align-justify" aria-hidden="true"></i>';
    });
    $('.main-menu nav ul li.dropdown-holder .fa').on('click', function () {
      $('.mobile-menu').slideToggle();
    }); 
  }
}

// Theme Search Box 
function searchBox () {
  var search = $("#search-button"),
      mainSearch = $("#searchWrapper"),
      close = $("#close-button");
  if(search.length) {
    search.on('click', function(){
      mainSearch.addClass('show-box');
    });
    close.on('click', function() {
      mainSearch.removeClass('show-box');
    });
  }
}

// Theme Search Box 
// function CustomerRegBox () {
//   var search = $("#user-button"),
//       mainSearch = $("#signupWrapper"),
//       close = $("#close-popup");
//   if(search.length) {
//     search.on('click', function(){
//       mainSearch.addClass('show-box');
//     });
//     close.on('click', function() {
//       mainSearch.removeClass('show-box');
//     });
//   }
// }

// Scroll to top
function scrollToTop () {
  if ($('.scroll-top').length) {

    //Check to see if the window is top if not then display button
    $(window).on('scroll', function (){
      if ($(this).scrollTop() > 200) {
        $('.scroll-top').fadeIn();
      } else {
        $('.scroll-top').fadeOut();
      }
    });
    
    //Click event to scroll to top
    $('.scroll-top').on('click', function() {
      $('html, body').animate({scrollTop : 0},1500);
      return false;
    });
  }
}


// Theme-banner slider 
function BannerSlider () {
  var banner = $("#theme-main-banner");
  if (banner.length) {
      banner.camera({ //here I declared some settings, the height and the presence of the thumbnails 
        height: '26%',
        pagination: true,
        thumbnails: false,
        playPause: false,
        autoplay:true,
        pauseOnClick: false,
        hover: false,
        overlayer: true,
        loader: 'bar', // loader
        time: 5000, // Slider display time
        transPeriod: 1500, // sliding effect in milliseconds
        minHeight: '',
        fx: 'simpleFade', // sliding effect we can more simpleFade, scrollRight, scrollBottom
        autoAdvance: true,
        mobileAutoAdvance: true,
        alignment: 'center',


      });
  };
}


// isoptop Project Gallery
function masanory () {
  if ($("#isotop-gallery-wrapper").length) {
    var $grid = $('#isotop-gallery-wrapper').isotope({
      // options
      itemSelector: '.isotop-item',
      percentPosition: true,
      masonry: {
        // use element for option
        columnWidth: '.grid-sizer'
      }

    });

    // filter items on button click
    $('.isotop-menu-wrapper').on( 'click', 'li', function() {
      var filterValue = $(this).attr('data-filter');
      $grid.isotope({ filter: filterValue });
    });

     // change is-checked class on buttons
      $('.isotop-menu-wrapper').each( function( i, buttonGroup ) {
        var $buttonGroup = $( buttonGroup );
        $buttonGroup.on( 'click', 'li', function() {
          $buttonGroup.find('.is-checked').removeClass('is-checked');
          $( this ).addClass('is-checked');
        });
      });
  };
}


// Counter function
function CounterNumberChanger () {
  var timer = $('.timer');
  if(timer.length) {
    timer.appear(function () {
      timer.countTo();
    })
  }
}


// W-l- Home client-review-slider
function clientReviewSlider ()  {
	var carouselOne = $("#client-review-slider");
	if(carouselOne.length) {
		carouselOne.owlCarousel({
			items:2,
			margin:20,
			loop:true,
			nav:true,
      navigation:true,
      navText:['<i aria-hidden="true" class="fa fa-caret-left"></i>','<i aria-hidden="true" class="fa fa-caret-right"></i>'],
			dotsEach:1,
			autoplay:true,
			autoplayTimeout:5000,
      autoplayHoverPause:true,
			autoplaySpeed:5000,
			dragEndSpeed:1000,
			smartSpeed:1000,
			responsiveClass:true,
			responsive:{
				0:{
          items:1
        },
        600:{
          items:2
        },
        992:{
          items:4
        }
			}
		});
	}
}

// W-l- Home client-review-slider
function newProductSlider ()  {
  var carouselOne = $("#new-product-slider");
  if(carouselOne.length) {
    carouselOne.owlCarousel({
      items:2,
      margin:20,
      loop:true,
      nav:true,
      navigation:true,
      navText:['<i aria-hidden="true" class="fa fa-caret-left"></i>','<i aria-hidden="true" class="fa fa-caret-right"></i>'],
      dots:false,
      autoplay:true,
      autoplayTimeout:3000,
      autoplayHoverPause:true,
      autoplaySpeed:2000,
      dragEndSpeed:1000,
      smartSpeed:1000,
      responsiveClass:true,
      responsive:{
        0:{
          items:1
        },
        600:{
          items:2
        },
        992:{
          items:4
        }
      }
    });
  }
}

function offerPackageSlider ()  {
  var carouselOne = $("#offer-package-slider");
  if(carouselOne.length) {
    carouselOne.owlCarousel({
      items:2,
      margin:20,
      loop:false,
      rewind: true,
      nav:true,
      navigation:true,
      navText:['<i aria-hidden="true" class="fa fa-caret-left"></i>','<i aria-hidden="true" class="fa fa-caret-right"></i>'],
      dotsEach:1,
      dots: false,
      autoplay:false,
      autoplayTimeout:5000,
      autoplayHoverPause:true,
      autoplaySpeed:5000,
      dragEndSpeed:1000,
      smartSpeed:1000,
      responsiveClass:true,
      responsive:{
        0:{
          items:2
        },
        600:{
          items:2
        },
        992:{
          items:3
        }
      }
    });
  }
}

function category_slider ()  {
  var carouselOne = $(".category_slider");
  if(carouselOne.length) {
    carouselOne.owlCarousel({
      items:2,
      margin:20,
      loop:true,
      nav:true,
      navigation:true,
      navText:['<i aria-hidden="true" class="fa fa-caret-left"></i>','<i aria-hidden="true" class="fa fa-caret-right"></i>'],
      dots:false,
      autoplay:true,
      autoplayTimeout:3000,
      autoplayHoverPause:true,
      autoplaySpeed:2000,
      dragEndSpeed:1000,
      smartSpeed:1000,
      responsiveClass:true,
      responsive:{
        0:{
          items:1
        },
        600:{
          items:2
        },
        992:{
          items:4
        }
      }
    });
  }

}

// W-l Home partner-logo
function partnerLogo ()  {
  var carouselOne = $("#partner-logo");
  if(carouselOne.length) {
    carouselOne.owlCarousel({
      items:4,
      margin:30,
      loop:true,
      nav:true,
      navText:['<i aria-hidden="true" class="fa fa-caret-left"></i>','<i aria-hidden="true" class="fa fa-caret-right"></i>'],
      dotsEach:1,
      autoplay:true,
      autoplayTimeout:4000,
      autoplaySpeed:2000,
      dragEndSpeed:1000,
      smartSpeed:1000,
      responsiveClass:true,
      responsive:{
        0:{
          items:2,
          margin:15,
        },
        501:{
          items:3,
        },
        992:{
          items:4
        }
        
      }
    });
  }
}


// shop price ranger
function priceRanger () {
  if ($('.price-ranger').length) {
    $( '.price-ranger #slider-range' ).slider({
      range: true,
      min: 0,
      max: 350,
      values: [ 25, 250 ],
      slide: function( event, ui ) {
        $( '.price-ranger .ranger-min-max-block .min' ).val( '$' + ui.values[ 0 ] );
        $( '.price-ranger .ranger-min-max-block .max' ).val( '$' + ui.values[ 1 ] );
      }
    });
      $( '.price-ranger .ranger-min-max-block .min' ).val( '$' + $( '.price-ranger #slider-range' ).slider( 'values', 0 ) );
    $( '.price-ranger .ranger-min-max-block .max' ).val( '$' + $( '.price-ranger #slider-range' ).slider( 'values', 1 ) );        
  };  
}


// Product Slider
function productSlider () {
  var carouselOne = $("#related-product-slider-carousel");
  if(carouselOne.length) {
		carouselOne.owlCarousel({
        loop:true,
        margin:30,
        nav:true,
        navText: ["",""],
        dots:false,
        autoplay:true,
        autoplayTimeout:5000,
        smartSpeed:1300,
        lazyLoad:true,
        autoplayHoverPause:true,
        responsive:{
            0:{
                items:1
            },
            400:{
                items:2
            },
            992:{
                items:3
            }
        }
    })
  }
}


// WOW animation 
function wowAnimation () {
  if($('.wow').length) {
    var wow = new WOW(
    {
      boxClass:     'wow',      // animated element css class (default is wow)
      animateClass: 'animated', // animation css class (default is animated)
      offset:       50,          // distance to the element when triggering the animation (default is 0)
      mobile:       true,       // trigger animations on mobile devices (default is true)
      live:         true,       // act on asynchronously loaded content (default is true)
      callback:     function(box) {
        // the callback is fired every time an animation is started
        // the argument that is passed in is the DOM node being animated
      },
      scrollContainer: null // optional scroll container selector, otherwise use window
    }
  );
  wow.init();
  }
}


// Fancybox 
function FancypopUp () {
  if ($(".fancybox").length) {
    $(".fancybox").fancybox({
      openEffect  : 'elastic',
        closeEffect : 'elastic',
         helpers : {
            overlay : {
                css : {
                    'background' : 'rgba(0, 0, 0, 0.6)',
                    'z-index' : '99999999'
                }
            }
        }
    });
  };
}


//Contact Form Validation
function contactFormValidation () {
  var activeform = $(".form-validation");
  if(activeform.length){
      activeform.validate({ // initialize the plugin
        rules: {
          name: {
            required: true
          },
          email: {
            required: true,
            email: true
          },
          sub: {
            required: true
          },
          message: {
            required: true
          }
        },
      submitHandler: function(form) {
                $(form).ajaxSubmit({
                    success: function() {
                        $('.form-validation :input').attr('disabled', 'disabled');
                        activeform.fadeTo( "slow", 1, function() {
                            $(this).find(':input').attr('disabled', 'disabled');
                            $(this).find('label').css('cursor','default');
                            $('#alert-success').fadeIn();
                        });
                    },
                    error: function() {
                        activeform.fadeTo( "slow", 1, function() {
                            $('#alert-error').fadeIn();
                        });
                    }
                });
            }
        });
  }
}


// Close suddess Alret
function closeSuccessAlert () {
  var closeButton = $ (".closeAlert");
  if(closeButton.length) {
      closeButton.on('click', function(){
        $(".alert-wrapper").fadeOut();
      });
      closeButton.on('click', function(){
        $(".alert-wrapper").fadeOut();
      })
  }
}


// Accordion panel
function themeAccrodion () {
  if ($('.theme-accordion > .panel').length) {
    $('.theme-accordion > .panel').on('show.bs.collapse', function (e) {
          var heading = $(this).find('.panel-heading');
          heading.addClass("active-panel");

    });

    $('.theme-accordion > .panel').on('hidden.bs.collapse', function (e) {
        var heading = $(this).find('.panel-heading');
          heading.removeClass("active-panel");
          //setProgressBar(heading.get(0).id);
    });

    $('.panel-heading a').on('click',function(e){
        if($(this).parents('.panel').children('.panel-collapse').hasClass('in')){
            e.stopPropagation();
        }
    });

  };
}


// RoundCircle Progress
function roundCircleProgress () {
  var rounderContainer = $('.piechart');
  if (rounderContainer.length) {
    rounderContainer.each(function () {
      var Self = $(this);
      var value = Self.data('value');
      var size = Self.parent().width();
      var color = Self.data('border-color');

      Self.find('span').each(function () {
        var expertCount = $(this);
        expertCount.appear(function () {
          expertCount.countTo({
            from: 1,
            to: value*100,
            speed: 2000
          });
        });

      });
      Self.appear(function () {         
        Self.circleProgress({
          value: value,
          size: 266,
          thickness: 5,
          emptyFill: 'rgba(243,243,243,1)',
          animation: {
            duration: 2000
          },
          fill: {
            color: color
          }
        });
      });
    });
  };
}


// Product value
// function productValue () {
//   var inputVal = $("#product-value");
//   if(inputVal.length) {
//     $('#value-decrease').on('click', function() {
//         inputVal.html(function(i, val) { return val*1-1 });
//     });
//     $('#value-increase').on('click', function() {
//         inputVal.html(function(i, val) { return val*1+1 });
//     });
//   }
// }
  

// DOM ready function
jQuery(document).on('ready', function(){
	(function($){
		mobileDropdown ();
    removePlaceholder ();
    searchBox ();
    // CustomerRegBox();
		BannerSlider ();
		clientReviewSlider ();
    newProductSlider();
    offerPackageSlider();
    category_slider ();
    partnerLogo ();
		CounterNumberChanger ();
		wowAnimation ();
		priceRanger ();
		productSlider ();
		FancypopUp ();
		scrollToTop ();
		contactFormValidation ();
    themeAccrodion ();
    // productValue ();
		closeSuccessAlert ()
	})(jQuery);
});

// Window scroll function
jQuery(window).on('scroll', function(){
	(function($){
		stickyHeader ();
	})(jQuery);
});

// Window on load function
jQuery(window).on('load', function(){
	(function($){
		prealoader ();
		masanory ();
    roundCircleProgress ();
	})(jQuery);
});

    function openCity(evt, cityName) {
      // Declare all variables
      var i, tabcontent, tablinks;

      // Get all elements with class="tabcontent" and hide them
      tabcontent = document.getElementsByClassName("sbp_content");
      for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
      }
      // Get all elements with class="tablinks" and remove the class "active"
      tablinks = document.getElementsByClassName("brand-nav");
      for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
      }

      // Show the current tab, and add an "active" class to the link that opened the tab
      document.getElementById(cityName).style.display = "block";
      evt.currentTarget.className += " active";
    }

/**
 *  BootTree Treeview plugin for Bootstrap.
 *
 *  Based on BootSnipp TreeView Example by Sean Wessell
 *  URL:  http://bootsnipp.com/snippets/featured/bootstrap-30-treeview
 *
 *  Revised code by Leo "LeoV117" Myers
 *
 */
  $.fn.extend({
    treeview: function() {
      return this.each(function() {
        // Initialize the top levels;
        var tree = $(this);
        
        tree.addClass('treeview-tree');
        tree.find('li').each(function() {
          var stick = $(this);
        });
        tree.find('li').has("ul").each(function () {
          var branch = $(this); //li with children ul
          var branchClass = branch.attr('class');
          // alert();
          if(branchClass =='mobile-menu-sub-li2'){
             branch.prepend("<i class='tree-indicator glyphicon glyphicon-chevron-right'></i>");
          }else{
             branch.prepend("<i class='tree-indicator glyphicon glyphicon-plus'></i>");
          }
         
          branch.addClass('tree-branch');
          branch.on('click', function (e) {
            if (this == e.target) {
              var icon = $(this).children('i:first');
              
              icon.toggleClass("glyphicon-minus");
              $(this).children().children().toggle();
            }
          })
          branch.children().children().toggle();
          
          /**
           *  The following snippet of code enables the treeview to
           *  function when a button, indicator or anchor is clicked.
           *
           *  It also prevents the default function of an anchor and
           *  a button from firing.
           */
          branch.children('.tree-indicator, button, a').click(function(e) {
            branch.click();
            
            e.preventDefault();
          });
        });
      });
    }
  });

  var rotated = false;
  $(".mobile-menu-sub-li2").click(function() {
    if (!rotated) {
      $(this).closest('i').toggleClass('glyphicon-chevron-right glyphicon-chevron-down');
    } else {
      $(this).find('i').toggleClass('glyphicon-chevron-down glyphicon-chevron-right');
    }
    // Toggle the flag
    rotated = !rotated;
  });
  /**
   *  The following snippet of code automatically converst
   *  any '.treeview' DOM elements into a treeview component.
   */
  $(window).on('load', function () {
    $('.treeview').each(function () {
      var tree = $(this);
      tree.treeview();
    })
  });

  